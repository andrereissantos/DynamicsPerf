/* This is a current activity query used to identify what processes are 
   currently running on the processors.  Use this query to find what user
   is running a large report or process and consuming system resources.  This 
   is a snapshot view of current activity.  You should execute the query several times
   to identify if a query is increasing it's I/O or CPU time.    
   
   explanation of TempDb usage columns:  http://technet.microsoft.com/en-us/library/ms190288.aspx
*/

--*****************  CURRENTLY EXECUTING SQL STATEMENTS ***********************

EXEC DynamicsPerf.dbo.DYNPERF_SERVER_ACTIVITY 
	/**** THIS IS FOR REMOTE SERVER AND NO AX DATABASE *****/
--@SERVER_NAME = 'MY_REMOTE_SERVER'

------------------------------------------------------------------------------------------------
--   SQL Server Performance Counters 
------------------------------------------------------------------------------------------------

SELECT *
FROM   DynamicsPerf.dbo.PERF_COUNTER_VW
WHERE   COUNTER_NAME LIKE 'Page life expectancy'
-- AND STATS_TIME > DATEADD(MI, -60, GETDATE())
ORDER  BY STATS_TIME DESC,
          OBJECT_NAME 
