/**********************  queries BY LOCK_TIME_MS by ONE HOUR interval  *********************************************/

SELECT(SELECT SUM(qws.total_query_wait_time_ms)
       FROM   sys.query_store_wait_stats qws
       WHERE  qws.plan_id = A.plan_id
              AND A.runtime_stats_interval_id = qws.runtime_stats_interval_id) AS TOTAL_LOCK_TIME_MS,
      A.*,
      qt.query_sql_text,
      TRY_CONVERT(xml, qp.query_plan)                                          AS QUERY_PLAN
FROM   (SELECT TOP 100 q.query_hash                                                                              AS QUERY_HASH,
                       p1.query_plan_hash                                                                        AS QUERY_PLAN_HASH,
                       rs.runtime_stats_interval_id                                                              AS RUNTIME_STATS_INTERVAL_ID,
                       MIN(CAST(DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), GETDATE()), rsi.start_time) AS DATETIME)) AS STARTDATE,
                       MIN(CAST(DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), GETDATE()), rsi.end_time) AS DATETIME))   AS ENDDATE,
                       CAST(SUM(rs.count_executions) AS BIGINT)                                                  AS TOTAL_EXECUTIONS,
                       CAST(SUM(( ( rs.avg_duration / 1000 ) * rs.count_executions )) AS DECIMAL(29, 3))         AS TOTAL_TIME,
                       CAST(AVG(rs.avg_duration / 1000) AS DECIMAL(29, 3))                                       AS AVG_DURATION_MS,
                       CAST (AVG(p1.avg_compile_duration) / 1000 AS DECIMAL(29, 3))                              AS AVG_COMPILE_TIME_MS,
                       CAST(AVG(rs.avg_logical_io_reads) AS DECIMAL(29, 3))                                      AS AVG_LOGICAL_IO_READS,
                       CAST(AVG(rs.avg_logical_io_writes) AS DECIMAL(29, 3))                                     AS AVG_LOGICAL_IO_WRITES,
                       CAST(MAX(rs.max_duration / 1000.000) AS DECIMAL(29, 3))                                   AS MAX_DURATION,
                       MAX(rs.max_dop)                                                                           AS MAX_DOP,
                       CAST(MAX(rs.max_rowcount) AS BIGINT)                                                      AS MAX_ROWCOUNT,
                       CAST(AVG(rs.avg_cpu_time / 1000.00) AS DECIMAL(29, 3))                                    AS AVG_CPU_TIME_MS,
                       CAST(MAX(rs.max_tempdb_space_used) / 1024 * 8 AS BIGINT)                                  AS MAX_TEMPDB_SPACE_USED_MB,
                       MIN(q.query_id)                                                                           AS QUERY_ID,
                       MIN(q.query_text_id)                                                                      AS QUERY_TEXT_ID,
                       MIN(p1.plan_id)                                                                           AS PLAN_ID
        FROM   sys.query_store_runtime_stats_interval AS rsi
               INNER LOOP JOIN sys.query_store_runtime_stats AS rs
                            ON rsi.runtime_stats_interval_id = rs.runtime_stats_interval_id
               JOIN sys.query_store_plan AS p1
                 ON p1.plan_id = rs.plan_id
               JOIN sys.query_store_query AS q
                 ON q.query_id = p1.query_id
               JOIN sys.query_store_query_text AS qt
                 ON QT.query_text_id = q.query_text_id
        WHERE  1 = 1
               AND rsi.end_time > '2018-11-06 12:00:00.000' --this is in UTC time    select getutcdate()
               AND qt.query_sql_text NOT LIKE 'select statman%'
               AND qt.query_sql_text NOT LIKE '%sys.%' --REH Don't want to see our QDS queries in this resultset
        -- qt.query_sql_text  like '%entitystore%'   --REH Use this one to see queries exporting data
        GROUP  BY q.query_hash,
                  p1.query_plan_hash,
                  rs.runtime_stats_interval_id
        ORDER  BY TOTAL_TIME DESC) AS a
       JOIN sys.query_store_plan AS qp
         ON a.plan_id = qp.plan_id
       JOIN sys.query_store_query_text AS qt
         ON QT.query_text_id = a.query_text_id
ORDER  BY TOTAL_LOCK_TIME_MS DESC



/********************************************** Compiles *******************************************/

SELECT a.*,
       qt.query_sql_text,
       TRY_CONVERT(xml, qp.query_plan) AS QUERY_PLAN
--,  object_name(cast(isnull(index_nodes.value('(//@ParentObjectId)[1]', 'nvarchar(128)'),'0') AS int)) AS parentojbect 
FROM   (SELECT TOP 100 q.query_hash                                                                              AS QUERY_HASH,
                       p1.query_plan_hash                                                                        AS QUERY_PLAN_HASH,
                       rs.runtime_stats_interval_id                                                              AS RUNTIME_STATS_INTERVAL_ID,
                       MIN(CAST(DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), GETDATE()), rsi.start_time) AS DATETIME)) AS STARTDATE,
                       MIN(CAST(DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), GETDATE()), rsi.end_time) AS DATETIME))   AS ENDDATE,
                       SUM (( ( p1.avg_compile_duration ) / 1000 * P1.count_compiles ))                          AS TOTAL_COMPILE_TIME_MS,
                       CAST(SUM(rs.count_executions) AS BIGINT)                                                  AS TOTAL_EXECUTIONS,
                       CAST(SUM(( ( rs.avg_duration / 1000 ) * rs.count_executions )) AS DECIMAL(29, 3))         AS TOTAL_TIME,
                       CAST(AVG(rs.avg_duration / 1000) AS DECIMAL(29, 3))                                       AS AVG_DURATION_MS,
                       CAST (AVG(p1.avg_compile_duration) / 1000 AS DECIMAL(29, 3))                              AS AVG_COMPILE_TIME_MS,
                       CAST(AVG(rs.avg_logical_io_reads) AS DECIMAL(29, 3))                                      AS AVG_LOGICAL_IO_READS,
                       CAST(AVG(rs.avg_logical_io_writes) AS DECIMAL(29, 3))                                     AS AVG_LOGICAL_IO_WRITES,
                       CAST(MAX(rs.max_duration / 1000.000) AS DECIMAL(29, 3))                                   AS MAX_DURATION,
                       MAX(rs.max_dop)                                                                           AS MAX_DOP,
                       CAST(MAX(rs.max_rowcount) AS BIGINT)                                                      AS MAX_ROWCOUNT,
                       CAST(AVG(rs.avg_cpu_time / 1000.00) AS DECIMAL(29, 3))                                    AS AVG_CPU_TIME_MS,
                       CAST(MAX(rs.max_tempdb_space_used) / 1024 * 8 AS BIGINT)                                  AS MAX_TEMPDB_SPACE_USED_MB,
                       MIN(q.query_id)                                                                           AS QUERY_ID,
                       MIN(q.query_text_id)                                                                      AS QUERY_TEXT_ID,
                       MIN(p1.plan_id)                                                                           AS PLAN_ID
        FROM   sys.query_store_runtime_stats_interval AS rsi
               INNER LOOP JOIN sys.query_store_runtime_stats AS rs
                            ON rsi.runtime_stats_interval_id = rs.runtime_stats_interval_id
               JOIN sys.query_store_plan AS p1
                 ON p1.plan_id = rs.plan_id
               JOIN sys.query_store_query AS q
                 ON q.query_id = p1.query_id
               JOIN sys.query_store_query_text AS qt
                 ON QT.query_text_id = q.query_text_id
        WHERE  1 = 1
               AND rsi.end_time > '2018-11-06 12:00:00.000' --this is in UTC time    select getutcdate()
               AND qt.query_sql_text NOT LIKE 'select statman%'
               AND qt.query_sql_text NOT LIKE '%sys.%' --REH Don't want to see our QDS queries in this resultset
        -- qt.query_sql_text  like '%entitystore%'   --REH Use this one to see queries exporting data
        GROUP  BY q.query_hash,
                  p1.query_plan_hash,
                  rs.runtime_stats_interval_id
        ORDER  BY TOTAL_COMPILE_TIME_MS DESC) AS a
       JOIN sys.query_store_plan AS qp
         ON a.plan_id = qp.plan_id
       JOIN sys.query_store_query_text AS qt
         ON QT.query_text_id = a.query_text_id
WHERE  1 = 1
--and Total_executions >=10 
ORDER  BY TOTAL_COMPILE_TIME_MS DESC



/***********************  Queries aggregated by DAY similar to QUERY_HISTORY in Dynperf   ***************************************/


SELECT TOP 100 a.*,
               qt.query_sql_text,
               TRY_CONVERT(xml, qp.query_plan) AS QUERY_PLAN
FROM   (SELECT TOP 100 q.query_hash                                                                                                      AS QUERY_HASH,
                       p1.query_plan_hash                                                                                                AS QUERY_PLAN_HASH,
                       CAST(DATEADD(DAY, DATEDIFF(DAY, 0, DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), GETDATE()), rsi.end_time)), 0) AS DATE) AS DAY,
                       CAST(SUM(rs.count_executions) AS BIGINT)                                                                          AS TOTAL_EXECUTIONS,
                       CAST(SUM(( ( rs.avg_duration / 1000 ) * rs.count_executions )) AS DECIMAL(29, 3))                                 AS TOTAL_TIME,
                       CAST(AVG(rs.avg_duration / 1000) AS DECIMAL(29, 3))                                                               AS AVG_DURATION_MS,
                       CAST(AVG(p1.avg_compile_duration) / 1000 AS DECIMAL(29, 3))                                                       AS AVG_COMPILE_TIME_MS,
                       CAST(AVG(rs.avg_logical_io_reads) AS DECIMAL(29, 3))                                                              AS AVG_LOGICAL_IO_READS,
                       CAST(AVG(rs.avg_logical_io_writes) AS DECIMAL(29, 3))                                                             AS AVG_LOGICAL_IO_WRITES,
                       CAST(MAX(rs.max_duration / 1000.000) AS DECIMAL(29, 3))                                                           AS MAX_DURATION,
                       MAX(rs.max_dop)                                                                                                   AS MAX_DOP,
                       CAST(MAX(rs.max_rowcount) AS BIGINT)                                                                              AS MAX_ROWCOUNT,
                       CAST(AVG(rs.avg_cpu_time / 1000.00)AS DECIMAL(29, 3))                                                             AS AVG_CPU_TIME_MS,
                       CAST(MAX(rs.max_tempdb_space_used) / 1024 * 8 AS BIGINT)                                                          AS MAX_TEMPDB_SPACE_USED_MB,
                       MIN(q.query_id)                                                                                                   AS QUERY_ID,
                       MIN(q.query_text_id)                                                                                              AS QUERY_TEXT_ID,
                       MIN(p1.plan_id)                                                                                                   AS PLAN_ID
        FROM   sys.query_store_runtime_stats_interval AS rsi
               INNER LOOP JOIN sys.query_store_runtime_stats AS rs
                            ON rsi.runtime_stats_interval_id = rs.runtime_stats_interval_id
               JOIN sys.query_store_plan AS p1
                 ON p1.plan_id = rs.plan_id
               JOIN sys.query_store_query AS q
                 ON q.query_id = p1.query_id
               JOIN sys.query_store_query_text AS qt
                 ON QT.query_text_id = q.query_text_id
        WHERE  1 = 1
               AND CAST(DATEADD(DAY, DATEDIFF(DAY, 0, DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), GETDATE()), rsi.end_time)), 0) AS DATE) = '11/6/2018'
               AND qt.query_sql_text NOT LIKE 'select statman%'
               AND qt.query_sql_text NOT LIKE '%sys.%' --REH Don't want to see our QDS queries in this resultset
        -- qt.query_sql_text  like '%entitystore%'   --REH Use this one to see queries exporting data
        GROUP  BY q.query_hash,
                  p1.query_plan_hash,
                  DATEADD(DAY, DATEDIFF(DAY, 0, DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), GETDATE()), rsi.end_time)), 0)
        ORDER  BY TOTAL_TIME DESC) AS a
       JOIN sys.query_store_plan AS qp
         ON a.plan_id = qp.plan_id
       JOIN sys.query_store_query_text AS qt
         ON QT.query_text_id = a.query_text_id
WHERE  1 = 1
--and Total_executions >=10 
ORDER  BY TOTAL_TIME DESC



/***************  the DBCC command is now a DMV similar to statstics HISTOGRAM   *********/


SELECT OBJECT_NAME(ss.object_id) AS TABLE_NAME,
       ss.name                   AS NAME,
       ss.stats_id               AS STATS_ID,
       ac.name                   AS COLUMN_NAME,
       shr.steps                 AS STEPS,
       shr.rows                  AS ROWS,
       shr.rows_sampled          AS ROWS_SAMPLED,
       shr.modification_counter  AS MODIFICATION_COUNTER,
       shr.last_updated          AS LAST_UPDATED,
       sh.range_high_key         AS VALUE,
       sh.equal_rows             AS EQUAL_ROWS,
       sh.range_rows             AS RANGE_ROWS,
       sh.average_range_rows     AS AVG_RANGE_ROWS
FROM   sys.stats ss
       INNER JOIN sys.stats_columns sc
               ON ss.stats_id = sc.stats_id
                  AND ss.object_id = sc.object_id
       INNER JOIN sys.all_columns ac
               ON ac.column_id = sc.column_id
                  AND ac.object_id = sc.object_id
       CROSS APPLY sys.DM_DB_STATS_PROPERTIES(ss.object_id, ss.stats_id) shr
       CROSS APPLY sys.DM_DB_STATS_HISTOGRAM(ss.object_id, ss.stats_id) sh
WHERE  1 = 1
--AND object_name(ss.object_id) = 'INVENTDIM'
--AND ac.name = 'CONFIGID'
ORDER  BY ss.name,
          ss.stats_id,
          shr.steps




/******************************* Queries with wait info by one hour default interval in QDS    *******************************************/
/************************* NOTE WITH THE XML PARSING IN THIS QUERY IT COULD TAKE A VERY LONG TIME TO RUN AS IN HOURS POTENTIALLY  ************/



;WITH XMLNAMESPACES ('http://schemas.microsoft.com/sqlserver/2004/07/showplan' AS sp)

SELECT OBJECT_NAME(CAST(ISNULL(index_nodes.value('(//@ParentObjectId)[1]', 'nvarchar(128)'), '0') AS INT))                                                                                                                                                AS parentojbect,
       a.*,
       qt.query_sql_text,
       TRY_CONVERT(xml, qp.query_plan)                                                                                                                                                                                                                    AS QUERY_PLAN,
       CONVERT (NVARCHAR(MAX), index_node.query('for $qplan in //sp:QueryPlan, $plist in $qplan/sp:ParameterList, $colref in $plist/sp:ColumnReference  return concat(string($colref/@Column),":",string($colref/@ParameterCompiledValue),",   "),"  "')) AS QUERY_PARAMETER_VALUES,
       index_nodeS.value('(../@Impact)[1]', 'float')                                                                                                                                                                                                      AS INDEX_IMPACT,
       REPLACE(REPLACE(index_nodeS.value('(./@Table)[1]', 'NVARCHAR(128)'), '[', ''), ']', '')                                                                                                                                                            AS TABLE_NAME,
       REPLACE(REPLACE(REPLACE(CONVERT(NVARCHAR(max), index_nodeS.query('for $colgroup in ./sp:ColumnGroup,
																			$col in $colgroup/sp:Column
																			where $colgroup/@Usage = "EQUALITY"
																			return string($col/@Name)')), '] [', ', '), '[', ''), ']', '')                                                                                                                                                                  AS EQUALITY_COLUMNS,
       REPLACE(REPLACE(REPLACE(CONVERT(NVARCHAR(max), index_nodeS.query('for $colgroup in ./sp:ColumnGroup,
																			$col in $colgroup/sp:Column
																			where $colgroup/@Usage = "INEQUALITY"
																			return string($col/@Name)')), '] [', ', '), '[', ''), ']', '')                                                                                                                                                                  AS INEQUALITY_COLUMNS,
       REPLACE(REPLACE(REPLACE(CONVERT(NVARCHAR(max), index_nodeS.query('for $colgroup in .//sp:ColumnGroup,
																			$col in $colgroup/sp:Column
																			where $colgroup/@Usage = "INCLUDE"
																			return string($col/@Name)')), '] [', ', '), '[', ''), ']', '')                                                                                                                                                                  AS INCLUDED_COLUMNS
--      , 
--stuff( 
--( 
--         SELECT   ' WAIT TYPE=['+ qws.wait_category_desc + ']  TIME IN MS=['+ cast(qws.total_query_wait_time_ms AS varchar(100)) + ']' +char(10) 
--         FROM     sys.query_store_wait_stats qws 
--         WHERE    qws.plan_id = a.plan_id 
--         AND      a.runtime_stats_interval_id = qws.runtime_stats_interval_id 
--         ORDER BY qws.total_query_wait_time_ms DESC FOR xml path('')),1,1, '') AS WAITS 
FROM   (SELECT TOP 100 q.query_hash                                                                              AS QUERY_HASH,
                       p1.query_plan_hash                                                                        AS QUERY_PLAN_HASH,
                       rs.runtime_stats_interval_id                                                              AS RUNTIME_STATS_INTERVAL_ID,
                       MIN(CAST(DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), GETDATE()), rsi.start_time) AS DATETIME)) AS STARTDATE,
                       MIN(CAST(DATEADD(hh, DATEDIFF(hh, GETUTCDATE(), GETDATE()), rsi.end_time) AS DATETIME))   AS ENDDATE,
                       CAST(SUM(rs.count_executions) AS BIGINT)                                                  AS TOTAL_EXECUTIONS,
                       CAST(SUM(( ( rs.avg_duration / 1000 ) * rs.count_executions )) AS DECIMAL(29, 3))         AS TOTAL_TIME,
                       CAST(AVG(rs.avg_duration / 1000) AS DECIMAL(29, 3))                                       AS AVG_DURATION_MS,
                       CAST (AVG(p1.avg_compile_duration) / 1000 AS DECIMAL(29, 3))                              AS AVG_COMPILE_TIME_MS,
                       CAST(AVG(rs.avg_logical_io_reads) AS DECIMAL(29, 3))                                      AS AVG_LOGICAL_IO_READS,
                       CAST(AVG(rs.avg_logical_io_writes) AS DECIMAL(29, 3))                                     AS AVG_LOGICAL_IO_WRITES,
                       CAST(MAX(rs.max_duration / 1000.000) AS DECIMAL(29, 3))                                   AS MAX_DURATION,
                       MAX(rs.max_dop)                                                                           AS MAX_DOP,
                       CAST(MAX(rs.max_rowcount) AS BIGINT)                                                      AS MAX_ROWCOUNT,
                       CAST(AVG(rs.avg_cpu_time / 1000.00) AS DECIMAL(29, 3))                                    AS AVG_CPU_TIME_MS,
                       CAST(MAX(rs.max_tempdb_space_used) / 1024 * 8 AS BIGINT)                                  AS MAX_TEMPDB_SPACE_USED_MB,
                       MIN(q.query_id)                                                                           AS QUERY_ID,
                       MIN(q.query_text_id)                                                                      AS QUERY_TEXT_ID,
                       MIN(p1.plan_id)                                                                           AS PLAN_ID
        FROM   sys.query_store_runtime_stats_interval AS rsi
               INNER LOOP JOIN sys.query_store_runtime_stats AS rs
                            ON rsi.runtime_stats_interval_id = rs.runtime_stats_interval_id
               JOIN sys.query_store_plan AS p1
                 ON p1.plan_id = rs.plan_id
               JOIN sys.query_store_query AS q
                 ON q.query_id = p1.query_id
               JOIN sys.query_store_query_text AS qt
                 ON QT.query_text_id = q.query_text_id
        WHERE  1 = 1
               AND rsi.end_time BETWEEN '2018-11-07 15:00:00.000' AND '2018-11-07 17:00:00.000' --this is in UTC time    select getutcdate()
               AND qt.query_sql_text NOT LIKE 'select statman%'
               AND qt.query_sql_text NOT LIKE '%sys.%' --REH Don't want to see our QDS queries in this resultset
        -- qt.query_sql_text  like '%entitystore%'   --REH Use this one to see queries exporting data in D365
        GROUP  BY q.query_hash,
                  p1.query_plan_hash,
                  rs.runtime_stats_interval_id
        ORDER  BY TOTAL_TIME DESC) AS a
       JOIN sys.query_store_plan AS qp
         ON a.plan_id = qp.plan_id
       JOIN sys.query_store_query_text AS qt
         ON QT.query_text_id = a.query_text_id
       CROSS APPLY (SELECT TRY_CONVERT(XML, qp.query_plan) AS query_plan_xml) AS qpx
       OUTER APPLY qpx.query_plan_xml.nodes('//sp:MissingIndexes/sp:MissingIndexGroup/sp:MissingIndex') AS missing_indexes(index_nodeS)
       OUTER APPLY qpx.query_plan_xml.nodes('//sp:Batch') AS Batch(index_node)
WHERE  1 = 1
--and Total_executions >=10 
ORDER  BY TOTAL_TIME DESC




--Missing indexes view for Query Data Store (note joining to this view will cause the query to be very slow potentially)





--Create view MSFT_QS_MISSING_INDEXES_VW
--AS
--WITH XMLNAMESPACES ('http://schemas.microsoft.com/sqlserver/2004/07/showplan' AS sp)
--SELECT 
--       p.plan_id,cast(p.query_plan as xml) as QUERY_PLAN,
--                     CONVERT (NVARCHAR(MAX), index_node.query('for $qplan in //sp:QueryPlan, $plist in $qplan/sp:ParameterList, $colref in $plist/sp:ColumnReference  return concat(string($colref/@Column),":",string($colref/@ParameterCompiledValue),",   "),"  "')) AS QUERY_PARAMETER_VALUES,
--       index_nodeS.value('(../@Impact)[1]', 'float')                                                                                                                                                                                                      AS INDEX_IMPACT,
--       Replace(Replace(index_nodeS.value('(./@Table)[1]', 'NVARCHAR(128)'), '[', ''), ']', '')                                                                                                                                                            AS TABLE_NAME,
--       Replace(Replace(Replace(CONVERT(NVARCHAR(max), index_nodeS.query('for $colgroup in ./sp:ColumnGroup,
--                                                $col in $colgroup/sp:Column
--                                                where $colgroup/@Usage = "EQUALITY"
--                                                return string($col/@Name)')), '] [', ', '), '[', ''), ']', '')                                                                                                                                     AS EQUALITY_COLUMNS,
--       Replace(Replace(Replace(CONVERT(NVARCHAR(max), index_nodeS.query('for $colgroup in ./sp:ColumnGroup,
--                                                $col in $colgroup/sp:Column
--                                                where $colgroup/@Usage = "INEQUALITY"
--                                                return string($col/@Name)')), '] [', ', '), '[', ''), ']', '')                                                                                                                                     AS INEQUALITY_COLUMNS,
--       Replace(Replace(Replace(CONVERT(NVARCHAR(max), index_nodeS.query('for $colgroup in .//sp:ColumnGroup,
--                                                $col in $colgroup/sp:Column
--                                                where $colgroup/@Usage = "INCLUDE"
--                                                return string($col/@Name)')), '] [', ', '), '[', ''), ']', '')                                                                                                                                     AS INCLUDED_COLUMNS 
--FROM sys.query_store_plan AS p 
--           CROSS APPLY (SELECT TRY_CONVERT(XML, p.query_plan) AS query_plan_xml) AS qpx   
--       CROSS APPLY qpx.query_plan_xml.nodes('//sp:MissingIndexes/sp:MissingIndexGroup/sp:MissingIndex') AS missing_indexes(index_nodeS)
--       CROSS APPLY qpx.query_plan_xml.nodes('//sp:Batch') AS Batch(index_node)
--WHERE 1=1  
--and p.query_plan like N'%<MissingIndexes>%'
