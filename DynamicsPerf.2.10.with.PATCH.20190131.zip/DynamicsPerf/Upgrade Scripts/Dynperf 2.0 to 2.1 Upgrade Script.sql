/*
Your collection schedule for DynamicsPerf will be set back to hourly after running 
this script.  If you wish to have the 5 minute schedule, run that from the install scripts. 
*/

GO
SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, CONCAT_NULL_YIELDS_NULL, QUOTED_IDENTIFIER ON;

SET NUMERIC_ROUNDABORT OFF;

GO

--REH drop all synonym's

declare @n char(1)
set @n = char(10)

declare @stmt nvarchar(max)

select @stmt = isnull( @stmt + @n, '' ) +
'drop synonym [' + SCHEMA_NAME(schema_id) + '].[' + name + ']'
from sys.synonyms

exec sp_executesql @stmt


GO
PRINT N'Dropping [dbo].[QUERY_PLANS].[IX_QUERY_MI_FLAG_PLAN_HANDLE]...';


GO
DROP INDEX [IX_QUERY_MI_FLAG_PLAN_HANDLE]
    ON [dbo].[QUERY_PLANS];


GO
PRINT N'Altering [dbo].[AX_INDEX_DETAIL]...';


GO
ALTER TABLE [dbo].[AX_INDEX_DETAIL] ALTER COLUMN [INDEX_DESCRIPTION] NVARCHAR (MAX) NOT NULL;

ALTER TABLE [dbo].[AX_INDEX_DETAIL] ALTER COLUMN [INDEX_NAME] NVARCHAR (128) NOT NULL;

ALTER TABLE [dbo].[AX_INDEX_DETAIL] ALTER COLUMN [TABLE_NAME] NVARCHAR (128) NOT NULL;


GO
PRINT N'Altering [dbo].[AX_TABLE_DETAIL]...';


GO
ALTER TABLE [dbo].[AX_TABLE_DETAIL] ALTER COLUMN [CLUSTERED_INDEX] NVARCHAR (256) NOT NULL;

ALTER TABLE [dbo].[AX_TABLE_DETAIL] ALTER COLUMN [COUNTRY_REGION_CODES] NVARCHAR (256) NOT NULL;

ALTER TABLE [dbo].[AX_TABLE_DETAIL] ALTER COLUMN [EXTENDS] NVARCHAR (256) NOT NULL;

ALTER TABLE [dbo].[AX_TABLE_DETAIL] ALTER COLUMN [PRIMARY_KEY] NVARCHAR (256) NOT NULL;

ALTER TABLE [dbo].[AX_TABLE_DETAIL] ALTER COLUMN [TABLE_NAME] NVARCHAR (256) NOT NULL;


GO
PRINT N'Altering [dbo].[DISKSTATS]...';


GO
ALTER TABLE [dbo].[DISKSTATS] ALTER COLUMN [SAMPLE_MS] BIGINT NOT NULL;


GO
PRINT N'Creating [dbo].[AX_BATCH_DETAILS]...';


GO
SET QUOTED_IDENTIFIER ON;

SET ANSI_NULLS OFF;

/****** Object:  Table [dbo].[AX_BATCH_DETAILS]    Script Date: 10/4/2018 5:08:17 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AX_BATCH_DETAILS]') AND type in (N'U'))
DROP TABLE [dbo].[AX_BATCH_DETAILS]
GO



GO
CREATE TABLE [dbo].[AX_BATCH_DETAILS] (
    [SERVER_NAME]     NVARCHAR (256) NOT NULL,
    [STATS_TIME]      DATETIME       NOT NULL,
    [DATABASE_NAME]   NVARCHAR (256) NOT NULL,
    [BATCHJOBID]      BIGINT         NOT NULL,
    [CAPTION]         NVARCHAR (512) NOT NULL,
    [COMPANY]         NVARCHAR (4)   NOT NULL,
    [STARTDATETIME]   DATETIME       NOT NULL,
    [ENDDATETIME]     DATETIME       NOT NULL,
    [SECONDS]         BIGINT         NULL,
    [STATUS]          INT            NOT NULL,
    [CREATEDDATETIME] DATETIME       NOT NULL
);


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Creating [dbo].[AX_BATCH_HISTORY]...';
/****** Object:  Table [dbo].[AX_BATCH_HISTORY]    Script Date: 10/4/2018 5:08:52 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AX_BATCH_HISTORY]') AND type in (N'U'))
DROP TABLE [dbo].[AX_BATCH_HISTORY]
GO



GO
CREATE TABLE [dbo].[AX_BATCH_HISTORY] (
    [SERVER_NAME]     NVARCHAR (256) NOT NULL,
    [DATABASE_NAME]   NVARCHAR (256) NOT NULL,
    [DATE]            DATE           NOT NULL,
    [BATCHJOBID]      BIGINT         NOT NULL,
    [EXECUTION_COUNT] BIGINT         NULL,
    [TOTAL_TIME]      BIGINT         NULL,
    [FLAG]            VARCHAR (1)    NULL
);


GO
PRINT N'Creating [dbo].[SQL_AO_AVAILABILITY_GROUP_LISTENERS]...';


GO
SET QUOTED_IDENTIFIER ON;

SET ANSI_NULLS OFF;

/****** Object:  Table [dbo].[SQL_AO_AVAILABILITY_GROUP_LISTENERS]    Script Date: 10/4/2018 5:09:30 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_AO_AVAILABILITY_GROUP_LISTENERS]') AND type in (N'U'))
DROP TABLE [dbo].[SQL_AO_AVAILABILITY_GROUP_LISTENERS]
GO


GO
CREATE TABLE [dbo].[SQL_AO_AVAILABILITY_GROUP_LISTENERS] (
    [SERVER_NAME]                          NVARCHAR (128)   NOT NULL,
    [STATS_TIME]                           DATETIME         NOT NULL,
    [group_id]                             UNIQUEIDENTIFIER NOT NULL,
    [listener_id]                          NVARCHAR (36)    NULL,
    [dns_name]                             NVARCHAR (63)    NULL,
    [port]                                 INT              NULL,
    [is_conformant]                        BIT              NOT NULL,
    [ip_configuration_string_from_cluster] NVARCHAR (4000)  NULL
);


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Creating [dbo].[SQL_AO_AVAILABILITY_GROUP_LISTENERS].[IX_AO_GROUP_LISTENER]...';


GO
CREATE CLUSTERED INDEX [IX_AO_GROUP_LISTENER]
    ON [dbo].[SQL_AO_AVAILABILITY_GROUP_LISTENERS]([SERVER_NAME] ASC, [STATS_TIME] ASC) WITH (DATA_COMPRESSION = ROW);


GO
PRINT N'Creating [dbo].[SQL_AO_AVAILABILITY_GROUP_STATES]...';


GO
SET QUOTED_IDENTIFIER ON;

SET ANSI_NULLS OFF;

/****** Object:  Table [dbo].[SQL_AO_AVAILABILITY_GROUP_STATES]    Script Date: 10/4/2018 5:09:58 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_AO_AVAILABILITY_GROUP_STATES]') AND type in (N'U'))
DROP TABLE [dbo].[SQL_AO_AVAILABILITY_GROUP_STATES]
GO


GO
CREATE TABLE [dbo].[SQL_AO_AVAILABILITY_GROUP_STATES] (
    [SERVER_NAME]                    NVARCHAR (128)   NOT NULL,
    [STATS_TIME]                     DATETIME         NOT NULL,
    [group_id]                       UNIQUEIDENTIFIER NOT NULL,
    [primary_replica]                NVARCHAR (128)   NULL,
    [primary_recovery_health]        TINYINT          NULL,
    [primary_recovery_health_desc]   NVARCHAR (60)    NULL,
    [secondary_recovery_health]      TINYINT          NULL,
    [secondary_recovery_health_desc] NVARCHAR (60)    NULL,
    [synchronization_health]         TINYINT          NULL,
    [synchronization_health_desc]    NVARCHAR (60)    NULL
);


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Creating [dbo].[SQL_AO_AVAILABILITY_GROUP_STATES].[IX_AO_AVAILABILITY_GROUP_STATES]...';


GO
CREATE CLUSTERED INDEX [IX_AO_AVAILABILITY_GROUP_STATES]
    ON [dbo].[SQL_AO_AVAILABILITY_GROUP_STATES]([SERVER_NAME] ASC, [STATS_TIME] ASC) WITH (DATA_COMPRESSION = ROW);


GO
PRINT N'Creating [dbo].[SQL_AO_AVAILABILITY_REPLICA_STATES]...';


GO
SET QUOTED_IDENTIFIER ON;

SET ANSI_NULLS OFF;

/****** Object:  Table [dbo].[SQL_AO_AVAILABILITY_REPLICA_STATES]    Script Date: 10/4/2018 5:10:20 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_AO_AVAILABILITY_REPLICA_STATES]') AND type in (N'U'))
DROP TABLE [dbo].[SQL_AO_AVAILABILITY_REPLICA_STATES]
GO


GO
CREATE TABLE [dbo].[SQL_AO_AVAILABILITY_REPLICA_STATES] (
    [SERVER_NAME]                    NVARCHAR (128)   NOT NULL,
    [STATS_TIME]                     DATETIME         NOT NULL,
    [replica_id]                     UNIQUEIDENTIFIER NOT NULL,
    [group_id]                       UNIQUEIDENTIFIER NOT NULL,
    [is_local]                       BIT              NOT NULL,
    [role]                           TINYINT          NULL,
    [role_desc]                      NVARCHAR (60)    NULL,
    [operational_state]              TINYINT          NULL,
    [operational_state_desc]         NVARCHAR (60)    NULL,
    [connected_state]                TINYINT          NULL,
    [connected_state_desc]           NVARCHAR (60)    NULL,
    [recovery_health]                TINYINT          NULL,
    [recovery_health_desc]           NVARCHAR (60)    NULL,
    [synchronization_health]         TINYINT          NULL,
    [synchronization_health_desc]    NVARCHAR (60)    NULL,
    [last_connect_error_number]      INT              NULL,
    [last_connect_error_description] NVARCHAR (1024)  NULL,
    [last_connect_error_timestamp]   DATETIME         NULL
);


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Creating [dbo].[SQL_AO_AVAILABILITY_REPLICA_STATES].[IX_AO_AVAILABILITY_REPLICA_STATES]...';


GO
CREATE CLUSTERED INDEX [IX_AO_AVAILABILITY_REPLICA_STATES]
    ON [dbo].[SQL_AO_AVAILABILITY_REPLICA_STATES]([SERVER_NAME] ASC, [STATS_TIME] ASC) WITH (DATA_COMPRESSION = ROW);


GO
PRINT N'Creating [dbo].[SQL_AO_AVAILABILITY_REPLICAS]...';


GO
SET QUOTED_IDENTIFIER ON;

SET ANSI_NULLS OFF;
/****** Object:  Table [dbo].[SQL_AO_AVAILABILITY_REPLICAS]    Script Date: 10/4/2018 5:10:41 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_AO_AVAILABILITY_REPLICAS]') AND type in (N'U'))
DROP TABLE [dbo].[SQL_AO_AVAILABILITY_REPLICAS]
GO



GO
CREATE TABLE [dbo].[SQL_AO_AVAILABILITY_REPLICAS] (
    [SERVER_NAME]                           NVARCHAR (128)   NOT NULL,
    [STATS_TIME]                            DATETIME         NOT NULL,
    [replica_id]                            UNIQUEIDENTIFIER NULL,
    [group_id]                              UNIQUEIDENTIFIER NULL,
    [replica_metadata_id]                   INT              NULL,
    [replica_server_name]                   NVARCHAR (256)   NULL,
    [owner_sid]                             VARBINARY (85)   NULL,
    [endpoint_url]                          NVARCHAR (256)   NULL,
    [availability_mode]                     TINYINT          NULL,
    [availability_mode_desc]                NVARCHAR (60)    NULL,
    [failover_mode]                         TINYINT          NULL,
    [failover_mode_desc]                    NVARCHAR (60)    NULL,
    [session_timeout]                       INT              NULL,
    [primary_role_allow_connections]        TINYINT          NULL,
    [primary_role_allow_connections_desc]   NVARCHAR (60)    NULL,
    [secondary_role_allow_connections]      TINYINT          NULL,
    [secondary_role_allow_connections_desc] NVARCHAR (60)    NULL,
    [create_date]                           DATETIME         NULL,
    [modify_date]                           DATETIME         NULL,
    [backup_priority]                       INT              NULL,
    [read_only_routing_url]                 NVARCHAR (256)   NULL
);


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Creating [dbo].[SQL_AO_AVAILABILITY_REPLICAS].[IX_AO_AVAILABILITY_REPLICAS]...';


GO
CREATE CLUSTERED INDEX [IX_AO_AVAILABILITY_REPLICAS]
    ON [dbo].[SQL_AO_AVAILABILITY_REPLICAS]([SERVER_NAME] ASC, [STATS_TIME] ASC) WITH (DATA_COMPRESSION = ROW);


GO
PRINT N'Creating [dbo].[SQL_AO_AVAILABILITYGROUPS]...';


GO
SET QUOTED_IDENTIFIER ON;

SET ANSI_NULLS OFF;

/****** Object:  Table [dbo].[SQL_AO_AVAILABILITYGROUPS]    Script Date: 10/4/2018 5:10:58 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_AO_AVAILABILITYGROUPS]') AND type in (N'U'))
DROP TABLE [dbo].[SQL_AO_AVAILABILITYGROUPS]
GO


GO
CREATE TABLE [dbo].[SQL_AO_AVAILABILITYGROUPS] (
    [SERVER_NAME]                      NVARCHAR (128)   NOT NULL,
    [STATS_TIME]                       DATETIME         NOT NULL,
    [group_id]                         UNIQUEIDENTIFIER NOT NULL,
    [name]                             [sysname]        NULL,
    [resource_id]                      NVARCHAR (40)    NULL,
    [resource_group_id]                NVARCHAR (40)    NULL,
    [failure_condition_level]          INT              NULL,
    [health_check_timeout]             INT              NULL,
    [automated_backup_preference]      TINYINT          NULL,
    [automated_backup_preference_desc] NVARCHAR (60)    NULL
);


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Creating [dbo].[SQL_AO_AVAILABILITYGROUPS].[IX_AO_AVAILABILITYGROUPS]...';


GO
CREATE CLUSTERED INDEX [IX_AO_AVAILABILITYGROUPS]
    ON [dbo].[SQL_AO_AVAILABILITYGROUPS]([SERVER_NAME] ASC, [STATS_TIME] ASC) WITH (DATA_COMPRESSION = ROW);


GO
PRINT N'Creating [dbo].[SQL_AO_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES]...';


GO
SET QUOTED_IDENTIFIER ON;

SET ANSI_NULLS OFF;

/****** Object:  Table [dbo].[SQL_AO_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES]    Script Date: 10/4/2018 5:11:19 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_AO_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES]') AND type in (N'U'))
DROP TABLE [dbo].[SQL_AO_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES]
GO


GO
CREATE TABLE [dbo].[SQL_AO_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES] (
    [SERVER_NAME]         NVARCHAR (128)   NOT NULL,
    [STATS_TIME]          DATETIME         NOT NULL,
    [replica_id]          UNIQUEIDENTIFIER NOT NULL,
    [replica_server_name] NVARCHAR (256)   NOT NULL,
    [group_id]            UNIQUEIDENTIFIER NOT NULL,
    [join_state]          TINYINT          NOT NULL,
    [join_state_desc]     NVARCHAR (60)    NULL
);


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Creating [dbo].[SQL_AO_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES].[IX_AO_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES]...';


GO
CREATE CLUSTERED INDEX [IX_AO_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES]
    ON [dbo].[SQL_AO_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES]([SERVER_NAME] ASC, [STATS_TIME] ASC) WITH (DATA_COMPRESSION = ROW);


GO
PRINT N'Creating [dbo].[SQL_AO_HADR_DATABASE_REPLICA_STATES]...';


GO
SET QUOTED_IDENTIFIER ON;

SET ANSI_NULLS OFF;

/****** Object:  Table [dbo].[SQL_AO_HADR_DATABASE_REPLICA_STATES]    Script Date: 10/4/2018 5:11:36 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_AO_HADR_DATABASE_REPLICA_STATES]') AND type in (N'U'))
DROP TABLE [dbo].[SQL_AO_HADR_DATABASE_REPLICA_STATES]
GO


GO
CREATE TABLE [dbo].[SQL_AO_HADR_DATABASE_REPLICA_STATES] (
    [SERVER_NAME]                 NVARCHAR (128)   NOT NULL,
    [STATS_TIME]                  DATETIME         NOT NULL,
    [database_id]                 INT              NOT NULL,
    [group_id]                    UNIQUEIDENTIFIER NOT NULL,
    [replica_id]                  UNIQUEIDENTIFIER NOT NULL,
    [group_database_id]           UNIQUEIDENTIFIER NOT NULL,
    [is_local]                    BIT              NULL,
    [synchronization_state]       TINYINT          NULL,
    [synchronization_state_desc]  NVARCHAR (60)    NULL,
    [is_commit_participant]       BIT              NULL,
    [synchronization_health]      TINYINT          NULL,
    [synchronization_health_desc] NVARCHAR (60)    NULL,
    [database_state]              TINYINT          NULL,
    [database_state_desc]         NVARCHAR (60)    NULL,
    [is_suspended]                BIT              NULL,
    [suspend_reason]              TINYINT          NULL,
    [suspend_reason_desc]         NVARCHAR (60)    NULL,
    [recovery_lsn]                NUMERIC (25)     NULL,
    [truncation_lsn]              NUMERIC (25)     NULL,
    [last_sent_lsn]               NUMERIC (25)     NULL,
    [last_sent_time]              DATETIME         NULL,
    [last_received_lsn]           NUMERIC (25)     NULL,
    [last_received_time]          DATETIME         NULL,
    [last_hardened_lsn]           NUMERIC (25)     NULL,
    [last_hardened_time]          DATETIME         NULL,
    [last_redone_lsn]             NUMERIC (25)     NULL,
    [last_redone_time]            DATETIME         NULL,
    [log_send_queue_size]         BIGINT           NULL,
    [log_send_rate]               BIGINT           NULL,
    [redo_queue_size]             BIGINT           NULL,
    [redo_rate]                   BIGINT           NULL,
    [filestream_send_rate]        BIGINT           NULL,
    [end_of_log_lsn]              NUMERIC (25)     NULL,
    [last_commit_lsn]             NUMERIC (25)     NULL,
    [last_commit_time]            DATETIME         NULL,
    [low_water_mark_for_ghosts]   BIGINT           NULL
);


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Creating [dbo].[SQL_AO_HADR_DATABASE_REPLICA_STATES].[IX_AO_HADR_DATABASE_REPLICA_STATES]...';


GO
CREATE CLUSTERED INDEX [IX_AO_HADR_DATABASE_REPLICA_STATES]
    ON [dbo].[SQL_AO_HADR_DATABASE_REPLICA_STATES]([SERVER_NAME] ASC, [STATS_TIME] ASC) WITH (DATA_COMPRESSION = ROW);


GO
PRINT N'Creating [dbo].[SQL_AO_HADR_DB_REPLICA_CLUSTER_STATES]...';


GO
SET QUOTED_IDENTIFIER ON;

SET ANSI_NULLS OFF;

/****** Object:  Table [dbo].[SQL_AO_HADR_DB_REPLICA_CLUSTER_STATES]    Script Date: 10/4/2018 5:11:53 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_AO_HADR_DB_REPLICA_CLUSTER_STATES]') AND type in (N'U'))
DROP TABLE [dbo].[SQL_AO_HADR_DB_REPLICA_CLUSTER_STATES]
GO


GO
CREATE TABLE [dbo].[SQL_AO_HADR_DB_REPLICA_CLUSTER_STATES] (
    [SERVER_NAME]                  [sysname]        NULL,
    [STATS_TIME]                   DATETIME         NULL,
    [replica_id]                   UNIQUEIDENTIFIER NOT NULL,
    [group_database_id]            UNIQUEIDENTIFIER NOT NULL,
    [database_name]                NVARCHAR (128)   NULL,
    [is_failover_ready]            BIT              NOT NULL,
    [is_pending_secondary_suspend] BIT              NOT NULL,
    [is_database_joined]           BIT              NOT NULL,
    [recovery_lsn]                 NUMERIC (25)     NULL,
    [truncation_lsn]               NUMERIC (25)     NULL
);


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Creating [dbo].[SQL_AO_HADR_DB_REPLICA_CLUSTER_STATES].[IX_AO_HADR_DB_REPLICA_CLUSTER_STATES]...';


GO
CREATE CLUSTERED INDEX [IX_AO_HADR_DB_REPLICA_CLUSTER_STATES]
    ON [dbo].[SQL_AO_HADR_DB_REPLICA_CLUSTER_STATES]([SERVER_NAME] ASC, [STATS_TIME] ASC) WITH (DATA_COMPRESSION = ROW);


GO
PRINT N'Creating [dbo].[SQL_AO_ROUTINGLISTS]...';


GO
SET QUOTED_IDENTIFIER ON;

SET ANSI_NULLS OFF;

/****** Object:  Table [dbo].[SQL_AO_ROUTINGLISTS]    Script Date: 10/4/2018 5:12:11 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_AO_ROUTINGLISTS]') AND type in (N'U'))
DROP TABLE [dbo].[SQL_AO_ROUTINGLISTS]
GO


GO
CREATE TABLE [dbo].[SQL_AO_ROUTINGLISTS] (
    [SERVER_NAME]          NVARCHAR (128)   NOT NULL,
    [STATS_TIME]           DATETIME         NOT NULL,
    [replica_id]           UNIQUEIDENTIFIER NOT NULL,
    [routing_priority]     INT              NOT NULL,
    [read_only_replica_id] UNIQUEIDENTIFIER NOT NULL
);


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Creating [dbo].[SQL_AO_ROUTINGLISTS].[IX_AO_ROUTINGLISTS]...';


GO
CREATE CLUSTERED INDEX [IX_AO_ROUTINGLISTS]
    ON [dbo].[SQL_AO_ROUTINGLISTS]([SERVER_NAME] ASC, [STATS_TIME] ASC) WITH (DATA_COMPRESSION = ROW);


GO
PRINT N'Creating [dbo].[SQL_DATABASE_SCOPECONFIG]...';


GO
SET QUOTED_IDENTIFIER ON;

SET ANSI_NULLS OFF;

/****** Object:  Table [dbo].[SQL_DATABASE_SCOPECONFIG]    Script Date: 10/4/2018 5:12:32 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SQL_DATABASE_SCOPECONFIG]') AND type in (N'U'))
DROP TABLE [dbo].[SQL_DATABASE_SCOPECONFIG]
GO


GO
CREATE TABLE [dbo].[SQL_DATABASE_SCOPECONFIG] (
    [SERVER_NAME]                     NVARCHAR (128) NOT NULL,
    [DATABASE_NAME]                   NVARCHAR (128) NOT NULL,
    [STATS_TIME]                      DATETIME       NOT NULL,
    [DB_SCOPED_LEGACY_CARDINALITY_ON] SQL_VARIANT    NOT NULL,
    [DB_SCOPED_MAXDOP]                SQL_VARIANT    NULL,
    [DB_SCOPED_PARAMETER_SNIFFING]    SQL_VARIANT    NULL,
    [DB_SCOPED_QUERY_OPTIMIZER_FIXES] SQL_VARIANT    NULL
);


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Creating [dbo].[QUERY_PLANS].[IX_QUERY_MI_FLAG_PLAN_HANDLE]...';


GO
CREATE NONCLUSTERED INDEX [IX_QUERY_MI_FLAG_PLAN_HANDLE]
    ON [dbo].[QUERY_PLANS]([MI_FLAG] ASC, [QUERY_PLAN_HASH] ASC, [SERVER_NAME] ASC, [DATABASE_NAME] ASC, [DATE_UPDATED] ASC) WITH (DATA_COMPRESSION = ROW);


GO
PRINT N'Creating [dbo].[QUERY_PLANS].[IX_QUERY_PLANS_DATE_UPDATED]...';

/****** Object:  Index [IX_QUERY_PLANS_DATE_UPDATED]    Script Date: 10/4/2018 5:19:00 PM ******/
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[QUERY_PLANS]') AND name = N'IX_QUERY_PLANS_DATE_UPDATED')
DROP INDEX [IX_QUERY_PLANS_DATE_UPDATED] ON [dbo].[QUERY_PLANS]
GO


GO
CREATE NONCLUSTERED INDEX [IX_QUERY_PLANS_DATE_UPDATED]
    ON [dbo].[QUERY_PLANS]([DATE_UPDATED] ASC, [SERVER_NAME] ASC, [DATABASE_NAME] ASC) WITH (DATA_COMPRESSION = ROW);


GO
PRINT N'Creating [dbo].[PARSE_PARAMS]...';


GO
/****** Object:  Trigger [PARSE_PARAMS]    Script Date: 10/4/2018 5:13:39 PM ******/
IF  EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[PARSE_PARAMS]'))
DROP TRIGGER [dbo].[PARSE_PARAMS]
GO


CREATE TRIGGER [dbo].[PARSE_PARAMS]
  ON  QUERY_PLANS 
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    
WITH XMLNAMESPACES ('http://schemas.microsoft.com/sqlserver/2004/07/showplan' AS sp)
UPDATE QP 
SET SQL_PARMS =  CONVERT (NVARCHAR(MAX), index_node.query('for $qplan in //sp:QueryPlan, $plist in $qplan/sp:ParameterList, $colref in $plist/sp:ColumnReference  return concat(string($colref/@Column),":",string($colref/@ParameterCompiledValue),",   "),"  "'))
FROM QUERY_PLANS QP INNER JOIN INSERTED INS ON QP.SERVER_NAME=INS.SERVER_NAME AND QP.DATABASE_NAME=INS.DATABASE_NAME
AND QP.QUERY_PLAN_HASH=INS.QUERY_PLAN_HASH
OUTER APPLY QP.QUERY_PLAN.nodes('//sp:Batch') AS Batch(index_node)


END
GO
PRINT N'Refreshing [dbo].[AX_INDEX_DETAIL_VW]...';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER OFF;


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[AX_INDEX_DETAIL_VW]';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Refreshing [dbo].[AX_DATABASELOGGING_VW]...';


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[AX_DATABASELOGGING_VW]';


GO
PRINT N'Refreshing [dbo].[AX_TABLE_DETAIL_VW]...';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER OFF;


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[AX_TABLE_DETAIL_VW]';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Refreshing [dbo].[QUERY_PLANS_VW]...';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER OFF;


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[QUERY_PLANS_VW]';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Refreshing [dbo].[MISSING_INDEXES_HISTORY_VW]...';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER OFF;


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[MISSING_INDEXES_HISTORY_VW]';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Refreshing [dbo].[QUERY_ALERTS_VW]...';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER OFF;


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[QUERY_ALERTS_VW]';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Refreshing [dbo].[QUERY_HISTORY_VW]...';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER OFF;


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[QUERY_HISTORY_VW]';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Refreshing [dbo].[QUERY_PLANS_PARSED_VW]...';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER OFF;


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[QUERY_PLANS_PARSED_VW]';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Refreshing [dbo].[QUERY_STATS_CTE_VW]...';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER OFF;


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[QUERY_STATS_CTE_VW]';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Altering [dbo].[QUERY_STATS_CURR_VW]...';


GO

ALTER VIEW [dbo].[QUERY_STATS_CURR_VW]
AS

WITH XMLNAMESPACES ('http://schemas.microsoft.com/sqlserver/2004/07/showplan' AS sp)
SELECT Q.SERVER_NAME,
       Q.DATABASE_NAME,
       CREATION_TIME                                                                                                AS COMPILED_TIME,
       EXECUTION_COUNT,
       EXECUTION_COUNT / CASE ( datediff(HOUR, CREATION_TIME, S.STATS_TIME) )
                           WHEN 0 THEN 1
                           ELSE ( datediff(HOUR, CREATION_TIME, S.STATS_TIME) )
                         END                                                                                        AS EXECUTION_PER_HOUR,
       cast(TOTAL_ELAPSED_TIME / 1000.000 AS DECIMAL(29, 3))                                                        AS TOTAL_ELAPSED_TIME,
       Q.AVG_TIME_MS                                                                                                AS AVG_ELAPSED_TIME,
       cast(MAX_ELAPSED_TIME / 1000.000 AS DECIMAL(29, 3))                                                          AS MAX_ELAPSED_TIME,
       AVG_LOGICAL_READS = TOTAL_LOGICAL_READS / EXECUTION_COUNT,
       AVG_LOGICAL_READS_MB = (TOTAL_LOGICAL_READS / EXECUTION_COUNT)*8/1024,
	   cast(TOTAL_ELAPSED_TIME / 1000.000 AS DECIMAL(29, 3)) - cast(TOTAL_WORKER_TIME / 1000.000 AS DECIMAL(29, 3)) AS TOTAL_WAIT_TIME,
       AVG_ROWS_RETURNED = TOTAL_ROWS / EXECUTION_COUNT,
       REPLACE(REPLACE(REPLACE(QT.SQL_TEXT, 'SELECT ', CHAR(10)+'SELECT '), ' FROM', CHAR(10)+' FROM'), ' WHERE', CHAR(10)+ ' WHERE')+
	   REPLICATE('-',50)+'TABLE NODES FROM QUERY PLAN' + REPLICATE('-',50) + CHAR(10) + ISNULL((SELECT QUERY_NODES FROM QUERY_PLANS_VW QPV WHERE Q.SERVER_NAME = QPV.SERVER_NAME AND Q.DATABASE_NAME = QPV.DATABASE_NAME AND Q.QUERY_PLAN_HASH = QPV.QUERY_PLAN_HASH),'')   AS QUERY_PLAN_PARSED,
        ISNULL((SELECT MISSING_INDEX_INFO FROM QUERY_PLANS_MISSING_INDEX_VW QPV WHERE Q.SERVER_NAME = QPV.SERVER_NAME AND Q.DATABASE_NAME = QPV.DATABASE_NAME AND Q.QUERY_PLAN_HASH = QPV.QUERY_PLAN_HASH),'')   AS MISSING_INDEXES,
	   
	   CASE  QP.SQL_PARMS WHEN NULL THEN 
	   CONVERT (NVARCHAR(MAX), index_node.query('for $qplan in //sp:QueryPlan, $plist in $qplan/sp:ParameterList, $colref in $plist/sp:ColumnReference  return concat(string($colref/@Column),":",string($colref/@ParameterCompiledValue),",   "),"  "')) 
		ELSE QP.SQL_PARMS END  AS QUERY_PARAMETER_VALUES,
	  
	   -- QP.SQL_PARMS  AS QUERY_PARAMETER_VALUES,                                                                                                                                                                   
       QUERY_PLAN,
       Q.ROW_NUM,
       Q.QUERY_HASH,
       QT.SQL_TEXT AS SQL_TEXT,
	   TOTAL_ROWS,
       MAX_ROWS,
       MIN_ROWS,
       PLAN_GENERATION_NUM,
       Q.LAST_EXECUTION_TIME,
       cast(TOTAL_WORKER_TIME / 1000.000 AS DECIMAL(29, 3))                                                         AS TOTAL_WORKER_TIME,
       AVG_PHYSICAL_READS = TOTAL_PHYSICAL_READS / EXECUTION_COUNT,
       AVG_LOGICAL_WRITES = TOTAL_LOGICAL_WRITES / EXECUTION_COUNT,
       cast(LAST_ELAPSED_TIME / 1000.000 AS DECIMAL(29, 3))                                                         AS LAST_ELAPSED_TIME,
       cast(MIN_ELAPSED_TIME / 1000.000 AS DECIMAL(29, 3))                                                          AS MIN_ELAPSED_TIME,
       TOTAL_PHYSICAL_READS,
       LAST_PHYSICAL_READS,
       MIN_PHYSICAL_READS,
       MAX_PHYSICAL_READS,
       TOTAL_LOGICAL_READS,
       LAST_LOGICAL_READS,
       MIN_LOGICAL_READS,
       MAX_LOGICAL_READS,
       TOTAL_LOGICAL_WRITES,
       LAST_LOGICAL_WRITES,
       MIN_LOGICAL_WRITES,
       MAX_LOGICAL_WRITES,
       cast(LAST_WORKER_TIME / 1000.000 AS DECIMAL(29, 3))                                                          AS LAST_WORKER_TIME,
       cast(MIN_WORKER_TIME / 1000.000 AS DECIMAL(29, 3))                                                           AS MIN_WORKER_TIME,
       cast(MAX_WORKER_TIME / 1000.000 AS DECIMAL(29, 3))                                                           AS MAX_WORKER_TIME,
       QUERY_PLAN_TEXT = CONVERT(NVARCHAR(MAX), QUERY_PLAN),
       S.STATS_TIME,
       SQL_VERSION,
       S.SQL_SERVER_STARTTIME,
       Q.QUERY_PLAN_HASH,
       C.COMMENT
FROM   (SELECT QS2.SERVER_NAME,
               QS2.DATABASE_NAME,
               QUERY_HASH,
               max(QS2.STATS_TIME)      AS STATS_TIME,
               max(LAST_EXECUTION_TIME) AS LAST_EXECUTION_TIME
        FROM   QUERY_STATS QS2
               INNER JOIN STATS_COLLECTION_SUMMARY S2 WITH (NOLOCK)
                       ON QS2.STATS_TIME = S2.STATS_TIME
                          AND QS2.DATABASE_NAME = S2.DATABASE_NAME
                          AND QS2.SERVER_NAME = S2.SERVER_NAME
                          
        GROUP  BY QS2.SERVER_NAME,
                  QS2.DATABASE_NAME,
                  QUERY_HASH,
				  QUERY_PLAN_HASH) AS A
       INNER LOOP JOIN QUERY_STATS Q WITH (NOLOCK)
                    ON A.SERVER_NAME = Q.SERVER_NAME
                       AND A.DATABASE_NAME = Q.DATABASE_NAME
                       AND A.QUERY_HASH = Q.QUERY_HASH
                       AND A.LAST_EXECUTION_TIME = Q.LAST_EXECUTION_TIME
                       AND A.STATS_TIME = Q.STATS_TIME
       LEFT OUTER JOIN QUERY_PLANS QP WITH (NOLOCK)
               ON QP.QUERY_PLAN_HASH = Q.QUERY_PLAN_HASH
                  AND QP.SERVER_NAME = Q.SERVER_NAME
                  AND QP.DATABASE_NAME = Q.DATABASE_NAME
       INNER JOIN STATS_COLLECTION_SUMMARY S WITH (NOLOCK)
               ON Q.STATS_TIME = S.STATS_TIME
                  AND Q.DATABASE_NAME = S.DATABASE_NAME
                  AND Q.SERVER_NAME = S.SERVER_NAME
       LEFT OUTER JOIN QUERY_TEXT AS QT
                    ON Q.QUERY_HASH = QT.QUERY_HASH
                       AND Q.DATABASE_NAME = QT.DATABASE_NAME
                       AND Q.SERVER_NAME = QT.SERVER_NAME
       LEFT OUTER JOIN COMMENTS C
                    ON Q.QUERY_HASH = C.QUERY_HASH
                       AND Q.SERVER_NAME = C.SERVER_NAME
                       AND Q.DATABASE_NAME = C.DATABASE_NAME
		OUTER APPLY QUERY_PLAN.nodes('//sp:Batch') AS Batch(index_node)
GO
PRINT N'Refreshing [dbo].[QUERY_STATS_VW]...';


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[QUERY_STATS_VW]';


GO
PRINT N'Refreshing [dbo].[HIDDEN_SCANS_CURR_VW]...';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER OFF;


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[HIDDEN_SCANS_CURR_VW]';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Refreshing [dbo].[USER_SCANS_CURR_VW]...';


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[USER_SCANS_CURR_VW]';


GO
PRINT N'Refreshing [dbo].[DISKSTATS_CURR_VW]...';


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[DISKSTATS_CURR_VW]';


GO
PRINT N'Refreshing [dbo].[DISKSTATS_VW]...';


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[DISKSTATS_VW]';


GO
PRINT N'Refreshing [dbo].[PERF_HOURLY_DISKSTATS_VW]...';


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[PERF_HOURLY_DISKSTATS_VW]';


GO
PRINT N'Altering [dbo].[AX_SQLTRACE_VW]...';


GO
SET ANSI_NULLS ON;

SET QUOTED_IDENTIFIER OFF;


GO


ALTER VIEW [dbo].[AX_SQLTRACE_VW]
AS

SELECT T.SERVER_NAME,
       T.STATS_TIME,
       T.DATABASE_NAME,
       TRACE_CATEGORY = CASE TRACE_CATEGORY
                          WHEN 0 THEN 'Statement'
                          WHEN 1 THEN 'QueryTime'
                          WHEN 2 THEN 'Error'
                          WHEN 3 THEN 'Synchronize'
                          WHEN 4 THEN 'Deadlock'
                          WHEN 5 THEN 'Warning'
                          ELSE str(TRACE_CATEGORY)
                        END,
       SQL_TYPE = CASE SQL_TYPE
                    WHEN 0 THEN 'UPDATE'
                    WHEN 1 THEN 'DELETE'
                    WHEN 2 THEN 'INSERT'
                    WHEN 3 THEN 'SELECT'
                    WHEN 4 THEN 'DDL'
                    WHEN 5 THEN 'PROC'
                    WHEN 6 THEN 'Other'
                    ELSE str(SQL_TYPE)
                  END,
       SQL_TEXT,
       SQL_DURATION,
       CALL_STACK,
       TRACE_EVENT_CODE,
       TRACE_EVENT_DESC,
       TRACE_EVENT_DETAILS,
       CONNECTION_TYPE,
       SQL_SESSION_ID,
      -- AX_USER_ID,
	   AX_USER_ID + ' ' + isnull(U.NAME, '') AS AX_USER_ID,
       AX_CONNECTION_ID,
       IS_LOBS_INCLUDED,
       IS_MORE_DATA_PENDING,
       ROWS_AFFECTED,
       ROW_SIZE,
       ROWS_PER_FETCH,
       IS_SELECTED_FOR_UPDATE,
       IS_STARTED_WITHIN_TRANSACTION,
       STATEMENT_ID,
       STATEMENT_REUSE_COUNT,
       DETAIL_TYPE,
       CREATED_DATETIME
FROM   AX_SQLTRACE T 
LEFT JOIN AX_USERINFO U ON T.AX_USER_ID = U.Id
GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Altering [dbo].[INDEX_KEY_ORDER_VW]...';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER OFF;


GO
ALTER VIEW [dbo].[INDEX_KEY_ORDER_VW]
AS
	 WITH CTE (SERVER_NAME, DATABASE_NAME, TABLENAME, INDEXNAME, ROWS, KEYCOLUMN, COLUMNS, PREV_COL)
       AS (SELECT IDV.SERVER_NAME,
                  IDV.DATABASE_NAME,
                  TABLENAME,
                  INDEXNAME,
                  Cast(1 / DENSITY AS BIGINT)                                        AS ROWS,
                  Replace(Replace(COLUMNS, Lag(COLUMNS, 1, '')
                                             OVER (
                                               PARTITION BY IDV.SERVER_NAME, IDV.DATABASE_NAME, TABLENAME, INDEXNAME
                                               ORDER BY Len(COLUMNS)), ''), ',', '') AS KEYCOLUMN,
                  COLUMNS,
                  Lag(COLUMNS, 1, '')
                    OVER (
                      PARTITION BY  IDV.SERVER_NAME, IDV.DATABASE_NAME, TABLENAME, INDEXNAME
                      ORDER BY Len(COLUMNS))                                         AS PREV_COL
           FROM   INDEX_DENSITY_VECTOR IDV
                  INNER JOIN INDEX_STATS_CURR_VW CV
                          ON IDV.DATABASE_NAME = CV.DATABASE_NAME
                             AND IDV.TABLENAME = CV.TABLE_NAME
                             AND IDV.INDEXNAME = CV.INDEX_NAME
                             --WHERE  IDV.TABLENAME = 'INVENTTRANS'
                             AND Len(IDV.COLUMNS) <= Len(CV.INDEX_KEYS) --REH for places where SQL has added the clustered index columns to the density vector
                             AND INDEXNAME NOT LIKE '_wa%') --REH Auto Stats indexes
  SELECT SERVER_NAME,
         DATABASE_NAME,
         TABLENAME,
         INDEXNAME,
         ROWS,
         KEYCOLUMN,
         COLUMNS,
         CASE KEYCOLUMN
           WHEN 'PARTITION' THEN -2
           WHEN 'DATAAREAID' THEN -1
           ELSE Cast (ROWS - Lag(ROWS, 1, 0)
                               OVER (
                                 PARTITION BY TABLENAME, INDEXNAME
                                 ORDER BY Len(COLUMNS)) AS BIGINT)
         END AS TOTAL_ROWS
  FROM   CTE
--ORDER BY TABLENAME,INDEXNAME, TOTAL_ROWS DESC
GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Creating [dbo].[AX_BATCHJOB_DETAILS_VW]...';

/****** Object:  View [dbo].[AX_BATCHJOB_DETAILS_VW]    Script Date: 10/4/2018 5:14:57 PM ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[AX_BATCHJOB_DETAILS_VW]'))
DROP VIEW [dbo].[AX_BATCHJOB_DETAILS_VW]
GO


CREATE VIEW [dbo].[AX_BATCHJOB_DETAILS_VW]
	AS 

	SELECT * FROM AX_BATCH_DETAILS
GO
PRINT N'Creating [dbo].[AX_BATCHJOB_HISTORY_VW]...';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
/****** Object:  View [dbo].[AX_BATCHJOB_HISTORY_VW]    Script Date: 10/4/2018 5:15:19 PM ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[AX_BATCHJOB_HISTORY_VW]'))
DROP VIEW [dbo].[AX_BATCHJOB_HISTORY_VW]
GO


CREATE VIEW [dbo].[AX_BATCHJOB_HISTORY_VW]
	AS 

	SELECT SERVER_NAME,
       DATABASE_NAME,
       DATE,
       BATCHJOBID,
       (SELECT TOP 1 CAPTION
        FROM   AX_BATCH_DETAILS AD
        WHERE  AD.SERVER_NAME = AH.SERVER_NAME
               AND AD.DATABASE_NAME = AH.DATABASE_NAME
               AND AD.BATCHJOBID = AH.BATCHJOBID
        ORDER  BY CREATEDDATETIME DESC) AS CAPTION,
       EXECUTION_COUNT,
       TOTAL_TIME,
       TOTAL_TIME / EXECUTION_COUNT     AS AVG_TIME,
       CASE FLAG
         WHEN 'M' THEN (SELECT MAX(TOTAL_TIME)
                        FROM   AX_BATCH_DETAILS AD
                        WHERE  AD.SERVER_NAME = AH.SERVER_NAME
                               AND AD.DATABASE_NAME = AH.DATABASE_NAME
                               AND AH.FLAG = 'M'
                               AND AD.BATCHJOBID = AH.BATCHJOBID
                               AND DATEADD(MONTH, DATEDIFF(MONTH, 0, AD.ENDDATETIME), 0) = AH.DATE
                        GROUP  BY AD.SERVER_NAME,
                                  AD.DATABASE_NAME,
                                  DATEADD(MONTH, DATEDIFF(MONTH, 0, AD.ENDDATETIME), 0))
         ELSE (SELECT MAX(TOTAL_TIME)
               FROM   AX_BATCH_DETAILS AD
               WHERE  AD.SERVER_NAME = AH.SERVER_NAME
                      AND AD.DATABASE_NAME = AH.DATABASE_NAME
                      AND AH.FLAG = 'D'
                      AND AD.BATCHJOBID = AH.BATCHJOBID
                      AND DATEADD(DAY, DATEDIFF(DAY, 0, AD.ENDDATETIME), 0) = AH.DATE
               GROUP  BY AD.SERVER_NAME,
                         AD.DATABASE_NAME,
                         DATEADD(DAY, DATEDIFF(DAY, 0, AD.ENDDATETIME), 0))
       END                              AS MAX_TIME,
       FLAG
FROM   AX_BATCH_HISTORY AH
GROUP  BY SERVER_NAME,
          DATABASE_NAME,
          DATE,
          BATCHJOBID,
          EXECUTION_COUNT,
          TOTAL_TIME,
          TOTAL_TIME / EXECUTION_COUNT,
          FLAG 

GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Creating [dbo].[INDEX_STATS_OPS_VW]...';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER OFF;

/****** Object:  View [dbo].[INDEX_STATS_OPS_VW]    Script Date: 10/4/2018 5:15:43 PM ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[INDEX_STATS_OPS_VW]'))
DROP VIEW [dbo].[INDEX_STATS_OPS_VW]
GO


GO
CREATE VIEW [dbo].[INDEX_STATS_OPS_VW]
	AS 
	

WITH INDEX_CTE (SERVER_NAME, DATABASE_NAME, STATS_TIME, TABLE_NAME,totalreadoperations, totalwriteoperations, totaloperations, ROW_COUNT
)
     AS (


SELECT SERVER_NAME,DATABASE_NAME, STATS_TIME,
       TABLE_NAME,
       ISNULL(SUM(USER_SEEKS + USER_SCANS + USER_LOOKUPS),0) AS totalreadoperations,
       ISNULL(SUM(USER_UPDATES),0)                           AS totalwriteoperations,
       ISNULL(SUM(USER_UPDATES + USER_SEEKS + USER_SCANS
           + USER_LOOKUPS),0)                                AS totaloperations,
		   MAX(ROW_COUNT) AS ROW_COUNT  
     FROM   INDEX_STATS_VW ISV
WHERE 1=1 
GROUP  BY SERVER_NAME,
          DATABASE_NAME,
		  STATS_TIME,
          TABLE_NAME
 )

SELECT *, 
 LAG(totalreadoperations, 1, 0)
                           OVER (
                             PARTITION BY SERVER_NAME, DATABASE_NAME, TABLE_NAME
                             ORDER BY STATS_TIME )                      AS PREV_READS
, LAG(totalwriteoperations, 1, 0)
                           OVER (
                             PARTITION BY SERVER_NAME, DATABASE_NAME, TABLE_NAME
                             ORDER BY STATS_TIME )                      AS PREV_WRITES							 
 , LAG(totaloperations, 1, 0)
                           OVER (
                             PARTITION BY SERVER_NAME, DATABASE_NAME, TABLE_NAME
                             ORDER BY STATS_TIME )                      AS PREV_TOTAL
 , LAG(ROW_COUNT, 1, 0)
                           OVER (
                             PARTITION BY SERVER_NAME, DATABASE_NAME, TABLE_NAME
                             ORDER BY STATS_TIME )                      AS PREV_ROWS

 FROM INDEX_CTE
GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Creating [dbo].[REPLICA_ROLLUPSTATE]...';

/****** Object:  View [dbo].[REPLICA_ROLLUPSTATE]    Script Date: 10/4/2018 5:16:06 PM ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[REPLICA_ROLLUPSTATE]'))
DROP VIEW [dbo].[REPLICA_ROLLUPSTATE]
GO


GO
CREATE VIEW [dbo].[REPLICA_ROLLUPSTATE]
	AS 

	--REH used by SQL_AG_REPLICAS_CURR_VW view

SELECT DISTINCT am1.server_name, am1.replica_id, am1.role, (case when (am1.synchronization_health is null) then 3 else am1.synchronization_health end) as sync_state, (case when (am1.availability_mode is NULL) or (am3.availability_mode is NULL) then null when (am1.role = 1) then 1 when (am1.availability_mode = 0 or am3.availability_mode = 0) then 0 else 1 end) as effective_availability_mode
	  
	  
from (select ar.server_name, ar.group_id, ar.replica_id, ar.replica_server_name, ar.availability_mode, (case when UPPER(ags.primary_replica) = UPPER(ar.replica_server_name) then 1 else 0 end) as role, ars.synchronization_health 

from SQL_AO_AVAILABILITY_REPLICAS as ar
      left join SQL_AO_AVAILABILITY_GROUP_STATES as ags on ags.group_id = ar.group_id and ags.SERVER_NAME = ar.SERVER_NAME
      left join SQL_AO_AVAILABILITY_REPLICA_STATES as ars on ar.group_id = ars.group_id and ar.replica_id = ars.replica_id and ars.SERVER_NAME = ar.SERVER_NAME) as am1 
	  left join (select server_name, group_id, role, availability_mode from (select ar.server_name,ar.group_id, ar.replica_id, ar.replica_server_name, ar.availability_mode, (case when UPPER(ags.primary_replica) = UPPER(ar.replica_server_name) then 1 else 0 end) as role, ars.synchronization_health 

from SQL_AO_AVAILABILITY_REPLICAS as ar
      left join SQL_AO_AVAILABILITY_GROUP_STATES as ags on ags.group_id = ar.group_id and ags.SERVER_NAME = ar.SERVER_NAME
      left join SQL_AO_AVAILABILITY_REPLICA_STATES as ars on ar.group_id = ars.group_id and ar.replica_id = ars.replica_id and ar.SERVER_NAME = ars.SERVER_NAME
	  
	  WHERE AR.STATS_TIME IN (SELECT MAX(STATS_TIME) FROM SQL_AO_AVAILABILITYGROUPS AO WHERE AO.SERVER_NAME = AR.SERVER_NAME)
	  ) as am2 where am2.role = 1) as am3 on am1.group_id = am3.group_id and am1.SERVER_NAME = am3.server_name
GO
PRINT N'Creating [dbo].[SQL_AG_LISTENERS_CURR_VW]...';

/****** Object:  View [dbo].[SQL_AG_LISTENERS_CURR_VW]    Script Date: 10/4/2018 5:16:29 PM ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SQL_AG_LISTENERS_CURR_VW]'))
DROP VIEW [dbo].[SQL_AG_LISTENERS_CURR_VW]
GO


GO
CREATE VIEW [dbo].[SQL_AG_LISTENERS_CURR_VW]
	AS 

	
SELECT DISTINCT 

AGL.dns_name AS [Name],
'Server[@Name=' + quotename(AG.SERVER_NAME,'''') + ']' + '/AvailabilityGroup[@Name=' + quotename(AG.name,'''') + ']' AS [Urn],
ISNULL(AGL.port, -1) AS [PortNumber],
AGL.is_conformant AS [IsConformant],
ISNULL(AGL.ip_configuration_string_from_cluster, N'') AS [ClusterIPConfiguration]
FROM
SQL_AO_AVAILABILITYGROUPS AS AG
INNER JOIN SQL_AO_AVAILABILITY_GROUP_LISTENERS AS AGL ON AGL.group_id=AG.group_id AND AGL.SERVER_NAME = AG.SERVER_NAME
WHERE AG.STATS_TIME IN (SELECT MAX(STATS_TIME) FROM SQL_AO_AVAILABILITYGROUPS AO WHERE AO.SERVER_NAME = AG.SERVER_NAME)
GO
PRINT N'Creating [dbo].[SQL_AG_READONLY_ROUTING_LIST_CURR_VW]...';

/****** Object:  View [dbo].[SQL_AG_READONLY_ROUTING_LIST_CURR_VW]    Script Date: 10/4/2018 5:16:45 PM ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SQL_AG_READONLY_ROUTING_LIST_CURR_VW]'))
DROP VIEW [dbo].[SQL_AG_READONLY_ROUTING_LIST_CURR_VW]
GO


GO
CREATE VIEW [dbo].[SQL_AG_READONLY_ROUTING_LIST_CURR_VW]
	AS

	SELECT DISTINCT AG.SERVER_NAME as SERVER_NAME,
	   ag.name as 'Availability Group', ar.replica_server_name as 'When Primary Replica Is',
        rl.routing_priority as 'Routing Priority', ar2.replica_server_name as 'RO Routed To', 
        ar.secondary_role_allow_connections_desc, ar2.read_only_routing_url
FROM SQL_AO_ROUTINGLISTS rl 
        inner join SQL_AO_AVAILABILITY_REPLICAS ar on rl.replica_id = ar.replica_id AND AR.SERVER_NAME = rl.SERVER_NAME
        inner join SQL_AO_AVAILABILITY_REPLICAS ar2 on rl.read_only_replica_id = ar2.replica_id AND rl.SERVER_NAME = ar2.SERVER_NAME
        inner join SQL_AO_AVAILABILITYGROUPS ag on ar.group_id = ag.group_id AND ar.SERVER_NAME = ag.SERVER_NAME
		
WHERE AG.STATS_TIME IN (SELECT MAX(STATS_TIME) FROM SQL_AO_AVAILABILITYGROUPS AO WHERE AO.SERVER_NAME = AG.SERVER_NAME)
GO
PRINT N'Creating [dbo].[SQL_AG_REPLICAS_CURR_VW]...';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER OFF;

/****** Object:  View [dbo].[SQL_AG_REPLICAS_CURR_VW]    Script Date: 10/4/2018 5:17:00 PM ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SQL_AG_REPLICAS_CURR_VW]'))
DROP VIEW [dbo].[SQL_AG_REPLICAS_CURR_VW]
GO


GO
CREATE VIEW [dbo].[SQL_AG_REPLICAS_CURR_VW]
	AS

	
SELECT  distinct AG.SERVER_NAME as SERVER_NAME,
AR.replica_server_name AS [Name],
'Server[@Name=' + quotename(AG.SERVER_NAME,'''') + ']' + '/AvailabilityGroup[@Name=' + quotename(AG.name,'''') + ']' AS [Urn],
ISNULL(arstates.role_desc, 3) AS [Role],
ISNULL(AR.primary_role_allow_connections_desc, 4) AS [ConnectionModeInPrimaryRole],
ISNULL(AR.secondary_role_allow_connections_desc, 3) AS [ConnectionModeInSecondaryRole],
ISNULL(arstates.connected_state_desc, 2) AS [ConnectionState],
(case when arrollupstates.sync_state = 3 then 3 when (arrollupstates.effective_availability_mode = 1 or arrollupstates.role = 1) then arrollupstates.sync_state when arrollupstates.sync_state = 2 then 1 else 0 end) AS [RollupSynchronizationState],
ISNULL(arcs.join_state_desc, 99) AS [JoinState]
FROM
SQL_AO_AVAILABILITYGROUPS AS AG
INNER JOIN SQL_AO_AVAILABILITY_REPLICAS AS AR ON (AR.replica_server_name IS NOT NULL) AND (AR.group_id=AG.group_id and AR.SERVER_NAME = ag.SERVER_NAME)
LEFT OUTER JOIN SQL_AO_AVAILABILITY_REPLICA_STATES AS arstates ON AR.replica_id = arstates.replica_id and ar.SERVER_NAME = arstates.SERVER_NAME
LEFT OUTER JOIN replica_rollupstate AS arrollupstates ON AR.replica_id = arrollupstates.replica_id and ar.SERVER_NAME = arrollupstates.SERVER_NAME
LEFT OUTER JOIN SQL_AO_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES AS arcs ON AR.replica_id = arcs.replica_id and AR.SERVER_NAME = arcs.SERVER_NAME
WHERE AG.STATS_TIME IN (SELECT MAX(STATS_TIME) FROM SQL_AO_AVAILABILITYGROUPS AO WHERE AO.SERVER_NAME = AG.SERVER_NAME)
GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Creating [dbo].[SQL_AVAILABILITY_DATABASESES_CURR_VW]...';

/****** Object:  View [dbo].[SQL_AVAILABILITY_DATABASESES_CURR_VW]    Script Date: 10/4/2018 5:17:16 PM ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SQL_AVAILABILITY_DATABASESES_CURR_VW]'))
DROP VIEW [dbo].[SQL_AVAILABILITY_DATABASESES_CURR_VW]
GO


GO
CREATE VIEW [dbo].[SQL_AVAILABILITY_DATABASESES_CURR_VW]
	AS 

	SELECT DISTINCT
ag.SERVER_NAME as Server_Name,
dbcs.database_name AS [Name],
'Server[@Name=' + quotename(AG.SERVER_NAME,'''') + ']' + '/AvailabilityGroup[@Name=' + quotename(AG.name,'''') + ']' AS [Urn],
ISNULL(dbrs.synchronization_state_desc,'unknown') AS [SynchronizationState],
ISNULL(dbrs.is_suspended, 0) AS [IsSuspended],
ISNULL(dbcs.is_database_joined, 0) AS [IsJoined]
FROM
SQL_AO_AVAILABILITYGROUPS AS AG
INNER JOIN SQL_AO_AVAILABILITY_REPLICAS AS AR ON AR.group_id=AG.group_id AND AR.SERVER_NAME = AG.SERVER_NAME
INNER JOIN SQL_AO_AVAILABILITY_REPLICA_STATES AS arstates ON AR.replica_id = arstates.replica_id AND arstates.is_local = 1 AND AR.SERVER_NAME = ARSTATES.SERVER_NAME
INNER JOIN SQL_AO_HADR_DB_REPLICA_CLUSTER_STATES AS dbcs ON arstates.replica_id = dbcs.replica_id AND DBCS.SERVER_NAME = ARSTATES.SERVER_NAME
LEFT OUTER JOIN SQL_AO_HADR_DATABASE_REPLICA_STATES AS dbrs ON dbcs.replica_id = dbrs.replica_id AND dbcs.group_database_id = dbrs.group_database_id
AND DBRS.SERVER_NAME = DBCS.SERVER_NAME
WHERE AG.STATS_TIME IN (SELECT MAX(STATS_TIME) FROM SQL_AO_AVAILABILITYGROUPS AO WHERE AO.SERVER_NAME = AG.SERVER_NAME)
GO
PRINT N'Creating [dbo].[SQL_AVAILABILITY_GROUPS_CURR_VW]...';

/****** Object:  View [dbo].[SQL_AVAILABILITY_GROUPS_CURR_VW]    Script Date: 10/4/2018 5:17:30 PM ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SQL_AVAILABILITY_GROUPS_CURR_VW]'))
DROP VIEW [dbo].[SQL_AVAILABILITY_GROUPS_CURR_VW]
GO


GO
CREATE VIEW [dbo].[SQL_AVAILABILITY_GROUPS_CURR_VW]
	AS 
	
SELECT DISTINCT
AG.SERVER_NAME AS SERVER_NAME,
ag.STATS_TIME,
AG.name AS [NAME],
'Server[@Name=' + quotename(AG.SERVER_NAME,'''') + ']' + '/AvailabilityGroup[@Name=' + quotename(AG.name,'''') + ']' AS [Urn],
ISNULL(agstates.primary_replica, '') AS [PrimaryReplicaServerName],
ISNULL(arstates2.role_desc, 3) AS [LocalReplicaRole],
ISNULL(arstates2.operational_state_desc, 3) AS [LocalOperationalState],
ISNULL(arstates2.synchronization_health_desc, 3) AS [LocalOperationalHealth]
FROM
SQL_AO_AVAILABILITYGROUPS AS AG
LEFT OUTER JOIN SQL_AO_AVAILABILITY_GROUP_STATES as agstates ON AG.group_id = agstates.group_id AND AG.SERVER_NAME = agstates.SERVER_NAME
INNER JOIN SQL_AO_AVAILABILITY_REPLICAS AS AR2 ON AG.group_id = AR2.group_id AND AR2.SERVER_NAME = AG.SERVER_NAME
INNER JOIN SQL_AO_AVAILABILITY_REPLICA_STATES AS arstates2 ON AR2.replica_id = arstates2.replica_id AND arstates2.is_local = 1 AND AR2.SERVER_NAME = ARSTATES2.SERVER_NAME
WHERE AG.STATS_TIME IN (SELECT MAX(STATS_TIME) FROM SQL_AO_AVAILABILITYGROUPS AO WHERE AO.SERVER_NAME = AG.SERVER_NAME)
GO
PRINT N'Altering [dbo].[DYNPERF_PURGE_DATA]...';


GO
ALTER PROCEDURE [dbo].[DYNPERF_PURGE_DATA]
	(@TASK_ID       INT,
                                              @SERVER_NAME   NVARCHAR(128),
                                              @DATABASE_NAME NVARCHAR(128),
                                              @TASK_PARAMS   NVARCHAR(1024),
                                              @TASK_DESC     NVARCHAR(256),
                                              @LAST_RUN      DATETIME,
                                              @RUN_NAME      NVARCHAR(255),
                                              @STATS_DATE    DATETIME,
                                              @REMOTE_SERVER NVARCHAR(1),
											  @AZURE_DB		 BIT,
											  @SQL_TZ_OFFSET INT,
											  @DPA_TZ_OFFSET INT,
                                              @DEBUG         NVARCHAR(1))
AS


SET NOCOUNT ON
SET DATEFORMAT MDY
DECLARE @PURGE_DATE smalldatetime, @PURGE_DAYS INT, @SQL NVARCHAR(MAX), @ROW_COUNT BIGINT = 0


DECLARE  @C_TABLE_NAME NVARCHAR(128), @C_TIME_COLUMN NVARCHAR(128), @C_SERVER_FLAG BIT, @C_DATABASE_FLAG BIT, @C_PURGE_DAYS INT
DECLARE @DC_SERVER_NAME NVARCHAR(128), @DC_DATABASE_NAME NVARCHAR(128), @DC_HISTORY_MONTHS INT, @DC_HISTORY_DAYS INT, @DC_DETAILS_DAYS INT






/********************************************************************************************************************************
*   STARTING TASK
*********************************************************************************************************************************/

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'STARTING to ' + ISNULL(@TASK_DESC, 'TASK')
              + ' for SERVER ' + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' USING PARMS @LAST_RUN ' + CAST(@LAST_RUN AS VARCHAR(30)) 
			  + ' @DPA_TZ_OFFSET = ' + CAST (@DPA_TZ_OFFSET AS VARCHAR(10))
			  + ' @SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET  AS VARCHAR(10))
			  + ' @STATS_DATE = ' + CAST(@STATS_DATE AS VARCHAR(30)) 
			  + ' @AZURE_DB = ' + CAST(@AZURE_DB AS VARCHAR(10))
			  + ' @REMOTE = ' + @REMOTE_SERVER
			  + ' @PARMS = ' + ISNULL(@TASK_PARAMS, '')
			  + ', '
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



--REH  Time Zone code for all procedures
IF @LAST_RUN > '1/1/1901'
  BEGIN
      IF @REMOTE_SERVER = 'N'
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @DPA_TZ_OFFSET, @LAST_RUN) --REH DPA and DB are on same server so use DPA Time Zone Offset
        END
      ELSE
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @SQL_TZ_OFFSET, @LAST_RUN)  --REH DPA and DB are on different servers so use DB Time Zone Offset
        END
  END 



BEGIN TRY
PRINT 'STARTING ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''




DECLARE TASK_CURSOR CURSOR  LOCAL
FOR
SELECT TABLE_NAME, TIME_COLUMN, SERVER_NAME_FLAG, DATABASE_NAME_FLAG, RETENTION_DAYS
FROM   DynamicsPerf..[DYNPERF_PURGETABLES] WHERE TIME_COLUMN > ''  ---REH Ignore tables without some form of time column.  The collection sproc will handle deletion of data in those tables
ORDER BY RETENTION_DAYS, TABLE_NAME    --REH this sort is to force QUERY_STATS to delete before QUERY_PLANS/QUERY_TEXT so we don't wait a day to delete records not attached to data



/* Open the cursor */
/*if the cursor isn't open you will get an error when you fetch the record*/
OPEN TASK_CURSOR 

/* Get the first record */
/* you can FETCH NEXT, FIRST, LAST, PREVIOUS */
FETCH NEXT FROM TASK_CURSOR INTO @C_TABLE_NAME, @C_TIME_COLUMN, @C_SERVER_FLAG, @C_DATABASE_FLAG, @C_PURGE_DAYS


/* Verify that we got a record*/
/* status 0 means we got a good record*/

WHILE @@fetch_status = 0  /* no errors */
BEGIN /* Top of Loop */



	SET @PURGE_DAYS = @C_PURGE_DAYS * -1  --set to negative so we go back in time not forward in time
	SET @PURGE_DATE = DATEADD(DAY,@PURGE_DAYS,GETDATE())



	UPDATE CAPTURE_LOG
SET    TEXT = TEXT + ' PURGING TABLE ' + ISNULL(@C_TABLE_NAME, 'TABLE ')
              + ' using PURGE_DAYS ' + CAST(@PURGE_DAYS AS VARCHAR(10)) + ' on DATE '
              + CONVERT(VARCHAR, @PURGE_DATE, 109) + ', '
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)




IF @C_TABLE_NAME IN ('QUERY_PLANS', 'QUERY_TEXT')  --REH Use special handling for QUERY_PLANS and QUERY_TEXT TABLE delete based on no dependent records
BEGIN
--REH All associated records in other tables must be deleted first, QUERY_STATS, QUERY_HISTORY, ETC

		IF @C_TABLE_NAME = 'QUERY_PLANS'
		BEGIN

				SELECT DISTINCT QP.SERVER_NAME, QP.DATABASE_NAME, QP.QUERY_PLAN_HASH
				INTO #QP1
					 FROM QUERY_PLANS QP WITH (NOLOCK) WHERE QP.SERVER_NAME = @SERVER_NAME AND
				 NOT EXISTS (SELECT QS.QUERY_PLAN_HASH FROM QUERY_STATS QS WITH (NOLOCK) WHERE QS.DATABASE_NAME = QP.DATABASE_NAME AND QS.SERVER_NAME = QP.SERVER_NAME AND QP.QUERY_PLAN_HASH = QS.QUERY_PLAN_HASH) 
					AND NOT EXISTS (SELECT QUERY_PLAN_HASH FROM QUERY_HISTORY QH WITH (NOLOCK) WHERE QH.DATABASE_NAME = QP.DATABASE_NAME AND QH.SERVER_NAME = QP.SERVER_NAME AND QP.QUERY_PLAN_HASH = QH.QUERY_PLAN_HASH) 
				
				DELETE QP FROM QUERY_PLANS QP WITH (ROWLOCK, READPAST) INNER JOIN #QP1 ON  QP.SERVER_NAME = #QP1.SERVER_NAME 
					AND QP.DATABASE_NAME = #QP1.DATABASE_NAME AND QP.QUERY_PLAN_HASH = #QP1.QUERY_PLAN_HASH
		
				DROP TABLE #QP1


			--REH Delete any plans over the minimum number of plans to keep
				
				SELECT A.*
				INTO #DEL_PLANS
				FROM (
				SELECT DISTINCT QV.SERVER_NAME,
										QV.DATABASE_NAME,
										QUERY_HASH,
										QV.QUERY_PLAN_HASH,
										RN = ROW_NUMBER()
									  OVER (
										PARTITION BY QV.QUERY_HASH
										ORDER BY QV.QUERY_HASH DESC, QP.DATE_UPDATED DESC)
						FROM   QUERY_HISTORY_VW QV WITH (NOLOCK) INNER JOIN QUERY_PLANS QP WITH (NOLOCK) ON QV.SERVER_NAME=QP.SERVER_NAME
						AND QV.DATABASE_NAME = QP.DATABASE_NAME AND QV.QUERY_PLAN_HASH = QP.QUERY_PLAN_HASH
						WHERE QV.DATE = DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()  ), 0) 

				   ) AS A 
				  -- INNER JOIN QUERY_PLANS QP WITH (NOLOCK) ON QP.SERVER_NAME = A.SERVER_NAME AND QP.DATABASE_NAME = A.DATABASE_NAME AND QP.QUERY_PLAN_HASH = A.QUERY_PLAN_HASH
				   WHERE A.RN> (SELECT D2.NUM_PLANS_TO_KEEP FROM DATABASES_2_COLLECT D2 WHERE D2.LINKED_SERVER=A.SERVER_NAME AND D2.DATABASE_NAME = A.DATABASE_NAME)

					DELETE QP FROM QUERY_PLANS QP WITH (ROWLOCK, READPAST) INNER JOIN #DEL_PLANS DP ON QP.SERVER_NAME = DP.SERVER_NAME
					AND QP.DATABASE_NAME = DP.DATABASE_NAME AND QP.QUERY_PLAN_HASH = DP.QUERY_PLAN_HASH

				   DROP TABLE #DEL_PLANS

			SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT


			--REH Delete any plans over the retention data

			DELETE QP FROM QUERY_PLANS QP WITH (ROWLOCK, READPAST) 
			INNER JOIN DATABASES_2_COLLECT DC ON QP.SERVER_NAME = DC.LINKED_SERVER AND DC.DATABASE_NAME = QP.DATABASE_NAME
			WHERE QP.DATE_UPDATED < DATEADD(DAY, DC.PURGE_PLANS_AFTER_X_DAYS * -1, GETDATE() )
			
			--REH Delete the bottom % of query_plans  RUN this task on the first day of the month
			

			IF DATEPART(DAY,GETDATE()) = 1 --REH Only run this part on first day of month
			BEGIN 
				WITH CTE_STATS (SERVER_NAME, DATABASE_NAME, QUERY_PLAN_HASH, PctRank)
					 AS (
	 					SELECT TOP 100 PERCENT QH.SERVER_NAME, QH.DATABASE_NAME, QH.QUERY_PLAN_HASH,
					   PERCENT_RANK() OVER (PARTITION BY QH.SERVER_NAME, QH.DATABASE_NAME ORDER BY QH.ELAPSED_TIME_TODAY  ) * 100.00 AS PctRank
				FROM QUERY_HISTORY QH INNER JOIN DATABASES_2_COLLECT D2 ON QH.SERVER_NAME = D2.LINKED_SERVER AND QH.DATABASE_NAME = D2.DATABASE_NAME
				WHERE FLAG = 'M' and DATE =  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE())-1, 0) --REH Previous Month
				--AND < 100 - D2.KEEP_TOP_X_PLANS_BY_MONTH  --REH The rank is less than the rank we want to keep (based on total time)
				ORDER BY QH.SERVER_NAME, QH.DATABASE_NAME, QH.ELAPSED_TIME_TODAY DESC)

				DELETE QP
				FROM   QUERY_PLANS QP WITH (ROWLOCK, READPAST)
					   INNER JOIN CTE_STATS CTE
							   ON QP.SERVER_NAME = CTE.SERVER_NAME
								  AND CTE.DATABASE_NAME = QP.DATABASE_NAME
								  AND CTE.QUERY_PLAN_HASH = QP.QUERY_PLAN_HASH
					   INNER JOIN DATABASES_2_COLLECT D2
							   ON D2.LINKED_SERVER = CTE.SERVER_NAME
								  AND CTE.DATABASE_NAME = D2.DATABASE_NAME
				WHERE  CTE.PCTRANK < 100 - D2.KEEP_TOP_X_QUERIES_BY_MONTH --REH The rank is less than the rank we want to keep (based on total time)

			
			END

		END

				

	   IF @C_TABLE_NAME = 'QUERY_TEXT'
		BEGIN
			SELECT QT.SERVER_NAME, QT.DATABASE_NAME, QT.QUERY_HASH 
			INTO #QT 
			FROM QUERY_TEXT QT WHERE QT.SERVER_NAME = @SERVER_NAME AND
			 NOT EXISTS (SELECT QS.QUERY_HASH FROM QUERY_STATS QS WITH (NOLOCK) WHERE QS.DATABASE_NAME = QT.DATABASE_NAME AND QS.SERVER_NAME = QT.SERVER_NAME AND QT.QUERY_HASH = QS.QUERY_HASH) 
				AND NOT EXISTS (SELECT QUERY_HASH FROM QUERY_HISTORY QH WITH (NOLOCK) WHERE QH.DATABASE_NAME = QT.DATABASE_NAME AND QH.SERVER_NAME = QT.SERVER_NAME AND QT.QUERY_HASH = QH.QUERY_HASH) 

				DELETE QT FROM QUERY_TEXT QT WITH (ROWLOCK, READPAST) INNER JOIN #QT TMP ON QT.SERVER_NAME = TMP.SERVER_NAME
				AND QT.DATABASE_NAME = TMP.DATABASE_NAME AND QT.QUERY_HASH = TMP.QUERY_HASH

				SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT
				
				DROP TABLE #QT
		END
END
ELSE
IF @C_TABLE_NAME IN ('QUERY_STATS', 'INDEX_DETAIL')  --RETAINED BASED ON FIELDS IN THE DATABASES_2_COLLECT TABLE

		BEGIN

				IF @C_TABLE_NAME = 'QUERY_STATS'
					DELETE QS FROM QUERY_STATS QS WITH (ROWLOCK, READPAST) INNER JOIN DATABASES_2_COLLECT DC ON QS.SERVER_NAME = DC.LINKED_SERVER AND QS.DATABASE_NAME = DC.DATABASE_NAME
						WHERE QS.SERVER_NAME = @SERVER_NAME AND QS.STATS_TIME < DATEADD(DAY,DC.RETAIN_DETAILS_DAYS * -1, GETDATE())

						SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT

				IF @C_TABLE_NAME = 'INDEX_DETAIL'
				BEGIN
					DELETE ID FROM INDEX_DETAIL ID WITH (ROWLOCK, READPAST) INNER JOIN DATABASES_2_COLLECT DC ON ID.SERVER_NAME = DC.LINKED_SERVER AND ID.DATABASE_NAME = DC.DATABASE_NAME 
							WHERE ID.SERVER_NAME = @SERVER_NAME AND ID.STATS_TIME < DATEADD(DAY,DC.RETAIN_DETAILS_DAYS * -1, GETDATE())

							SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT

					DELETE IOS FROM INDEX_OPERATIONAL_STATS IOS 
					WHERE IOS.STATS_TIME < ISNULL((SELECT MIN(STATS_TIME) FROM INDEX_DETAIL ID WHERE ID.SERVER_NAME = IOS.SERVER_NAME
					AND ID.DATABASE_NAME = IOS.DATABASE_NAME AND ID.OBJECT_ID = IOS.OBJECT_ID AND IOS.INDEX_ID = ID.INDEX_ID), GETDATE())

					DELETE IOS FROM INDEX_USAGE_STATS IOS 
					WHERE IOS.STATS_TIME < ISNULL((SELECT MIN(STATS_TIME) FROM INDEX_DETAIL ID WHERE ID.SERVER_NAME = IOS.SERVER_NAME
					AND ID.DATABASE_NAME = IOS.DATABASE_NAME AND ID.OBJECT_ID = IOS.OBJECT_ID AND IOS.INDEX_ID = ID.INDEX_ID), GETDATE())

				END
				
		END

ELSE
IF @C_TABLE_NAME IN ('CAPTURE_LOG')


	BEGIN

	
	SET @SQL = 'DELETE FROM ' + @C_TABLE_NAME + ' WHERE  ' + @C_TIME_COLUMN + ' <= ' + '''' + CONVERT(VARCHAR, @PURGE_DATE, 109) + ''''
			IF @DEBUG = 'Y'
			 BEGIN
				 PRINT @SQL
			 END
	EXEC(@SQL)

	SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT

	END
ELSE


IF @C_TABLE_NAME IN ('AX_BATCH_HISTORY')  --RETAINED BASED ON FIELDS IN THE DATABASES_2_COLLECT TABLE

		BEGIN
		DELETE QS FROM AX_BATCH_HISTORY QS WITH (ROWLOCK, READPAST) 
			INNER JOIN DATABASES_2_COLLECT DC ON QS.SERVER_NAME = DC.LINKED_SERVER AND DC.DATABASE_NAME = QS.DATABASE_NAME
		WHERE  QS.SERVER_NAME = @SERVER_NAME AND QS.DATE < DATEADD(MONTH,DC.RETAIN_HISTORY_MONTHS * -1, GETDATE()) AND QS.FLAG = 'M'

						SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT



					--REH DELETE DAYS TOTALS FROM QUERY_HISTORY		
		DELETE QS FROM AX_BATCH_HISTORY QS WITH (ROWLOCK, READPAST) 
			INNER JOIN DATABASES_2_COLLECT DC ON QS.SERVER_NAME = DC.LINKED_SERVER AND DC.DATABASE_NAME = QS.DATABASE_NAME
		WHERE  QS.SERVER_NAME = @SERVER_NAME AND QS.DATE < DATEADD(MONTH,DC.RETAIN_HISTORY_MONTHS * -1, GETDATE()) AND QS.FLAG = 'D'

						SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT

		END




IF @C_TABLE_NAME IN ('INDEX_HISTORY', 'QUERY_HISTORY')  --RETAINED BASED ON FIELDS IN THE DATABASES_2_COLLECT TABLE

		BEGIN

				IF @C_TABLE_NAME = 'QUERY_HISTORY'
				BEGIN
					--REH DELETE MONTHLY QUERY TOTALS 
					DELETE QS FROM QUERY_HISTORY QS WITH (ROWLOCK, READPAST) INNER JOIN DATABASES_2_COLLECT DC ON QS.SERVER_NAME = DC.LINKED_SERVER AND QS.DATABASE_NAME = DC.DATABASE_NAME
						WHERE  QS.SERVER_NAME = @SERVER_NAME AND QS.DATE < DATEADD(MONTH,DC.RETAIN_HISTORY_MONTHS * -1, GETDATE()) AND QS.FLAG = 'M'

						SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT



					--REH DELETE DAYS TOTALS FROM QUERY_HISTORY		
					DELETE QS FROM QUERY_HISTORY QS WITH (ROWLOCK, READPAST) INNER JOIN DATABASES_2_COLLECT DC ON QS.SERVER_NAME = DC.LINKED_SERVER AND QS.DATABASE_NAME = DC.DATABASE_NAME
						WHERE  QS.SERVER_NAME = @SERVER_NAME AND QS.DATE < DATEADD(DAY,DC.RETAIN_HISTORY_DAYS * -1, GETDATE()) AND QS.FLAG = 'D'

						SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT

		--REH STALE QUERY delete

							;WITH CTE_HIST (SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, MAX_DATE)
								 AS (SELECT SERVER_NAME,
											DATABASE_NAME,
											QUERY_HASH,
											QUERY_PLAN_HASH,
											MAX(DATE)
									 FROM   QUERY_HISTORY WITH (NOLOCK)
									 GROUP  BY SERVER_NAME,
											   DATABASE_NAME,
											   QUERY_HASH,
											   QUERY_PLAN_HASH)
							DELETE QS
							FROM   QUERY_HISTORY QS WITH (ROWLOCK, READPAST)
								   INNER JOIN DATABASES_2_COLLECT DC
										   ON QS.SERVER_NAME = DC.LINKED_SERVER
											  AND QS.DATABASE_NAME = DC.DATABASE_NAME
								   INNER JOIN CTE_HIST CTE
										   ON CTE.SERVER_NAME = QS.SERVER_NAME
											  AND CTE.DATABASE_NAME = QS.DATABASE_NAME
											  AND CTE.QUERY_HASH = QS.QUERY_HASH
											  AND CTE.QUERY_PLAN_HASH = QS.QUERY_PLAN_HASH
							WHERE  QS.SERVER_NAME = @SERVER_NAME
								   AND CTE.MAX_DATE < DATEADD(DAY, DC.PURGE_STALE_QUERIES_DAYS * -1, GETDATE()) 


						SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT



						IF DATEPART(DAY,GETDATE()) = 1 --REH Only run this part on first day of month
							BEGIN 
								WITH CTE_STATS (SERVER_NAME, DATABASE_NAME, QUERY_HASH, PctRank)
									 AS (
	 									SELECT TOP 100 PERCENT QH.SERVER_NAME, QH.DATABASE_NAME, QH.QUERY_HASH,
									   PERCENT_RANK() OVER (PARTITION BY QH.SERVER_NAME, QH.DATABASE_NAME ORDER BY QH.ELAPSED_TIME_TODAY  ) * 100.00 AS PctRank
								FROM QUERY_HISTORY QH INNER JOIN DATABASES_2_COLLECT D2 ON QH.SERVER_NAME = D2.LINKED_SERVER AND QH.DATABASE_NAME = D2.DATABASE_NAME
								WHERE FLAG = 'M' and DATE =  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE())-1, 0)  --REH Previous Month
								--AND < 100 - D2.KEEP_TOP_X_PLANS_BY_MONTH  --REH The rank is less than the rank we want to keep (based on total time)
								ORDER BY QH.SERVER_NAME, QH.DATABASE_NAME, QH.ELAPSED_TIME_TODAY DESC)

								DELETE QH FROM QUERY_HISTORY QH WITH (ROWLOCK, READPAST)
								INNER JOIN CTE_STATS CTE WITH (NOLOCK) ON QH.SERVER_NAME = CTE.SERVER_NAME AND CTE.DATABASE_NAME = QH.DATABASE_NAME AND CTE.QUERY_HASH = QH.QUERY_HASH
								INNER JOIN DATABASES_2_COLLECT D2  ON D2.LINKED_SERVER = CTE.SERVER_NAME AND CTE.DATABASE_NAME = D2.DATABASE_NAME 
								WHERE CTE.PCTRANK < 100 - D2.KEEP_TOP_X_QUERIES_BY_MONTH  --REH The rank is less than the rank we want to keep (based on total time)
								AND QH.FLAG = 'M' and QH.DATE =  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE())-1, 0)
							END







				END

				IF @C_TABLE_NAME = 'INDEX_HISTORY'
				BEGIN
					DELETE ID FROM INDEX_HISTORY ID WITH (ROWLOCK, READPAST) INNER JOIN DATABASES_2_COLLECT DC ON ID.SERVER_NAME = DC.LINKED_SERVER AND ID.DATABASE_NAME = DC.DATABASE_NAME 
							WHERE ID.SERVER_NAME = @SERVER_NAME AND ID.DATE < DATEADD(MONTH,DC.RETAIN_HISTORY_MONTHS * -1, GETDATE()) 
							AND ID.FLAG = 'M'

							SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT

					DELETE ID FROM INDEX_HISTORY ID WITH (ROWLOCK, READPAST) INNER JOIN DATABASES_2_COLLECT DC ON ID.SERVER_NAME = DC.LINKED_SERVER AND ID.DATABASE_NAME = DC.DATABASE_NAME 
							WHERE ID.SERVER_NAME = @SERVER_NAME AND ID.DATE < DATEADD(DAY,DC.RETAIN_HISTORY_DAYS * -1, GETDATE()) 
							AND ID.FLAG = 'D'

							SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT

				END	
			
		END

ELSE

IF @C_TABLE_NAME IN ('SSRS_EXECUTIONLOG', 'SSRS_HISTORY')  --RETAINED BASED ON FIELDS IN THE DATABASES_2_COLLECT TABLE
BEGIN
			IF @C_TABLE_NAME = 'SSRS_EXECUTIONLOG'
				BEGIN
					--REH DELETE MONTHLY QUERY TOTALS 
					DELETE EL FROM SSRS_EXECUTIONLOG EL WITH (ROWLOCK, READPAST)
					INNER JOIN SSRS_CONFIG SC ON EL.SERVER_NAME = SC.SERVER_NAME AND EL.DATABASE_NAME = SC.DATABASE_NAME
						WHERE  EL.TIMEEND < DATEADD(DAY,SC.RETAIN_DETAILS_DAYS * -1, GETDATE()) 

					SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT
				END
			IF @C_TABLE_NAME = 'SSRS_HISTORY'
				BEGIN
					--REH DELETE MONTHLY QUERY TOTALS 
					DELETE SH FROM SSRS_HISTORY SH WITH (ROWLOCK, READPAST)
						INNER JOIN SSRS_CONFIG SC ON SH.SERVER_NAME = SC.SERVER_NAME AND SH.DATABASE_NAME = SC.DATABASE_NAME
						WHERE   SH.REPORT_DATE < DATEADD(MONTH,SC.RETAIN_HISTORY_MONTHS * -1, GETDATE()) AND SH.FLAG = 'M'

						SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT



					--REH DELETE DAYS TOTALS FROM QUERY_HISTORY	
					DELETE SH FROM SSRS_HISTORY SH WITH (ROWLOCK, READPAST)
						INNER JOIN SSRS_CONFIG SC ON SH.SERVER_NAME = SC.SERVER_NAME AND SH.DATABASE_NAME = SC.DATABASE_NAME
						WHERE   SH.REPORT_DATE < DATEADD(DAY,SC.RETAIN_HISTORY_DAYS * -1, GETDATE()) AND SH.FLAG = 'D'
	
					SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT
				END
				
END


ELSE


IF @C_TABLE_NAME IN ('QUERY_PLANS_PARSED')  --RETAINED BASED ON FIELDS IN THE DATABASES_2_COLLECT TABLE
BEGIN
	SET @SQL = 'DELETE FROM ' + @C_TABLE_NAME + ' WITH (ROWLOCK, READPAST) WHERE ' + @C_TIME_COLUMN + ' <= ' + '''' + CONVERT(VARCHAR, @PURGE_DATE, 109) + ''''
			IF @DEBUG = 'Y'
			 BEGIN
				 PRINT @SQL
			 END
	EXEC(@SQL)

	SELECT QPP.SERVER_NAME, QPP.DATABASE_NAME, QPP.QUERY_PLAN_HASH 
	INTO #QPP FROM QUERY_PLANS_PARSED QPP 
	WHERE NOT EXISTS (SELECT 'X' FROM QUERY_HISTORY QH WHERE QPP.SERVER_NAME = QH.SERVER_NAME
	AND QPP.DATABASE_NAME = QH.DATABASE_NAME AND QPP.QUERY_PLAN_HASH = QH.QUERY_PLAN_HASH)

	DELETE QPP FROM QUERY_PLANS_PARSED QPP WITH (ROWLOCK, READPAST) INNER JOIN #QPP TMP ON QPP.SERVER_NAME = TMP.SERVER_NAME
		AND QPP.DATABASE_NAME = TMP.DATABASE_NAME AND QPP.QUERY_PLAN_HASH = TMP.QUERY_PLAN_HASH


	SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT
	
	DROP TABLE #QPP
END


ELSE


BEGIN



	SET @SQL = 'DELETE FROM ' + @C_TABLE_NAME + ' WITH (ROWLOCK, READPAST) WHERE SERVER_NAME =  ' + ''''+ @SERVER_NAME + '''' + ' AND ' + @C_TIME_COLUMN + ' <= ' + '''' + CONVERT(VARCHAR, @PURGE_DATE, 109) + ''''
			IF @DEBUG = 'Y'
			 BEGIN
				 PRINT @SQL
			 END
	EXEC(@SQL)

	SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT

END




FETCH NEXT FROM TASK_CURSOR INTO @C_TABLE_NAME, @C_TIME_COLUMN, @C_SERVER_FLAG, @C_DATABASE_FLAG, @C_PURGE_DAYS


END  /*End of the loop */
CLOSE TASK_CURSOR  /*close the cursor to free memory in SQL*/
DEALLOCATE TASK_CURSOR /*Must deallocate the cursor to destroy it and free SQL resources*/
 
	


UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'SUCCESSFULLY '
              + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' Deleted ' + CAST(@ROW_COUNT AS VARCHAR(10)) + ' ROWS ' +  CHAR(10) 
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



PRINT ''
PRINT 'SUCCESSFULLY CAPTURED ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


RETURN(0)  --REH RETURN SUCCESS


END TRY 


/********************************************************************************************************************************
*   END OF TASK
*********************************************************************************************************************************/


BEGIN CATCH
    UPDATE CAPTURE_LOG
    SET    TEXT = TEXT + 'FAILED !!! to '
	      + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
                  + ISNULL(@SERVER_NAME, '') + ' on database '
                  + ISNULL(@DATABASE_NAME, '') + ' at '
                  + CONVERT(VARCHAR, GETDATE(), 109) 
				  + ' ERROR = ' + CAST(@@ERROR AS VARCHAR(MAX))
				  + ', ' 
				  + CHAR(10)
    WHERE  STATS_TIME = @STATS_DATE
	AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



    PRINT 'ERROR WHILE COLLECTING '
          + ISNULL(@TASK_DESC, '') + ' !!!!!!!!!!!!!!'

    RETURN(1) --REH RETURN ERROR, TRAPPED BY SPROC
END CATCH
GO
PRINT N'Altering [dbo].[DYNPERF_PROCESS_QUERY_ALERTS]...';


GO
ALTER PROCEDURE [dbo].[DYNPERF_PROCESS_QUERY_ALERTS]
(@TASK_ID       INT,
                                              @SERVER_NAME   NVARCHAR(128),
                                              @DATABASE_NAME NVARCHAR(128),
                                              @TASK_PARAMS   NVARCHAR(1024),
                                              @TASK_DESC     NVARCHAR(256),
                                              @LAST_RUN      DATETIME,
                                              @RUN_NAME      NVARCHAR(255),
                                              @STATS_DATE    DATETIME,
                                              @REMOTE_SERVER NVARCHAR(1),
											  @AZURE_DB		 BIT,
											  @SQL_TZ_OFFSET INT,
											  @DPA_TZ_OFFSET INT,
                                              @DEBUG         NVARCHAR(1))
AS

/************************************************************************************************************
*  SETUP
*		DECLARE VARIABLES, CREATE SYNONYMS, ETC
*
*************************************************************************************************************/


    SET NOCOUNT ON
    SET DATEFORMAT MDY

    DECLARE @SQL NVARCHAR(MAX), @SQL2 NVARCHAR(MAX), @PCT_AVG_TIME_CHANGE_DAY int, @PCT_AVG_TIME_CHANGE_MONTH INT
	DECLARE @MIN_EXECUTION_COUNTS INT, @MIN_AVG_TIME_MS INT
    



/********************************************************************************************************************************
*   STARTING TASK
*********************************************************************************************************************************/

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'STARTING to ' + ISNULL(@TASK_DESC, 'TASK')
              + ' for SERVER ' + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' USING PARMS @LAST_RUN ' + CAST(@LAST_RUN AS VARCHAR(30)) 
			  + ' @DPA_TZ_OFFSET = ' + CAST (@DPA_TZ_OFFSET AS VARCHAR(10))
			  + ' @SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET  AS VARCHAR(10))
			  + ' @STATS_DATE = ' + CAST(@STATS_DATE AS VARCHAR(30)) 
			  + ' @AZURE_DB = ' + CAST(@AZURE_DB AS VARCHAR(10))
			  + ' @REMOTE = ' + @REMOTE_SERVER
			  + ' @PARMS = ' + ISNULL(@TASK_PARAMS, '')
			  + ', '
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)




SELECT @PCT_AVG_TIME_CHANGE_DAY = PCT_AVG_TIME_CHANGE_DAY,
       @PCT_AVG_TIME_CHANGE_MONTH = PCT_AVG_TIME_CHANGE_MONTH,
       @MIN_EXECUTION_COUNTS = MIN_EXECUTION_COUNTS,
       @MIN_AVG_TIME_MS = MIN_AVG_TIME_MS
FROM   QUERY_ALERTS_CONFIG
WHERE  SERVER_NAME = @SERVER_NAME
       AND DATABASE_NAME = @DATABASE_NAME 


--REH  Time Zone code for all procedures
IF @LAST_RUN > '1/1/1901'
  BEGIN
  --REH in this case, we are going to compare to STATS_TIME which is the DynamicsPerf Time Zone so convert last_run back into that time

     SET @LAST_RUN = DATEADD(MI, @DPA_TZ_OFFSET, @LAST_RUN) --REH DPA and DB are on same server so use DPA Time Zone Offset

  END 


IF @PCT_AVG_TIME_CHANGE_DAY IS NULL 
  BEGIN
                --MJP Log no alerts
                UPDATE CAPTURE_LOG
                 SET    TEXT = TEXT + 'No Alerts Configured! '
                  WHERE  STATS_TIME = @STATS_DATE 
                  AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)
                RETURN(0)  --REH No settings for this server/db just return and do nothing
  END


BEGIN TRY
PRINT 'STARTING ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''

--REH SAME QUERY_HASH/PLAN_HASH , true parm sniffing query issue



;WITH CTE_STATS (SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, CREATION_TIME, STATS_TIME, PREV_STATS_TIME, PREV_CREATION_TIME, PREV_ELAPSED_TIME, PREV_EXECUTION_COUNT, EXECUTION_COUNT, TOTAL_WORKER_TIME, TOTAL_ELAPSED_TIME, PREV_TOTAL_WORKER_TIME, TIME_THIS_PERIOD, WORKER_TIME_THIS_PERIOD, EXECUTIONS_THIS_PERIOD)
     AS (SELECT  SERVER_NAME,
                         DATABASE_NAME,
                         QUERY_HASH,
                         QUERY_PLAN_HASH,

                         CREATION_TIME,
                         [STATS_TIME],
                         LAG(STATS_TIME, 1, 0)
                           OVER (
                             PARTITION BY SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, CREATION_TIME
                             ORDER BY STATS_TIME )                      AS PREV_STATS_TIME,
                         LAG(CREATION_TIME, 1, 0)
                           OVER (
                             PARTITION BY SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, CREATION_TIME
                             ORDER BY STATS_TIME )                      AS PREV_CREATION_TIME,
                         
                         LAG(TOTAL_ELAPSED_TIME, 1, 0)
                           OVER (
                             PARTITION BY SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, CREATION_TIME
                             ORDER BY STATS_TIME )                      AS PREV_ELAPSED_TIME,
                         LAG(EXECUTION_COUNT, 1, 0)
                           OVER (
                             PARTITION BY SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, CREATION_TIME
                             ORDER BY STATS_TIME )                      AS PREV_EXECUTION_COUNT,
                         EXECUTION_COUNT,
                         TOTAL_WORKER_TIME,
                         TOTAL_ELAPSED_TIME,
                         LAG(TOTAL_WORKER_TIME, 1, 0)
                           OVER (
                             PARTITION BY SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, CREATION_TIME
                             ORDER BY STATS_TIME )                      AS PREV_TOTAL_WORKER_TIME,
                         TOTAL_ELAPSED_TIME - LAG(TOTAL_ELAPSED_TIME, 1, 0)
                                                OVER (
                                                  PARTITION BY SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, CREATION_TIME
                                                  ORDER BY STATS_TIME ) AS TIME_THIS_PERIOD,
                         TOTAL_WORKER_TIME - LAG(TOTAL_WORKER_TIME, 1, 0)
                                               OVER (
                                                 PARTITION BY SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, CREATION_TIME
                                                 ORDER BY STATS_TIME )  AS WORKER_TIME_THIS_PERIOD,
                         EXECUTION_COUNT - LAG(EXECUTION_COUNT, 1, 0)
                                             OVER (
                                               PARTITION BY SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, CREATION_TIME
                                               ORDER BY STATS_TIME )    AS EXECUTIONS_THIS_PERIOD
         FROM   QUERY_STATS QS
		where SERVER_NAME = @SERVER_NAME
       AND DATABASE_NAME = @DATABASE_NAME
       AND STATS_TIME > @LAST_RUN
		 )


INSERT QUERY_ALERTS
SELECT DISTINCT QS_CTE.SERVER_NAME,
       QS_CTE.STATS_TIME,
       QS_CTE.DATABASE_NAME,
       QS_CTE.QUERY_HASH,
       QS_CTE.QUERY_PLAN_HASH
FROM    (SELECT SERVER_NAME,
					   DATABASE_NAME,
					   STATS_TIME,
					   QUERY_HASH,
					   QUERY_PLAN_HASH,
					   SUM(CAST(TIME_THIS_PERIOD / 1000.000 AS DECIMAL(20, 3)))                               AS TOTAL_TIME_MS,
					   SUM(EXECUTIONS_THIS_PERIOD)                                                            AS TOTAL_EXECUTIONS,
					   CASE SUM(EXECUTIONS_THIS_PERIOD)
						 WHEN 0 THEN 0
						 ELSE ( SUM(CAST(TIME_THIS_PERIOD / 1000.000 AS DECIMAL(20, 3))) / SUM(EXECUTIONS_THIS_PERIOD) )
					   END                                                                                    AS AVG_TIME_MS,
					   SUM(CAST(WORKER_TIME_THIS_PERIOD / 1000.000 AS DECIMAL(20, 3)))                        AS WORK_TIME,
					   SUM(CAST(( TIME_THIS_PERIOD - WORKER_TIME_THIS_PERIOD ) / 1000.000 AS DECIMAL(14, 3))) AS WAIT_TIME
			FROM  (select * from CTE_STATS) as CTE 
			WHERE  
				--QS.SERVER_NAME = CTE.SERVER_NAME AND QS.DATABASE_NAME=CTE.DATABASE_NAME AND
				--QS.STATS_TIME = CTE.STATS_TIME 
				--AND QS.QUERY_HASH = CTE.QUERY_HASH AND QS.QUERY_PLAN_HASH = CTE.QUERY_PLAN_HASH AND
				 CTE.DATABASE_NAME = @DATABASE_NAME AND CTE.SERVER_NAME = @SERVER_NAME
				AND CTE.STATS_TIME > @LAST_RUN

			GROUP  BY SERVER_NAME,
						DATABASE_NAME,
				         STATS_TIME,
						QUERY_HASH,
						QUERY_PLAN_HASH) AS QS_CTE

       INNER JOIN QUERY_HISTORY QHD 
               ON QHD.SERVER_NAME = QS_CTE.SERVER_NAME
                  AND QHD.DATABASE_NAME = QS_CTE.DATABASE_NAME
                  AND QHD.QUERY_HASH = QS_CTE.QUERY_HASH
                  AND QHD.QUERY_PLAN_HASH = QS_CTE.QUERY_PLAN_HASH
                  AND QHD.FLAG = 'D'
                  AND QHD.DATE = DATEADD(DAY, DATEDIFF(DAY, 0, QS_CTE.STATS_TIME), 0)
       INNER JOIN QUERY_HISTORY QHM
               ON QHM.SERVER_NAME = QS_CTE.SERVER_NAME
                  AND QHM.DATABASE_NAME = QS_CTE.DATABASE_NAME
                  AND QHM.QUERY_HASH = QS_CTE.QUERY_HASH
                  AND QHM.QUERY_PLAN_HASH = QS_CTE.QUERY_PLAN_HASH
                  AND QHM.FLAG = 'M'
                  AND QHM.DATE = DATEADD(MONTH, DATEDIFF(MONTH, 0, QS_CTE.STATS_TIME), 0)
WHERE  
        ( ( QS_CTE.AVG_TIME_MS  > QHD.AVG_TIME_TODAY_MS * @PCT_AVG_TIME_CHANGE_DAY/100
                OR QS_CTE.AVG_TIME_MS   > QHM.AVG_TIME_TODAY_MS * @PCT_AVG_TIME_CHANGE_MONTH/100 )
             AND QS_CTE.AVG_TIME_MS   > @MIN_AVG_TIME_MS
             AND QS_CTE.TOTAL_EXECUTIONS > @MIN_EXECUTION_COUNTS ) 
			 option (maxdop 1)


--REH any variation 






;WITH CTE_STATS (SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, CREATION_TIME, STATS_TIME, PREV_STATS_TIME, PREV_CREATION_TIME, PREV_ELAPSED_TIME, PREV_EXECUTION_COUNT, EXECUTION_COUNT, TOTAL_WORKER_TIME, TOTAL_ELAPSED_TIME, PREV_TOTAL_WORKER_TIME, TIME_THIS_PERIOD, WORKER_TIME_THIS_PERIOD, EXECUTIONS_THIS_PERIOD)
     AS (SELECT  SERVER_NAME,
                         DATABASE_NAME,
                         QUERY_HASH,
                         QUERY_PLAN_HASH,

                         CREATION_TIME,
                         [STATS_TIME],
                         LAG(STATS_TIME, 1, 0)
                           OVER (
                             PARTITION BY SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, CREATION_TIME
                             ORDER BY STATS_TIME )                      AS PREV_STATS_TIME,
                         LAG(CREATION_TIME, 1, 0)
                           OVER (
                             PARTITION BY SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, CREATION_TIME
                             ORDER BY STATS_TIME )                      AS PREV_CREATION_TIME,
                         
                         LAG(TOTAL_ELAPSED_TIME, 1, 0)
                           OVER (
                             PARTITION BY SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, CREATION_TIME
                             ORDER BY STATS_TIME )                      AS PREV_ELAPSED_TIME,
                         LAG(EXECUTION_COUNT, 1, 0)
                           OVER (
                             PARTITION BY SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, CREATION_TIME
                             ORDER BY STATS_TIME )                      AS PREV_EXECUTION_COUNT,
                         EXECUTION_COUNT,
                         TOTAL_WORKER_TIME,
                         TOTAL_ELAPSED_TIME,
                         LAG(TOTAL_WORKER_TIME, 1, 0)
                           OVER (
                             PARTITION BY SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, CREATION_TIME
                             ORDER BY STATS_TIME )                      AS PREV_TOTAL_WORKER_TIME,
                         TOTAL_ELAPSED_TIME - LAG(TOTAL_ELAPSED_TIME, 1, 0)
                                                OVER (
                                                  PARTITION BY SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, CREATION_TIME
                                                  ORDER BY STATS_TIME ) AS TIME_THIS_PERIOD,
                         TOTAL_WORKER_TIME - LAG(TOTAL_WORKER_TIME, 1, 0)
                                               OVER (
                                                 PARTITION BY SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, CREATION_TIME
                                                 ORDER BY STATS_TIME )  AS WORKER_TIME_THIS_PERIOD,
                         EXECUTION_COUNT - LAG(EXECUTION_COUNT, 1, 0)
                                             OVER (
                                               PARTITION BY SERVER_NAME, DATABASE_NAME, QUERY_HASH, QUERY_PLAN_HASH, CREATION_TIME
                                               ORDER BY STATS_TIME )    AS EXECUTIONS_THIS_PERIOD
         FROM   QUERY_STATS QS
		where SERVER_NAME = @SERVER_NAME
       AND DATABASE_NAME = @DATABASE_NAME
       AND STATS_TIME > @LAST_RUN
		 )




INSERT QUERY_ALERTS
SELECT DISTINCT QS_CTE.SERVER_NAME,
       QS_CTE.STATS_TIME,
       QS_CTE.DATABASE_NAME,
       QS_CTE.QUERY_HASH,
       QS_CTE.QUERY_PLAN_HASH
FROM    (SELECT TOP 100 SERVER_NAME,
					   DATABASE_NAME,
					   STATS_TIME,
					   QUERY_HASH,
					   QUERY_PLAN_HASH,
					   SUM(CAST(TIME_THIS_PERIOD / 1000.000 AS DECIMAL(20, 3)))                               AS TOTAL_TIME_MS,
					   SUM(EXECUTIONS_THIS_PERIOD)                                                            AS TOTAL_EXECUTIONS,
					   CASE SUM(EXECUTIONS_THIS_PERIOD)
						 WHEN 0 THEN 0
						 ELSE ( SUM(CAST(TIME_THIS_PERIOD / 1000.000 AS DECIMAL(20, 3))) / SUM(EXECUTIONS_THIS_PERIOD) )
					   END                                                                                    AS AVG_TIME_MS,
					   SUM(CAST(WORKER_TIME_THIS_PERIOD / 1000.000 AS DECIMAL(20, 3)))                        AS WORK_TIME,
					   SUM(CAST(( TIME_THIS_PERIOD - WORKER_TIME_THIS_PERIOD ) / 1000.000 AS DECIMAL(14, 3))) AS WAIT_TIME
			FROM  (select * from CTE_STATS) as CTE 
			WHERE  
				--QS.SERVER_NAME = CTE.SERVER_NAME AND QS.DATABASE_NAME=CTE.DATABASE_NAME AND
				--QS.STATS_TIME = CTE.STATS_TIME 
				--AND QS.QUERY_HASH = CTE.QUERY_HASH AND QS.QUERY_PLAN_HASH = CTE.QUERY_PLAN_HASH AND
				 CTE.DATABASE_NAME = @DATABASE_NAME AND CTE.SERVER_NAME = @SERVER_NAME
				AND CTE.STATS_TIME > @LAST_RUN

			GROUP  BY SERVER_NAME,
						DATABASE_NAME,
				         STATS_TIME,
						QUERY_HASH,
						QUERY_PLAN_HASH) AS QS_CTE

       CROSS APPLY (SELECT SERVER_NAME, DATABASE_NAME, QUERY_HASH, MAX(QHD.AVG_TIME_TODAY_MS) AS AVG_TIME_TODAY_MS
				FROM  QUERY_HISTORY QHD
               WHERE QHD.SERVER_NAME = QS_CTE.SERVER_NAME
                  AND QHD.DATABASE_NAME = QS_CTE.DATABASE_NAME
                  AND QHD.QUERY_HASH = QS_CTE.QUERY_HASH
				  AND QHD.QUERY_PLAN_HASH <> QS_CTE.QUERY_PLAN_HASH
                  AND QHD.FLAG = 'D'
                  AND QHD.DATE = DATEADD(DAY, DATEDIFF(DAY, 0, QS_CTE.STATS_TIME), 0)
				  GROUP BY SERVER_NAME, DATABASE_NAME, QUERY_HASH
				  ) AS QHDAILY
       CROSS APPLY ( SELECT SERVER_NAME, DATABASE_NAME, QUERY_HASH, MAX(QHM.AVG_TIME_TODAY_MS) AS AVG_TIME_TODAY_MS
				FROM  QUERY_HISTORY QHM
               WHERE QHM.SERVER_NAME = QS_CTE.SERVER_NAME
                  AND QHM.DATABASE_NAME = QS_CTE.DATABASE_NAME
                  AND QHM.QUERY_HASH = QS_CTE.QUERY_HASH
				  AND QHM.QUERY_PLAN_HASH <> QS_CTE.QUERY_PLAN_HASH
                  AND QHM.FLAG = 'M'
                  AND QHM.DATE = DATEADD(MONTH, DATEDIFF(MONTH, 0, QS_CTE.STATS_TIME), 0)
				  GROUP BY SERVER_NAME, DATABASE_NAME, QUERY_HASH
				  ) AS QHMONTHLY
WHERE   ( ( QS_CTE.AVG_TIME_MS  > QHDAILY.AVG_TIME_TODAY_MS * @PCT_AVG_TIME_CHANGE_DAY/100
                OR QS_CTE.AVG_TIME_MS   > QHMONTHLY.AVG_TIME_TODAY_MS * @PCT_AVG_TIME_CHANGE_MONTH/100 )
             AND QS_CTE.AVG_TIME_MS   > @MIN_AVG_TIME_MS
             AND QS_CTE.TOTAL_EXECUTIONS > @MIN_EXECUTION_COUNTS ) 
option (maxdop 1)



UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'SUCCESSFULLY '
              + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' Inserted ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' ROWS ' +  CHAR(10) 
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



PRINT ''
PRINT 'SUCCESSFULLY CAPTURED ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


RETURN(0)  --REH RETURN SUCCESS


END TRY 


/********************************************************************************************************************************
*   END OF TASK
*********************************************************************************************************************************/


BEGIN CATCH
    UPDATE CAPTURE_LOG
    SET    TEXT = TEXT + 'FAILED !!! to '
	      + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
                  + ISNULL(@SERVER_NAME, '') + ' on database '
                  + ISNULL(@DATABASE_NAME, '') + ' at '
                  + CONVERT(VARCHAR, GETDATE(), 109) 
				  + ' ERROR = ' + CAST(@@ERROR AS VARCHAR(MAX))
				  + ', ' 
				  + CHAR(10)
    WHERE  STATS_TIME = @STATS_DATE
	AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



    PRINT 'ERROR WHILE COLLECTING '
          + ISNULL(@TASK_DESC, '') + ' !!!!!!!!!!!!!!'

    RETURN(1) --REH RETURN ERROR, TRAPPED BY SPROC
END CATCH
GO
PRINT N'Altering [dbo].[DYNPERF_AX_VERSION_INFO]...';


GO

ALTER PROCEDURE DYNPERF_AX_VERSION_INFO (@AX_SERVER_NAME      NVARCHAR(128) = NULL,
                                          @AX_DATABASE_NAME    NVARCHAR(128),
                                          @DEBUG            NVARCHAR(1) = 'N')
                                      
AS
    /************************************************************************************************************
    *  SETUP
    *		DECLARE VARIABLES, CREATE SYNONYMS, ETC
    *
    *************************************************************************************************************/
    SET NOCOUNT ON
    SET DATEFORMAT MDY

    DECLARE @SQL           NVARCHAR(MAX),
            @SQL2          NVARCHAR(MAX),
            @REMOTE_SERVER NVARCHAR(1),
			@AX_APP_BUILD_OUT NVARCHAR(120) ,
            @KERNEL_BUILD_OUT NVARCHAR(20),
			@AX_VERSION NVARCHAR(20)

    /*************************************************
    
    --REH Template for creating a synonym, 
    --Will help avoid having to use EXEC (@SQL) code
    -- and make the code more dynamic to the inputs
    
    
    ***************************************************/
    SET @REMOTE_SERVER = CASE @AX_SERVER_NAME
                           WHEN @@SERVERNAME THEN 'N'
                           ELSE 'Y'
                         END

    IF EXISTS (SELECT *
               FROM   sys.synonyms
               WHERE  name = 'DYN_AVI_AX_SYSSETUPLOG')
      DROP SYNONYM [dbo].DYN_AVI_AX_SYSSETUPLOG

    IF @REMOTE_SERVER = 'Y'
         BEGIN
             SET @SQL = '
				CREATE SYNONYM DYN_AVI_AX_SYSSETUPLOG
				FOR [' + @AX_SERVER_NAME + '].['
                        + @AX_DATABASE_NAME + '].dbo.SYSSETUPLOG'
         END
    ELSE
      SET @SQL = '
				CREATE SYNONYM DYN_AVI_AX_SYSSETUPLOG
				FOR [' + @AX_DATABASE_NAME
                 + '].dbo.SYSSETUPLOG'

    IF @DEBUG = 'Y'
         BEGIN
             PRINT '@SQL= ' + @SQL
         END

    EXEC (@SQL)

    IF EXISTS (SELECT *
               FROM   sys.synonyms
               WHERE  name = 'DYN_AVI_AX_SYSCONFIG')
      DROP SYNONYM [dbo].DYN_AVI_AX_SYSCONFIG

    IF @REMOTE_SERVER = 'Y'
         BEGIN
             SET @SQL = '
				CREATE SYNONYM DYN_AVI_AX_SYSCONFIG
				FOR [' + @AX_SERVER_NAME + '].['
                        + @AX_DATABASE_NAME + '].dbo.SYSCONFIG'
         END
    ELSE
      SET @SQL = '
				CREATE SYNONYM DYN_AVI_AX_SYSCONFIG
				FOR [' + @AX_DATABASE_NAME
                 + '].dbo.SYSCONFIG'

    IF @DEBUG = 'Y'
         BEGIN
             PRINT '@SQL= ' + @SQL
         END

    EXEC (@SQL)

     /********************************************************************************************************************************
     *   STARTING TASK
     *********************************************************************************************************************************/
     BEGIN TRY
         SELECT TOP 1 @KERNEL_BUILD_OUT = KERNELBUILD, @AX_VERSION = VERSION
         FROM   DYN_AVI_AX_SYSSETUPLOG WITH (NOLOCK)
         ORDER  BY RECID DESC

         SELECT TOP 1 @AX_APP_BUILD_OUT = VALUE
         FROM   DYN_AVI_AX_SYSCONFIG WITH (NOLOCK)
         WHERE  CONFIGTYPE = 4
                AND ID = 6

		IF ISNULL(@AX_APP_BUILD_OUT,'') = ''
			BEGIN
				SET @AX_APP_BUILD_OUT = @AX_VERSION  --REH work around for AX7 atm
				SET @KERNEL_BUILD_OUT = @AX_VERSION 
			END
		SELECT @AX_APP_BUILD_OUT AS AX_APP_BUILD, @KERNEL_BUILD_OUT AS AX_KERNEL_BUILD


		    IF EXISTS (SELECT *
               FROM   sys.synonyms
               WHERE  name = 'DYN_AVI_AX_SYSSETUPLOG')
      DROP SYNONYM [dbo].DYN_AVI_AX_SYSSETUPLOG

	      IF EXISTS (SELECT *
               FROM   sys.synonyms
               WHERE  name = 'DYN_AVI_AX_SYSCONFIG')
      DROP SYNONYM [dbo].DYN_AVI_AX_SYSCONFIG

     END TRY

     /********************************************************************************************************************************
     *   END OF TASK
     *********************************************************************************************************************************/
     BEGIN CATCH
         PRINT 'ERROR IN COLLECTING AX VERSION INFORAMTION '

		 		    IF EXISTS (SELECT *
               FROM   sys.synonyms
               WHERE  name = 'DYN_AVI_AX_SYSSETUPLOG')
      DROP SYNONYM [dbo].DYN_AVI_AX_SYSSETUPLOG

	      IF EXISTS (SELECT *
               FROM   sys.synonyms
               WHERE  name = 'DYN_AVI_AX_SYSCONFIG')
      DROP SYNONYM [dbo].DYN_AVI_AX_SYSCONFIG


     END CATCH
GO
PRINT N'Altering [dbo].[DYNPERF_COLLECT_AX_NUMBERSEQUENCE]...';


GO

ALTER PROCEDURE DYNPERF_COLLECT_AX_NUMBERSEQUENCE (@TASK_ID       INT,
                                              @SERVER_NAME   NVARCHAR(128),
                                              @DATABASE_NAME NVARCHAR(128),
                                              @TASK_PARAMS   NVARCHAR(1024),
                                              @TASK_DESC     NVARCHAR(256),
                                              @LAST_RUN      DATETIME,
                                              @RUN_NAME      NVARCHAR(255),
                                              @STATS_DATE    DATETIME,
                                              @REMOTE_SERVER NVARCHAR(1),
											  @AZURE_DB		 BIT,
											  @SQL_TZ_OFFSET INT,
											  @DPA_TZ_OFFSET INT,
                                              @DEBUG         NVARCHAR(1))
AS


/************************************************************************************************************
*  SETUP
*		DECLARE VARIABLES, CREATE SYNONYMS, ETC
*
*************************************************************************************************************/

    SET NOCOUNT ON
    SET DATEFORMAT MDY

    DECLARE @SQL NVARCHAR(MAX), @SQL2 NVARCHAR(MAX), @ROW_COUNT BIGINT
    
/*************************************************

--REH Template for creating a synonym, 
--Will help avoid having to use EXEC (@SQL) code
-- and make the code more dynamic to the inputs


***************************************************/


--REH All versions have this table so it's here in the code
-- version specific synonyms are in the appropriate AX version below


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_NUMBERSEQUENCETABLE')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_NUMBERSEQUENCETABLE')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_NUMBERSEQUENCETABLE
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.NUMBERSEQUENCETABLE'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_NUMBERSEQUENCETABLE
				FOR [' + @DATABASE_NAME + '].dbo.NUMBERSEQUENCETABLE'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL) 











/********************************************************************************************************************************
*   STARTING TASK
*********************************************************************************************************************************/



UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'STARTING to ' + ISNULL(@TASK_DESC, 'TASK')
              + ' for SERVER ' + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' USING PARMS @LAST_RUN ' + CAST(@LAST_RUN AS VARCHAR(30)) 
			  + ' @DPA_TZ_OFFSET = ' + CAST (@DPA_TZ_OFFSET AS VARCHAR(10))
			  + ' @SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET  AS VARCHAR(10))
			  + ' @STATS_DATE = ' + CAST(@STATS_DATE AS VARCHAR(30)) 
			  + ' @AZURE_DB = ' + CAST(@AZURE_DB AS VARCHAR(10))
			  + ' @REMOTE = ' + @REMOTE_SERVER
			  + ' @PARMS = ' + ISNULL(@TASK_PARAMS, '')
			  + ', '
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)





--REH  Time Zone code for all procedures
IF @LAST_RUN > '1/1/1901'
  BEGIN
      IF @REMOTE_SERVER = 'N'
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @DPA_TZ_OFFSET, @LAST_RUN) --REH DPA and DB are on same server so use DPA Time Zone Offset
        END
      ELSE
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @SQL_TZ_OFFSET, @LAST_RUN)  --REH DPA and DB are on different servers so use DB Time Zone Offset
        END
  END 




BEGIN TRY
PRINT 'STARTING ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


--REH Get AX version

DECLARE @AX_SERVER_NAME   NVARCHAR(128) = NULL,
        @AX_DATABASE_NAME NVARCHAR(128),
        @AX_APP_BUILD     NVARCHAR(120),
        @KERNEL_BUILD     NVARCHAR(20)
   
   CREATE TABLE #AX_VERSION_NUM
     (
        AX_APP_BUILD NVARCHAR(120),
        KERNEL_BUILD NVARCHAR(20)
     )
   
   SET NOCOUNT ON
   
   INSERT #AX_VERSION_NUM
   EXECUTE DYNPERF_AX_VERSION_INFO
     @AX_SERVER_NAME = @SERVER_NAME,
     @AX_DATABASE_NAME = @DATABASE_NAME--, @DEBUG = 'N'
   SELECT @AX_APP_BUILD = AX_APP_BUILD,
          @KERNEL_BUILD = KERNEL_BUILD
   FROM   #AX_VERSION_NUM
   
   --PRINT 'AX BUILD = ' + ISNULL(@AX_APP_BUILD, '')
   
   --PRINT 'KERNEL BUILD = '+ ISNULL(@KERNEL_BUILD, '')
   
   IF EXISTS (SELECT * FROM  [tempdb].sys.objects WHERE name = '#AX_VERSION_NUM') 
	BEGIN
	  DROP TABLE #AX_VERSION_NUM 
	END
   
   
  
IF Substring(@AX_APP_BUILD, 1, 1) BETWEEN N'4' AND N'5'
BEGIN



--REH  Have to check if the NUMBERSEQUENCETABLE is shared or not, aka. does DATAAREAID exist in the table

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_SYSTABLES')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_SYSTABLES')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_SYSTABLES
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].sys.tables'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_SYSTABLES
				FOR [' + @DATABASE_NAME + '].sys.tables'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL) 


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_SYSCOLUMNS')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_SYSCOLUMNS')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_SYSCOLUMNS
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].sys.columns'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_SYSCOLUMNS
				FOR [' + @DATABASE_NAME + '].sys.columns'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL) 


		--REH store data by company, most common scenario
		IF EXISTS (SELECT * FROM DYN_AXNUM_SYSTABLES t INNER JOIN DYN_AXNUM_SYSCOLUMNS c
		ON t.object_id=c.object_id
		WHERE t.name = 'NUMBERSEQUENCETABLE' AND c.name = 'DATAAREAID') 
		BEGIN
			INSERT INTO AX_NUM_SEQUENCES
			SELECT @SERVER_NAME,
				   @STATS_DATE,
				   @DATABASE_NAME,
				   0,
				   NUMBERSEQUENCE,
				   TXT,
				   LOWEST,
				   HIGHEST,
				   NEXTREC,
				   0,
				   0,
				   CASE CONTINUOUS
					 WHEN 0 THEN 'No'
					 WHEN 1 THEN 'Yes'
				   END,
				   FETCHAHEAD,
				   FETCHAHEADQTY,
				   0,
				   0,
				   NULL,
				   NULL,
				   DATAAREAID,
				   NULL,
				   NULL,
				   NULL,
				   NULL,
				   NULL,
				   NULL,
				   NULL,
				   NULL,
				   FORMAT
			FROM   DYN_AXNUM_AX_NUMBERSEQUENCETABLE 


		END
		ELSE
		BEGIN
		
			INSERT INTO AX_NUM_SEQUENCES
			SELECT @SERVER_NAME,
				   @STATS_DATE,
				   @DATABASE_NAME,
				   0,
				   NUMBERSEQUENCE,
				   TXT,
				   LOWEST,
				   HIGHEST,
				   NEXTREC,
				   0,
				   0,
				   CASE CONTINUOUS
					 WHEN 0 THEN 'No'
					 WHEN 1 THEN 'Yes'
				   END,
				   FETCHAHEAD,
				   FETCHAHEADQTY,
				   0,
				   0,
				   NULL,
				   NULL,
				   '',			--blank out dataareid, field doesn't exist
				   NULL,
				   NULL,
				   NULL,
				   NULL,
				   NULL,
				   NULL,
				   NULL,
				   NULL,
				   FORMAT
			FROM   DYN_AXNUM_AX_NUMBERSEQUENCETABLE 


		
		END

		SET @ROW_COUNT = @@ROWCOUNT
	
END

--REH Synonyms for all version of AX2012 --------------------------------------------------

IF Substring(@AX_APP_BUILD, 1, 1) = '6'
BEGIN
	

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_NUMBERSEQUENCESCOPE')
 EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_NUMBERSEQUENCESCOPE')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_NUMBERSEQUENCESCOPE
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.NUMBERSEQUENCESCOPE'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_NUMBERSEQUENCESCOPE
				FOR [' + @DATABASE_NAME + '].dbo.NUMBERSEQUENCESCOPE'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL)




IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_DATAAREA')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_DATAAREA')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_DATAAREA
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.DATAAREA'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_DATAAREA
				FOR [' + @DATABASE_NAME + '].dbo.DATAAREA'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL)



IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_FISCALCALENDARPERIOD')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_FISCALCALENDARPERIOD')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_FISCALCALENDARPERIOD
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.FISCALCALENDARPERIOD'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_FISCALCALENDARPERIOD
				FOR [' + @DATABASE_NAME + '].dbo.FISCALCALENDARPERIOD'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL)



IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_FISCALCALENDAR')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_FISCALCALENDAR')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_FISCALCALENDAR
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.FISCALCALENDAR'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_FISCALCALENDAR
				FOR [' + @DATABASE_NAME + '].dbo.FISCALCALENDAR'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL)




IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_FISCALCALENDARYEAR')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_FISCALCALENDARYEAR')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_FISCALCALENDARYEAR
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.FISCALCALENDARYEAR'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_FISCALCALENDARYEAR
				FOR [' + @DATABASE_NAME + '].dbo.FISCALCALENDARYEAR'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL)
	
END



IF Substring(@AX_APP_BUILD, 1, 1) = '7'
BEGIN
	

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_NUMBERSEQUENCESCOPE')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_NUMBERSEQUENCESCOPE')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_NUMBERSEQUENCESCOPE
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.NUMBERSEQUENCESCOPE'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_NUMBERSEQUENCESCOPE
				FOR [' + @DATABASE_NAME + '].dbo.NUMBERSEQUENCESCOPE'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL)




IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_DATAAREA')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_DATAAREA')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_DATAAREA
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.DATAAREA'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_DATAAREA
				FOR [' + @DATABASE_NAME + '].dbo.DATAAREA'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL)



IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_FISCALCALENDARPERIOD')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_FISCALCALENDARPERIOD')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_FISCALCALENDARPERIOD
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.FISCALCALENDARPERIOD'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_FISCALCALENDARPERIOD
				FOR [' + @DATABASE_NAME + '].dbo.FISCALCALENDARPERIOD'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL)



IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_FISCALCALENDAR')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_FISCALCALENDAR')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_FISCALCALENDAR
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.FISCALCALENDAR'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_FISCALCALENDAR
				FOR [' + @DATABASE_NAME + '].dbo.FISCALCALENDAR'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL)




IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_FISCALCALENDARYEAR')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_FISCALCALENDARYEAR')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_FISCALCALENDARYEAR
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.FISCALCALENDARYEAR'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_FISCALCALENDARYEAR
				FOR [' + @DATABASE_NAME + '].dbo.FISCALCALENDARYEAR'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL)
	
		
	
	
PRINT ''	
END

-------------------------------------------End of AX2012 common synonyms -------------------


IF Substring(@AX_APP_BUILD, 1, 3) = '6.0'
BEGIN




IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_COMPANYINFO')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_COMPANYINFO')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_COMPANYINFO
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.COMPANYINFO'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_COMPANYINFO
				FOR [' + @DATABASE_NAME + '].dbo.COMPANYINFO'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL)




IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_OMOPERATINGUNIT')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_OMOPERATINGUNIT')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_OMOPERATINGUNIT
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.OMOPERATINGUNIT'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_OMOPERATINGUNIT
				FOR [' + @DATABASE_NAME + '].dbo.OMOPERATINGUNIT'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL)

INSERT INTO AX_NUM_SEQUENCES
SELECT @SERVER_NAME,
       @STATS_DATE,
       @DATABASE_NAME,
       NST.RECID,
       NST.NUMBERSEQUENCE                                                                                                                                 AS [NumberSequence],
       NST.TXT                                                                                                                                            AS [Text],
       NST.LOWEST,
       NST.HIGHEST,
       NST.NEXTREC,
	   CASE WHEN NST.HIGHEST - NST.LOWEST = 0 THEN 0 ELSE
       CAST (( CAST(( NST.HIGHEST - NST.NEXTREC ) AS DECIMAL(20, 2)) / ( CAST(( NST.HIGHEST - NST.LOWEST ) AS DECIMAL(20, 2)) ) * 100 ) AS DECIMAL(6, 2)) END AS [PercentRemaining],
       NST.HIGHEST - NST.NEXTREC                                                                                                                          AS [NumbersRemaining],
       CASE NST.CONTINUOUS
         WHEN 0 THEN 'No'
         WHEN 1 THEN 'Yes'
       END                                                                                                                                                [Continuous],
       NST.FETCHAHEAD                                                                                                                                     AS FetchAhead,
       NST.FETCHAHEADQTY                                                                                                                                  AS FetchAheadQty,
       NST.CLEANINTERVAL                                                                                                                                  AS CleanInterval,
       NST.CLEANATACCESS                                                                                                                                  AS CleanAtAccess,
       'N/A'                                                                                                                                              AS [PartitionName],
       NST.NUMBERSEQUENCESCOPE,
       DA.ID                                                                                                                                              [CompanyId],
       DA.NAME                                                                                                                                            [CompanyName],
       CASE DA.ISVIRTUAL
         WHEN 0 THEN 'No'
         WHEN 1 THEN 'Yes'
       END                                                                                                                                                [Shared],
       CI.DATAAREA                                                                                                                                        [LegalEntityName],
       CASE OU.OMOPERATINGUNITTYPE
         WHEN 0 THEN 'None'
         WHEN 1 THEN 'Department'
         WHEN 2 THEN 'Cost center'
         WHEN 3 THEN 'Value stream'
         WHEN 4 THEN 'Business unit'
         WHEN 5 THEN 'All operating units'
         WHEN 6 THEN 'Retail channel'
       END                                                                                                                                                [OperatingUnitType],
       OU.OMOPERATINGUNITNUMBER                                                                                                                           [OperatingUnitNumber],
       FC.CALENDARID                                                                                                                                      [FiscalCalendar],
       FCY.NAME                                                                                                                                           [FiscalCalendarYear],
       FCP.NAME                                                                                                                                           [Period],
       NST.FORMAT
FROM   DYN_AXNUM_AX_NUMBERSEQUENCETABLE NST
       JOIN DYN_AXNUM_AX_NUMBERSEQUENCESCOPE NSS
         ON NSS.RECID = NST.NUMBERSEQUENCESCOPE
       LEFT JOIN DYN_AXNUM_AX_DATAAREA DA
              ON NSS.DATAAREA = DA.ID
       LEFT JOIN DYN_AXNUM_AX_COMPANYINFO CI
              ON NSS.LEGALENTITY = CI.RECID
       LEFT JOIN DYN_AXNUM_AX_OMOPERATINGUNIT OU
              ON NSS.OPERATINGUNIT = OU.RECID
       LEFT JOIN DYN_AXNUM_AX_FISCALCALENDARPERIOD FCP
              ON NSS.FISCALCALENDARPERIOD = FCP.RECID
       LEFT JOIN DYN_AXNUM_AX_FISCALCALENDAR FC
              ON FC.RECID = FCP.FISCALCALENDAR
       LEFT JOIN DYN_AXNUM_AX_FISCALCALENDARYEAR FCY
              ON FCY.RECID = FCP.FISCALCALENDARYEAR

	
	SET @ROW_COUNT = @@ROWCOUNT
END
	
IF Substring(@AX_APP_BUILD, 1, 3) IN ( '6.2', '6.3', '7.0')
BEGIN
	


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_PARTITIONS')
  EXEC('DROP SYNONYM [dbo].DYN_AXNUM_AX_PARTITIONS')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_PARTITIONS
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.PARTITIONS'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_PARTITIONS
				FOR [' + @DATABASE_NAME + '].dbo.PARTITIONS'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL)


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_DIRPARTYTABLE')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_DIRPARTYTABLE')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_DIRPARTYTABLE
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.DIRPARTYTABLE'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXNUM_AX_DIRPARTYTABLE
				FOR [' + @DATABASE_NAME + '].dbo.DIRPARTYTABLE'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL)

INSERT INTO AX_NUM_SEQUENCES
SELECT @SERVER_NAME,
       @STATS_DATE,
       @DATABASE_NAME,
       NST.RECID,
       NST.NUMBERSEQUENCE                                                                                                                                 AS [NumberSequence],
       NST.TXT                                                                                                                                            AS [Text],
       NST.LOWEST,
       NST.HIGHEST,
       NST.NEXTREC,
	   CASE WHEN NST.HIGHEST - NST.LOWEST = 0 THEN 0 ELSE
       CAST (( CAST(( NST.HIGHEST - NST.NEXTREC ) AS DECIMAL(20, 2)) / ( CAST(( NST.HIGHEST - NST.LOWEST ) AS DECIMAL(20, 2)) ) * 100 ) AS DECIMAL(6, 2)) END AS [PercentRemaining],
       NST.HIGHEST - NST.NEXTREC                                                                                                                          AS [NumbersRemaining],
       CASE NST.CONTINUOUS
         WHEN 0 THEN 'No'
         WHEN 1 THEN 'Yes'
       END                                                                                                                                                [Continuous],
       NST.FETCHAHEAD                                                                                                                                     AS FetchAhead,
       NST.FETCHAHEADQTY                                                                                                                                  AS FetchAheadQty,
       NST.CLEANINTERVAL                                                                                                                                  AS CleanInterval,
       NST.CLEANATACCESS                                                                                                                                  AS CleanAtAccess,
       P.NAME                                                                                                                                             AS [PartitionName],
       NST.NUMBERSEQUENCESCOPE,
       DA.ID                                                                                                                                              [CompanyId],
       DA.NAME                                                                                                                                            [CompanyName],
       CASE DA.ISVIRTUAL
         WHEN 0 THEN 'No'
         WHEN 1 THEN 'Yes'
       END                                                                                                                                                [Shared],
       DI.DATAAREA                                                                                                                                        [LegalEntityName],
       CASE DI.OMOPERATINGUNITTYPE
         WHEN 0 THEN 'None'
         WHEN 1 THEN 'Department'
         WHEN 2 THEN 'Cost center'
         WHEN 3 THEN 'Value stream'
         WHEN 4 THEN 'Business unit'
         WHEN 5 THEN 'All operating units'
         WHEN 6 THEN 'Retail channel'
       END                                                                                                                                                [OperatingUnitType],
       DI.OMOPERATINGUNITNUMBER                                                                                                                           [OperatingUnitNumber],
       FC.CALENDARID                                                                                                                                      [FiscalCalendar],
       FCY.NAME                                                                                                                                           [FiscalCalendarYear],
       FCP.NAME                                                                                                                                           [Period],
       NST.FORMAT
FROM   DYN_AXNUM_AX_NUMBERSEQUENCETABLE NST
       JOIN DYN_AXNUM_AX_PARTITIONS P
         ON NST.PARTITION = P.RECID
       JOIN DYN_AXNUM_AX_NUMBERSEQUENCESCOPE NSS
         ON NSS.RECID = NST.NUMBERSEQUENCESCOPE
       LEFT JOIN DYN_AXNUM_AX_DATAAREA DA
              ON NSS.DATAAREA = DA.ID
			  and NST.PARTITION = DA.PARTITION
       LEFT JOIN DYN_AXNUM_AX_DIRPARTYTABLE DI
              ON ( NSS.LEGALENTITY = DI.RECID )
                  OR ( NSS.OPERATINGUNIT = DI.RECID )
       LEFT JOIN DYN_AXNUM_AX_FISCALCALENDARPERIOD FCP
              ON NSS.FISCALCALENDARPERIOD = FCP.RECID
       LEFT JOIN DYN_AXNUM_AX_FISCALCALENDAR FC
              ON FC.RECID = FCP.FISCALCALENDAR
       LEFT JOIN DYN_AXNUM_AX_FISCALCALENDARYEAR FCY
              ON FCY.RECID = FCP.FISCALCALENDARYEAR


	SET @ROW_COUNT = @@ROWCOUNT

END
    


UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'SUCCESSFULLY '
              + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' Inserted ' + cast(@ROW_COUNT as varchar(10)) + ' ROWS ' +  CHAR(10) 
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)


PRINT ''
PRINT 'SUCCESSFULLY CAPTURED ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


--REH Drop all synonyms

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_NUMBERSEQUENCETABLE')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_NUMBERSEQUENCETABLE')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_SYSTABLES')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_SYSTABLES')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_SYSCOLUMNS')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_SYSCOLUMNS')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_NUMBERSEQUENCESCOPE')
 EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_NUMBERSEQUENCESCOPE')


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_DATAAREA')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_DATAAREA')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_FISCALCALENDARPERIOD')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_FISCALCALENDARPERIOD')


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_FISCALCALENDAR')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_FISCALCALENDAR')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_FISCALCALENDARYEAR')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_FISCALCALENDARYEAR')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_NUMBERSEQUENCESCOPE')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_NUMBERSEQUENCESCOPE')


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_DATAAREA')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_DATAAREA')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_FISCALCALENDARPERIOD')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_FISCALCALENDARPERIOD')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_FISCALCALENDAR')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_FISCALCALENDAR')


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_FISCALCALENDARYEAR')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_FISCALCALENDARYEAR')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_COMPANYINFO')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_COMPANYINFO')


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_OMOPERATINGUNIT')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_OMOPERATINGUNIT')



IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_PARTITIONS')
  EXEC('DROP SYNONYM [dbo].DYN_AXNUM_AX_PARTITIONS')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_DIRPARTYTABLE')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_DIRPARTYTABLE')




RETURN(0)  --REH RETURN SUCCESS


END TRY 


/********************************************************************************************************************************
*   END OF TASK
*********************************************************************************************************************************/




BEGIN CATCH
    UPDATE CAPTURE_LOG
    SET    TEXT = TEXT + 'FAILED !!! to '
	      + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
                  + ISNULL(@SERVER_NAME, '') + ' on database '
                  + ISNULL(@DATABASE_NAME, '') + ' at '
                  + CONVERT(VARCHAR, GETDATE(), 109) 
				  + ' ERROR = ' + CAST(@@ERROR AS VARCHAR(MAX))
				  + ', ' 
				  + CHAR(10)
    WHERE  STATS_TIME = @STATS_DATE
	AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)




    PRINT 'ERROR WHILE COLLECTING '
          + ISNULL(@TASK_DESC, '') + ' !!!!!!!!!!!!!!'

--REH Drop all synonyms

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_NUMBERSEQUENCETABLE')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_NUMBERSEQUENCETABLE')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_SYSTABLES')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_SYSTABLES')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_SYSCOLUMNS')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_SYSCOLUMNS')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_NUMBERSEQUENCESCOPE')
 EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_NUMBERSEQUENCESCOPE')


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_DATAAREA')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_DATAAREA')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_FISCALCALENDARPERIOD')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_FISCALCALENDARPERIOD')


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_FISCALCALENDAR')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_FISCALCALENDAR')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_FISCALCALENDARYEAR')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_FISCALCALENDARYEAR')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_NUMBERSEQUENCESCOPE')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_NUMBERSEQUENCESCOPE')


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_DATAAREA')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_DATAAREA')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_FISCALCALENDARPERIOD')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_FISCALCALENDARPERIOD')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_FISCALCALENDAR')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_FISCALCALENDAR')


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_FISCALCALENDARYEAR')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_FISCALCALENDARYEAR')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_COMPANYINFO')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_COMPANYINFO')


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_OMOPERATINGUNIT')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_OMOPERATINGUNIT')



IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_PARTITIONS')
  EXEC('DROP SYNONYM [dbo].DYN_AXNUM_AX_PARTITIONS')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXNUM_AX_DIRPARTYTABLE')
  EXEC ('DROP SYNONYM [dbo].DYN_AXNUM_AX_DIRPARTYTABLE')





    RETURN(1) --REH RETURN ERROR, TRAPPED BY SPROC
END CATCH
GO
PRINT N'Altering [dbo].[DYNPERF_COLLECT_AX_SQLTRACE]...';


GO

ALTER PROCEDURE DYNPERF_COLLECT_AX_SQLTRACE (@TASK_ID       INT,
                                              @SERVER_NAME   NVARCHAR(128),
                                              @DATABASE_NAME NVARCHAR(128),
                                              @TASK_PARAMS   NVARCHAR(1024),
                                              @TASK_DESC     NVARCHAR(256),
                                              @LAST_RUN      DATETIME,
                                              @RUN_NAME      NVARCHAR(255),
                                              @STATS_DATE    DATETIME,
                                              @REMOTE_SERVER NVARCHAR(1),
											  @AZURE_DB		 BIT,
											  @SQL_TZ_OFFSET INT,
											  @DPA_TZ_OFFSET INT,
                                              @DEBUG         NVARCHAR(1))
AS


/************************************************************************************************************
*  SETUP
*		DECLARE VARIABLES, CREATE SYNONYMS, ETC
*
*************************************************************************************************************/

    SET NOCOUNT ON
    SET DATEFORMAT MDY

    DECLARE @SQL NVARCHAR(MAX), @SQL2 NVARCHAR(MAX)
    
/*************************************************

--REH Template for creating a synonym, 
--Will help avoid having to use EXEC (@SQL) code
-- and make the code more dynamic to the inputs


***************************************************/
--REH Moved the synonms to avoid SQL runtime error that columns don't exists.  

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXTRACE_AX_SYSTRACETABLE')
  EXEC ('DROP SYNONYM [dbo].DYN_AXTRACE_AX_SYSTRACETABLE')




/********************************************************************************************************************************
*   STARTING TASK
*********************************************************************************************************************************/

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'STARTING to ' + ISNULL(@TASK_DESC, 'TASK')
              + ' for SERVER ' + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' USING PARMS @LAST_RUN ' + CAST(@LAST_RUN AS VARCHAR(30)) 
			  + ' @DPA_TZ_OFFSET = ' + CAST (@DPA_TZ_OFFSET AS VARCHAR(10))
			  + ' @SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET  AS VARCHAR(10))
			  + ' @STATS_DATE = ' + CAST(@STATS_DATE AS VARCHAR(30)) 
			  + ' @AZURE_DB = ' + CAST(@AZURE_DB AS VARCHAR(10))
			  + ' @REMOTE = ' + @REMOTE_SERVER
			  + ' @PARMS = ' + ISNULL(@TASK_PARAMS, '')
			  + ', '
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



--REH  Time Zone code for all procedures

--REH @LAST_RUN IS UTC TIME WHICH IS WHAT WE NEED IN THIS SPROC AND THIS SPROC ALONE


--IF @LAST_RUN > '1/1/1901'
--  BEGIN
--      IF @REMOTE_SERVER = 'N'
--        BEGIN
--            SET @LAST_RUN = DATEADD(MI, @DPA_TZ_OFFSET, @LAST_RUN) --REH DPA and DB are on same server so use DPA Time Zone Offset
--        END
--      ELSE
--        BEGIN
--            SET @LAST_RUN = DATEADD(MI, @SQL_TZ_OFFSET, @LAST_RUN)  --REH DPA and DB are on different servers so use DB Time Zone Offset
--        END
--  END 


BEGIN TRY
PRINT 'STARTING ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''

IF EXISTS (SELECT * FROM  [tempdb].sys.objects WHERE name = '#AX_VERSION') 
 DROP TABLE  #AX_VERSION 

--REH Get AX version

DECLARE @AX_SERVER_NAME   NVARCHAR(128) = NULL,
        @AX_DATABASE_NAME NVARCHAR(128),
        @AX_APP_BUILD     NVARCHAR(120),
        @KERNEL_BUILD     NVARCHAR(20)
   
   CREATE TABLE #AX_VERSION
     (
        AX_APP_BUILD NVARCHAR(120),
        KERNEL_BUILD NVARCHAR(20)
     )
   
   SET NOCOUNT ON
   
   INSERT #AX_VERSION
   EXECUTE DYNPERF_AX_VERSION_INFO
     @AX_SERVER_NAME = @SERVER_NAME,
     @AX_DATABASE_NAME = @DATABASE_NAME--, @DEBUG = 'N'
   SELECT @AX_APP_BUILD = AX_APP_BUILD,
          @KERNEL_BUILD = KERNEL_BUILD
   FROM   #AX_VERSION
   
   --PRINT 'AX BUILD = ' + ISNULL(@AX_APP_BUILD, '')
   
   --PRINT 'KERNEL BUILD = '+ ISNULL(@KERNEL_BUILD, '')
   
IF EXISTS (SELECT * FROM  [tempdb].sys.objects WHERE name = '#AX_VERSION') 
 BEGIN 
	DROP TABLE  #AX_VERSION 
 END
   

  
IF Substring(@AX_APP_BUILD, 1, 1) BETWEEN N'3' AND N'4'
BEGIN


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXTRACE_AX_SYSTRACETABLE')
  EXEC('DROP SYNONYM [dbo].DYN_AXTRACE_AX_SYSTRACETABLE')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXTRACE_AX_SYSTRACETABLE
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.SYSTRACETABLESQL'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXTRACE_AX_SYSTRACETABLE
				FOR [' + @DATABASE_NAME + '].dbo.SYSTRACETABLESQL'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL) 


INSERT INTO AX_SQLTRACE 
		   (SERVER_NAME
		   ,STATS_TIME
		   ,DATABASE_NAME
		   ,SQL_DURATION
		   ,TRACE_CATEGORY
		   ,SQL_TEXT
		   ,CALL_STACK
		   ,TRACE_EVENT_CODE
		   ,TRACE_EVENT_DESC
		   ,TRACE_EVENT_DETAILS
		   ,CONNECTION_TYPE
		   ,SQL_SESSION_ID
		   ,AX_CONNECTION_ID
		   ,IS_LOBS_INCLUDED
		   ,IS_MORE_DATA_PENDING
		   ,ROWS_AFFECTED
		   ,ROW_SIZE
		   ,ROWS_PER_FETCH
		   ,IS_SELECTED_FOR_UPDATE
		   ,IS_STARTED_WITHIN_TRANSACTION
		   ,SQL_TYPE
		   ,STATEMENT_ID
		   ,STATEMENT_REUSE_COUNT
		   ,DETAIL_TYPE
		   ,CREATED_DATETIME
		   ,AX_USER_ID)
		SELECT @SERVER_NAME,
			@STATS_DATE,
			@DATABASE_NAME,
			TRACETIME
			,CATEGORY
			,STATEMENT
			,CALLSTACK
			,CODE
			,TEXT
			,TEXTDETAILS
			,CONNECTIONTYPE
			,CONNECTIONSPID
			,CONNECTIONID
			,ISLOBSINCLUDED
			,ISMOREDATAPENDING
			,ROWSAFFECTED
			,ROWSIZE
			,ROWSPERFETCH
			,ISSELECTEDFORUPDATE
			,ISSTARTEDWITHINTRANSACTION
			,STATEMENTTYPE
			,STATEMENTID
			,STATEMENTREUSECOUNT
			,DETAILTYPE
			,  DATEADD(MI, @SQL_TZ_OFFSET, DATEADD(minute, DATEDIFF(minute,getutcdate(),getdate()), DATEADD(S, CREATEDTIME, CREATEDDATE)))      
			,CREATEDBY
			
			
		FROM DYN_AXTRACE_AX_SYSTRACETABLE WITH (NOLOCK)
		WHERE DATEADD(S, CREATEDTIME, CREATEDDATE) >= @LAST_RUN
	 AND DATEADD(D, 14, CREATEDDATE) >= GETDATE()


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXTRACE_AX_SYSTRACETABLE')
  EXEC ('DROP SYNONYM [dbo].DYN_AXTRACE_AX_SYSTRACETABLE')
	
END

IF Substring(@AX_APP_BUILD, 1, 2) IN ('5.', '6.', '7.') 
    BEGIN	
	
	
IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXTRACE_AX_SYSTRACETABLE')
  EXEC ('DROP SYNONYM [dbo].DYN_AXTRACE_AX_SYSTRACETABLE')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AXTRACE_AX_SYSTRACETABLE
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.SYSTRACETABLESQL'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AXTRACE_AX_SYSTRACETABLE
				FOR [' + @DATABASE_NAME + '].dbo.SYSTRACETABLESQL'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL) 

INSERT INTO AX_SQLTRACE 
		   (SERVER_NAME
		   ,STATS_TIME
		   ,DATABASE_NAME
		   ,SQL_DURATION
		   ,TRACE_CATEGORY
		   ,SQL_TEXT
		   ,CALL_STACK
		   ,TRACE_EVENT_CODE
		   ,TRACE_EVENT_DESC
		   ,TRACE_EVENT_DETAILS
		   ,CONNECTION_TYPE
		   ,SQL_SESSION_ID
		   ,AX_CONNECTION_ID
		   ,IS_LOBS_INCLUDED
		   ,IS_MORE_DATA_PENDING
		   ,ROWS_AFFECTED
		   ,ROW_SIZE
		   ,ROWS_PER_FETCH
		   ,IS_SELECTED_FOR_UPDATE
		   ,IS_STARTED_WITHIN_TRANSACTION
		   ,SQL_TYPE
		   ,STATEMENT_ID
		   ,STATEMENT_REUSE_COUNT
		   ,DETAIL_TYPE
		   ,CREATED_DATETIME
		   ,AX_USER_ID)
		SELECT @SERVER_NAME,
			@STATS_DATE,
			@DATABASE_NAME,
			TRACETIME
			,CATEGORY
			,STATEMENT
			,CALLSTACK
			,CODE
			,TEXT
			,TEXTDETAILS
			,CONNECTIONTYPE
			,CONNECTIONSPID
			,CONNECTIONID
			,ISLOBSINCLUDED
			,ISMOREDATAPENDING
			,ROWSAFFECTED
			,ROWSIZE
			,ROWSPERFETCH
			,ISSELECTEDFORUPDATE
			,ISSTARTEDWITHINTRANSACTION
			,STATEMENTTYPE
			,STATEMENTID
			,STATEMENTREUSECOUNT
			,DETAILTYPE
			,DATEADD(MI, @SQL_TZ_OFFSET, CREATEDDATETIME)
			,CREATEDBY
	
		FROM DYN_AXTRACE_AX_SYSTRACETABLE WITH (NOLOCK)
		WHERE CREATEDDATETIME >= @LAST_RUN
	 AND DATEADD(D, 14, CREATEDDATETIME) >= GETDATE()
	
	END
	
IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXTRACE_AX_SYSTRACETABLE')
 EXEC('DROP SYNONYM [dbo].DYN_AXTRACE_AX_SYSTRACETABLE')
  
  	
 
UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'SUCCESSFULLY '
              + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' Inserted ' + cast(@@rowcount as varchar(10)) + ' ROWS ' +  CHAR(10) 
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



PRINT ''
PRINT 'SUCCESSFULLY CAPTURED ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


RETURN(0)  --REH RETURN SUCCESS


END TRY 


/********************************************************************************************************************************
*   END OF TASK
*********************************************************************************************************************************/


BEGIN CATCH

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AXTRACE_AX_SYSTRACETABLE')
  EXEC ('DROP SYNONYM [dbo].DYN_AXTRACE_AX_SYSTRACETABLE')



    UPDATE CAPTURE_LOG
    SET    TEXT = TEXT + 'FAILED !!! to '
	      + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
                  + ISNULL(@SERVER_NAME, '') + ' on database '
                  + ISNULL(@DATABASE_NAME, '') + ' at '
                  + CONVERT(VARCHAR, GETDATE(), 109) 
				  + ', ' 
				  + CHAR(10)
    WHERE  STATS_TIME = @STATS_DATE
	AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)




    PRINT 'ERROR WHILE COLLECTING '
          + ISNULL(@TASK_DESC, '') + ' !!!!!!!!!!!!!!'

    RETURN(1) --REH RETURN ERROR, TRAPPED BY SPROC
END CATCH
GO
PRINT N'Altering [dbo].[DYNPERF_COLLECT_INDEXSTATS]...';


GO

ALTER PROCEDURE DYNPERF_COLLECT_INDEXSTATS (@TASK_ID       INT,
                                              @SERVER_NAME   NVARCHAR(128),
                                              @DATABASE_NAME NVARCHAR(128),
                                              @TASK_PARAMS   NVARCHAR(1024),
                                              @TASK_DESC     NVARCHAR(256),
                                              @LAST_RUN      DATETIME,
                                              @RUN_NAME      NVARCHAR(255),
                                              @STATS_DATE    DATETIME,
                                              @REMOTE_SERVER NVARCHAR(1),
											  @AZURE_DB		 BIT,
											  @SQL_TZ_OFFSET INT,
											  @DPA_TZ_OFFSET INT,
                                              @DEBUG         NVARCHAR(1))
AS


/************************************************************************************************************
*  SETUP
*		DECLARE VARIABLES, CREATE SYNONYMS, ETC
*
*************************************************************************************************************/


    SET NOCOUNT ON
    SET DATEFORMAT MDY

    DECLARE @SQL NVARCHAR(MAX), @SQL2 NVARCHAR(MAX), @PREV_STATS_TIME DATETIME
    
/*************************************************

--REH Template for creating a synonym, 
--Will help avoid having to use EXEC (@SQL) code
-- and make the code more dynamic to the inputs


***************************************************/

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_CI_INDEX_COLS')
  EXEC ('DROP SYNONYM [dbo].DYN_CI_INDEX_COLS')


IF @REMOTE_SERVER = 'N'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_CI_INDEX_COLS
				FOR [' + @DATABASE_NAME + '].sys.index_columns'
     END


IF @DEBUG = 'Y'
     BEGIN
         PRINT '@SQL= ' + @SQL
     END

EXEC(@SQL) 

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_CI_SYS_COLS')
  EXEC ('DROP SYNONYM [dbo].DYN_CI_SYS_COLS')


IF @REMOTE_SERVER = 'N'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_CI_SYS_COLS
				FOR [' + @DATABASE_NAME + '].sys.columns'
     END


IF @DEBUG = 'Y'
     BEGIN
         PRINT '@SQL= ' + @SQL
     END

EXEC(@SQL) 


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_CI_INDEXES')
  EXEC ('DROP SYNONYM [dbo].DYN_CI_INDEXES')


IF @REMOTE_SERVER = 'N'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_CI_INDEXES
				FOR [' + @DATABASE_NAME + '].sys.indexes'
     END


IF @DEBUG = 'Y'
     BEGIN
         PRINT '@SQL= ' + @SQL
     END

EXEC(@SQL) 


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_CI_SYS_INDEXES')
  EXEC ('DROP SYNONYM [dbo].DYN_CI_SYS_INDEXES')


IF @REMOTE_SERVER = 'N'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_CI_SYS_INDEXES
				FOR [' + @DATABASE_NAME + '].sys.sysindexes'
     END


IF @DEBUG = 'Y'
     BEGIN
         PRINT '@SQL= ' + @SQL
     END

EXEC(@SQL) 


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_CI_OBJECTS')
  EXEC ('DROP SYNONYM [dbo].DYN_CI_OBJECTS')


IF @REMOTE_SERVER = 'N'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_CI_OBJECTS
				FOR [' + @DATABASE_NAME + '].sys.objects'
     END


IF @DEBUG = 'Y'
     BEGIN
         PRINT '@SQL= ' + @SQL
     END

EXEC(@SQL) 


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_CI_SCHEMAS')
  EXEC ('DROP SYNONYM [dbo].DYN_CI_SCHEMAS')

IF @REMOTE_SERVER = 'N'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_CI_SCHEMAS
				FOR [' + @DATABASE_NAME + '].sys.schemas'
     END


IF @DEBUG = 'Y'
     BEGIN
         PRINT '@SQL= ' + @SQL
     END

EXEC(@SQL) 


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_CI_PARTITIONS')
  EXEC ('DROP SYNONYM [dbo].DYN_CI_PARTITIONS')

IF @REMOTE_SERVER = 'N'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_CI_PARTITIONS
				FOR [' + @DATABASE_NAME + '].sys.partitions'
     END


IF @DEBUG = 'Y'
     BEGIN
         PRINT '@SQL= ' + @SQL
     END

EXEC(@SQL) 



IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_CI_PARTITION_STATS')
  EXEC ('DROP SYNONYM [dbo].DYN_CI_PARTITION_STATS')

IF @REMOTE_SERVER = 'N'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_CI_PARTITION_STATS
				FOR [' + @DATABASE_NAME + '].sys.dm_db_partition_stats'
     END


IF @DEBUG = 'Y'
     BEGIN
         PRINT '@SQL= ' + @SQL
     END

EXEC(@SQL) 



/********************************************************************************************************************************
*   STARTING TASK
*********************************************************************************************************************************/

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'STARTING to ' + ISNULL(@TASK_DESC, 'TASK')
              + ' for SERVER ' + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' USING PARMS @LAST_RUN ' + CAST(@LAST_RUN AS VARCHAR(30)) 
			  + ' @DPA_TZ_OFFSET = ' + CAST (@DPA_TZ_OFFSET AS VARCHAR(10))
			  + ' @SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET  AS VARCHAR(10))
			  + ' @STATS_DATE = ' + CAST(@STATS_DATE AS VARCHAR(30)) 
			  + ' @AZURE_DB = ' + CAST(@AZURE_DB AS VARCHAR(10))
			  + ' @REMOTE = ' + @REMOTE_SERVER
			  + ' @PARMS = ' + ISNULL(@TASK_PARAMS, '')
			  + ', '
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)




--REH  Time Zone code for all procedures
IF @LAST_RUN > '1/1/1901'
  BEGIN
      IF @REMOTE_SERVER = 'N'
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @DPA_TZ_OFFSET, @LAST_RUN) --REH DPA and DB are on same server so use DPA Time Zone Offset
        END
      ELSE
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @SQL_TZ_OFFSET, @LAST_RUN)  --REH DPA and DB are on different servers so use DB Time Zone Offset
        END
  END 



BEGIN TRY
PRINT 'STARTING ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


IF @REMOTE_SERVER = 'N'
BEGIN
INSERT INTO INDEX_DETAIL
SELECT @SERVER_NAME,
       CONVERT(NVARCHAR(50), @STATS_DATE, 121),
       @DATABASE_NAME,
       si.object_id,
       si.index_id,
       CASE
         WHEN ss.NAME IN ( 'sys', 'dbo' ) THEN so.NAME
         ELSE ss.NAME + '.' + so.NAME
       END,
       si.NAME,
       si.type_desc + CASE WHEN is_unique = 1 THEN ', UNIQUE' ELSE '' END + CASE WHEN is_primary_key = 1 THEN ', PRIMARY KEY' ELSE '' END + CASE WHEN has_filter = 1 THEN ', FILTERED' ELSE '' END,
       Stuff ((SELECT ', ' + sc.NAME
               FROM   DYN_CI_INDEX_COLS sic
                      JOIN DYN_CI_SYS_COLS sc
                        ON sc.column_id = sic.column_id
               WHERE  so.object_id = sic.object_id
                      AND sic.index_id = si.index_id
                      AND sc.object_id = so.object_id
                      AND sic.is_included_column = 0
               ORDER  BY sic.key_ordinal
               FOR xml path('')), 1, 1, '') AS key_columns,
       Stuff ((SELECT ', ' + sc.NAME
               FROM   DYN_CI_INDEX_COLS sic
                      JOIN DYN_CI_SYS_COLS sc
                        ON sc.column_id = sic.column_id
               WHERE  so.object_id = sic.object_id
                      AND sic.index_id = si.index_id
                      AND sc.object_id = so.object_id
                      AND sic.is_included_column = 1
               ORDER  BY sic.key_ordinal
               FOR XML path('')), 1, 1, '') AS included_columns,
       PS.DATA_SIZE                         AS PAGE_COUNT,
       PS.ROW_COUNT                         AS ROW_COUNT,
       sp.data_compression
FROM   DYN_CI_INDEXES si
       JOIN DYN_CI_SYS_INDEXES ii
         ON si.object_id = ii.id
            AND si.index_id = ii.indid
       JOIN DYN_CI_OBJECTS so
         ON so.object_id = si.object_id
       JOIN DYN_CI_SCHEMAS ss
         ON ss.schema_id = so.schema_id
       JOIN DYN_CI_PARTITIONS sp
         ON so.object_id = sp.object_id
            AND sp.index_id = ii.indid
       INNER JOIN (SELECT object_id,
                          index_id,
                          Sum(row_count)                      AS ROW_COUNT,
                          Sum(in_row_data_page_count
                              + lob_used_page_count
                              + row_overflow_used_page_count) AS DATA_SIZE
                   FROM   DYN_CI_PARTITION_STATS
                   GROUP  BY object_id,
                             index_id) AS PS
               ON PS.index_id = si.index_id
                  AND PS.object_id = si.object_id
WHERE  so.type = 'U'
		AND PS.DATA_SIZE > 0 --REH eliminate tables with 0 records to save space
       AND si.type > 0 --other than heap tables
       AND sp.partition_number = 1 -- fix issue with partiioned tables multiplying the number or records we return

	UNION ALL
    
    SELECT @SERVER_NAME,
           CONVERT(NVARCHAR(50), @STATS_DATE, 121),
           @DATABASE_NAME,
           si.object_id,
           si.index_id,
		   CASE
			 WHEN ss.NAME IN ( 'sys', 'dbo' ) THEN so.NAME
			 ELSE ss.NAME + '.' + so.NAME
		   END,
           so.NAME,
           'HEAP',
           'N/A',
           'N/A',
           PS.DATA_SIZE AS PAGE_COUNT,
           PS.ROW_COUNT AS ROW_COUNT,
           sp.data_compression
    FROM   DYN_CI_INDEXES si
           JOIN DYN_CI_SYS_INDEXES ii
             ON si.object_id = ii.id
                AND si.index_id = ii.indid
           JOIN DYN_CI_OBJECTS so
             ON so.object_id = si.object_id
           JOIN DYN_CI_SCHEMAS ss
             ON ss.schema_id = so.schema_id
           JOIN DYN_CI_PARTITIONS sp
             ON so.object_id = sp.object_id
                AND sp.index_id = ii.indid
           INNER JOIN (SELECT object_id,
                              index_id,
                              Sum(row_count)                      AS ROW_COUNT,
                              Sum(in_row_data_page_count
                                  + lob_used_page_count
                                  + row_overflow_used_page_count) AS DATA_SIZE
                       FROM   DYN_CI_PARTITION_STATS
                       GROUP  BY object_id,
                                 index_id) AS PS
                   ON PS.index_id = si.index_id
                      AND PS.object_id = si.object_id
    WHERE  so.type = 'U'
	AND PS.DATA_SIZE > 0 --REH eliminate tables with 0 records to save space
           AND si.type = 0 --only heap tables
           AND sp.partition_number = 1 -- fix issue with partiioned tables multiplying the number or records we return
    
    
 END
 
 IF @REMOTE_SERVER = 'Y'
 BEGIN
 
 
    		SET @SQL = '	
			
			
			SELECT	
 			si.object_id,
			si.index_id,
			CASE 
			WHEN ss.name in (''sys'', ''dbo'') THEN so.name
			ELSE 
				ss.name + ''.'' + so.name
			END, 
			si.name,  
			si.type_desc+
			CASE
				WHEN is_unique = 1 THEN '', UNIQUE''
				ELSE ''''
			END
			+	
			CASE
				WHEN is_primary_key = 1 THEN '', PRIMARY KEY''
				ELSE ''''
			END
			+
			CASE
				WHEN has_filter = 1 THEN '', FILTERED''
				ELSE ''''
			END,
			

    	stuff
    		(
    				
    			(
    			SELECT '', '' + sc.name FROM	['+ @DATABASE_NAME+ '].sys.index_columns sic
    			JOIN	['+ @DATABASE_NAME+ '].sys.columns sc ON sc.column_id = sic.column_id
    			WHERE	so.object_id = sic.object_id
    			AND		sic.index_id = si.index_id
    			AND		sc.object_id = so.object_id
    			AND		sic.is_included_column=0
    			ORDER	BY sic.key_ordinal
    			FOR		xml path('''')
    			)
    		,1,1,''''
    		)  AS key_columns,
    	stuff
    		(
    			(
    			SELECT	'', '' + sc.name FROM ['+ @DATABASE_NAME+ '].sys.index_columns sic
    			JOIN	['+ @DATABASE_NAME+ '].sys.columns sc ON sc.column_id = sic.column_id
    			WHERE	so.object_id = sic.object_id
    			AND		sic.index_id = si.index_id
    			AND		sc.object_id = so.object_id
    			AND		sic.is_included_column=1
    			ORDER BY sic.key_ordinal
    			FOR XML path('''')
    			)
    		,1,1,''''
    		)  AS included_columns,
    	PS.DATA_SIZE AS PAGE_COUNT,
    	PS.ROW_COUNT AS ROW_COUNT,
    	sp.data_compression
    	FROM	 ['+ @DATABASE_NAME+ '].sys.indexes si
    	JOIN 	['+ @DATABASE_NAME+ '].sys.sysindexes ii ON si.object_id = ii.id AND si.index_id = ii.indid
    	JOIN 	['+ @DATABASE_NAME+ '].sys.objects so ON so.object_id = si.object_id
    	JOIN	 ['+ @DATABASE_NAME+ '].sys.schemas ss ON ss.schema_id = so.schema_id
    	JOIN	 ['+ @DATABASE_NAME+ '].sys.partitions sp ON so.object_id = sp.object_id AND sp.index_id = ii.indid
    	INNER JOIN  (SELECT object_id, index_id,SUM(row_count) AS ROW_COUNT,SUM(in_row_data_page_count + lob_used_page_count + row_overflow_used_page_count) AS DATA_SIZE
    	FROM ['+ @DATABASE_NAME+ '].sys.dm_db_partition_stats GROUP BY  object_id, index_id) AS PS ON PS.index_id = si.index_id AND PS.object_id = si.object_id
    	
     WHERE	so.type = ''U''
	 AND PS.DATA_SIZE > 0 --REH eliminate tables with 0 records to save space
    	AND		si.type > 0 
    	AND     sp.partition_number = 1 
    
	
	UNION ALL
    
    
SELECT	
    
			si.object_id,
			si.index_id,
			so.name, 
			CASE 
			WHEN ss.name in (''sys'', ''dbo'') THEN so.name
			ELSE 
				ss.name + ''.'' + so.name
			END, 
			''HEAP'',

			''N/A'', 
			''N/A'',
	PS.DATA_SIZE AS PAGE_COUNT,
	PS.ROW_COUNT AS ROW_COUNT,
	sp.data_compression 
    	FROM ['+ @DATABASE_NAME+ '].sys.indexes si
	JOIN ['+ @DATABASE_NAME+ '].sys.sysindexes ii ON si.object_id = ii.id AND si.index_id = ii.indid
	JOIN ['+ @DATABASE_NAME+ '].sys.objects so ON so.object_id = si.object_id
	JOIN	 ['+ @DATABASE_NAME+ '].sys.schemas ss ON ss.schema_id = so.schema_id
	JOIN ['+ @DATABASE_NAME+ '].sys.partitions sp ON so.object_id = sp.object_id AND sp.index_id = ii.indid
	
    INNER JOIN  (SELECT object_id, index_id,SUM(row_count) AS ROW_COUNT,SUM(in_row_data_page_count + lob_used_page_count + row_overflow_used_page_count) AS DATA_SIZE
	FROM ['+ @DATABASE_NAME+ '].sys.dm_db_partition_stats GROUP BY  object_id, index_id) AS PS ON PS.index_id = si.index_id AND PS.object_id = si.object_id
	
 WHERE	so.type = ''U''
	AND PS.DATA_SIZE > 0 --REH eliminate tables with 0 records to save space
	AND		si.type = 0  --only heap tables
	AND     sp.partition_number = 1 ' 


         IF @DEBUG = 'Y'
              BEGIN
                  PRINT '@SQL= ' + @SQL
              END
              
              
		SET @SQL2 = ' 
		  SET QUOTED_IDENTIFIER OFF
		  INSERT INTO DynamicsPerf.dbo.INDEX_DETAIL
						 SELECT ' + '''' + @SERVER_NAME + '''' + ',' + '''' + CONVERT(NVARCHAR(24), @STATS_DATE, 121) +'''' + ','
				  + '''' + @DATABASE_NAME + '''' + ',*
		                   FROM OPENQUERY([' + @SERVER_NAME + '], ' +'"' + @SQL +'"' + ')'


		 IF @DEBUG = 'Y'
			  BEGIN
				  PRINT '@SQL= ' + @SQL2
			  END 
		 

         EXEC(@SQL2)

 END
 
    
    
UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'SUCCESSFULLY '
              + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' Inserted ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' ROWS ' +  CHAR(10) 
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)




PRINT ''
PRINT 'SUCCESSFULLY CAPTURED ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


RETURN(0)  --REH RETURN SUCCESS


END TRY 


/********************************************************************************************************************************
*   END OF TASK
*********************************************************************************************************************************/



BEGIN CATCH
    UPDATE CAPTURE_LOG
    SET    TEXT = TEXT + 'FAILED !!! to '
	      + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
                  + ISNULL(@SERVER_NAME, '') + ' on database '
                  + ISNULL(@DATABASE_NAME, '') + ' at '
                  + CONVERT(VARCHAR, GETDATE(), 109) 
				  + ' ERROR = ' + CAST(@@ERROR AS VARCHAR(MAX))
				  + ', ' 
				  + CHAR(10)
    WHERE  STATS_TIME = @STATS_DATE
	AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)




    PRINT 'ERROR WHILE COLLECTING '
          + ISNULL(@TASK_DESC, '') + ' !!!!!!!!!!!!!!'

    RETURN(1) --REH RETURN ERROR, TRAPPED BY SPROC
END CATCH
GO
PRINT N'Altering [dbo].[DYNPERF_COLLECT_QUERY_PLANS]...';


GO

ALTER PROCEDURE DYNPERF_COLLECT_QUERY_PLANS (@TASK_ID       INT,
                                              @SERVER_NAME   NVARCHAR(128),
                                              @DATABASE_NAME NVARCHAR(128),
                                              @TASK_PARAMS   NVARCHAR(1024),
                                              @TASK_DESC     NVARCHAR(256),
                                              @LAST_RUN      DATETIME,
                                              @RUN_NAME      NVARCHAR(255),
                                              @STATS_DATE    DATETIME,
                                              @REMOTE_SERVER NVARCHAR(1),
											  @AZURE_DB		 BIT,
											  @SQL_TZ_OFFSET INT,
											  @DPA_TZ_OFFSET INT,
                                              @DEBUG         NVARCHAR(1))
AS

/************************************************************************************************************
*  SETUP
*		DECLARE VARIABLES, CREATE SYNONYMS, ETC
*
*************************************************************************************************************/


    SET NOCOUNT ON
    SET DATEFORMAT MDY

    DECLARE @SQL NVARCHAR(MAX), @SQL2 NVARCHAR(MAX), @TOPPLANPCT INT


		SELECT   @TOPPLANPCT = COLLECT_TOP_X_PLANS
	FROM   DATABASES_2_COLLECT
	WHERE  LINKED_SERVER = @SERVER_NAME
		   AND DATABASE_NAME = @DATABASE_NAME 


    
/*************************************************

--REH Template for creating a synonym, 
--Will help avoid having to use EXEC (@SQL) code
-- and make the code more dynamic to the inputs


***************************************************/

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_QP_STATS')
  EXEC ('DROP SYNONYM [dbo].DYN_QP_STATS')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_QP_STATS
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].sys.dm_exec_query_stats'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_QP_STATS
				FOR [' + @DATABASE_NAME + '].sys.dm_exec_query_stats'

EXEC (@SQL)


/********************************************************************************************************************************
*   STARTING TASK
*********************************************************************************************************************************/

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'STARTING to ' + ISNULL(@TASK_DESC, 'TASK')
              + ' for SERVER ' + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' USING PARMS @LAST_RUN ' + CAST(@LAST_RUN AS VARCHAR(30)) 
			  + ' @DPA_TZ_OFFSET = ' + CAST (@DPA_TZ_OFFSET AS VARCHAR(10))
			  + ' @SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET  AS VARCHAR(10))
			  + ' @STATS_DATE = ' + CAST(@STATS_DATE AS VARCHAR(30)) 
			  + ' @AZURE_DB = ' + CAST(@AZURE_DB AS VARCHAR(10))
			  + ' @REMOTE = ' + @REMOTE_SERVER
			  + ' @PARMS = ' + ISNULL(@TASK_PARAMS, '')
			  + ', '
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



--REH  Time Zone code for all procedures
IF @LAST_RUN > '1/1/1901'
  BEGIN
	--This value is passed back to the QUERY_STATS table that lives in the DynamicsPerf database
	SET @LAST_RUN = DATEADD(MI, @DPA_TZ_OFFSET, @LAST_RUN)

      --IF @REMOTE_SERVER = 'N'
      --  BEGIN
      --      SET @LAST_RUN = DATEADD(MI, @DPA_TZ_OFFSET, @LAST_RUN) --REH DPA and DB are on same server so use DPA Time Zone Offset
      --  END
      --ELSE
      --  BEGIN
      --      SET @LAST_RUN = DATEADD(MI, @SQL_TZ_OFFSET, @LAST_RUN)  --REH DPA and DB are on different servers so use DB Time Zone Offset
      --  END
  END 



BEGIN TRY
PRINT 'STARTING ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''

IF @REMOTE_SERVER = 'N'
BEGIN
--;WITH Query_Stats_CTE ( QUERY_PLAN_HASH, PLAN_HANDLE )
--     AS
--     -- Define the CTE query.
--     (SELECT DISTINCT QUERY_PLAN_HASH,
--                      PLAN_HANDLE
--      FROM   QUERY_STATS AS QS
--      WHERE  STATS_TIME >= @LAST_RUN
--             AND DATABASE_NAME = @DATABASE_NAME
--             AND SERVER_NAME = @SERVER_NAME 
--             AND QUERY_PLAN_HASH > 0x00000000
--             AND NOT EXISTS (SELECT 'X'
--                             FROM   QUERY_PLANS QP
--                             WHERE  QP.QUERY_PLAN_HASH = QS.QUERY_PLAN_HASH
--                                    AND QS.DATABASE_NAME = QP.DATABASE_NAME
--                                    AND QS.SERVER_NAME = QP.SERVER_NAME ))
--INSERT INTO QUERY_PLANS
--SELECT @SERVER_NAME,
--       @DATABASE_NAME,
--       QUERY_PLAN_HASH,
--       QUERY_PLAN,
--       '',
--       0,
--       0,
--       GETDATE()
--FROM   (SELECT RN = ROW_NUMBER()
--                      OVER (
--                        PARTITION BY CTE.QUERY_PLAN_HASH
--                        ORDER BY CTE.QUERY_PLAN_HASH DESC),
--               CTE.QUERY_PLAN_HASH,
--               query_plan AS QUERY_PLAN
--        FROM   Query_Stats_CTE CTE
--               OUTER APPLY sys.dm_exec_query_plan(CTE.PLAN_HANDLE)) AS RH
--WHERE  RN = 1 

SET @SQL = '

;WITH Query_Stats_CTE (  QUERY_PLAN_HASH, PLAN_HANDLE )
     AS
     (SELECT DISTINCT  QUERY_PLAN_HASH, PLAN_HANDLE FROM 
     (SELECT SERVER_NAME, DATABASE_NAME, QUERY_PLAN_HASH,
                      PLAN_HANDLE
      FROM   QUERY_STATS AS QS
      WHERE  STATS_TIME >= ' + '''' + CONVERT(NVARCHAR(24), @LAST_RUN, 121) + '''' + '
             AND DATABASE_NAME = ' + '''' + @DATABASE_NAME + ''''+ '
             AND SERVER_NAME = ' + '''' + @SERVER_NAME  + ''''
			 + ' AND DATEADD(MM,LAST_ELAPSED_TIME/60000000,LAST_EXECUTION_TIME) >= ' + '''' +CONVERT(NVARCHAR(24), @LAST_RUN, 121) + '''' 
            + ' AND QUERY_PLAN_HASH > 0x00000000
             
         
                                   ) AS A
					WHERE  NOT EXISTS (SELECT ''X''
                             FROM   QUERY_PLANS QP
                             WHERE  QP.QUERY_PLAN_HASH = A.QUERY_PLAN_HASH
                                    AND QP.DATABASE_NAME = A.DATABASE_NAME
                                    AND QP.SERVER_NAME = A.SERVER_NAME )	  
						AND EXISTS (SELECT TOP ' + CAST(@TOPPLANPCT AS VARCHAR(4)) + ' PERCENT  CASE WHEN (QH.SQL_TEXT LIKE ' + '''' + '%TEMPDB.%DBO%.T%' + '''' + ' ) THEN NULL ELSE ''X'' END 
									FROM QUERY_HISTORY_VW QH
									WHERE QH.SERVER_NAME = A.SERVER_NAME 
										AND QH.DATABASE_NAME = A.DATABASE_NAME
										AND QH.QUERY_PLAN_HASH = A.QUERY_PLAN_HASH
										
										AND FLAG = ''D'' AND DATE = ' + '''' + CAST ((SELECT dateadd(DAY,datediff(DAY,0,@STATS_DATE),0)) AS VARCHAR(50)) + ''''
										+ CHAR(10) +  '  ORDER BY TOTAL_ELAPSED_TIME DESC )
								   
								   
								   )
INSERT INTO QUERY_PLANS
SELECT ' + '''' +@SERVER_NAME+ ''''+',
       '+ '''' +@DATABASE_NAME+ ''''+',
       QUERY_PLAN_HASH,
       QUERY_PLAN,
       '''',
       0,
       0,
       GETDATE()
FROM   (SELECT RN = ROW_NUMBER()
                      OVER (
                        PARTITION BY CTE.QUERY_PLAN_HASH
                        ORDER BY CTE.QUERY_PLAN_HASH DESC),
               CTE.QUERY_PLAN_HASH,
               query_plan AS QUERY_PLAN
        FROM   Query_Stats_CTE CTE
               OUTER APPLY sys.dm_exec_query_plan(CTE.PLAN_HANDLE)) AS RH
WHERE  RN = 1 AND query_plan IS NOT NULL'

IF @DEBUG = 'Y'
BEGIN
	PRINT @SQL
END


EXEC (@SQL)



END

IF @REMOTE_SERVER = 'Y'
     BEGIN
SET @SQL = '

IF EXISTS (SELECT * FROM  [tempdb].sys.objects WHERE name = ''DYNPERF_QUERY_HASH'') 
 DROP TABLE  [tempdb].dbo.DYNPERF_QUERY_HASH '
				 
			SET @SQL2 = ' 
							  SET QUOTED_IDENTIFIER OFF
							  EXEC (' + '"' + @SQL + '"' + ') AT ['
						+ @SERVER_NAME + ']' 


         IF @DEBUG = 'Y'
              BEGIN
                  PRINT '@SQL= ' + @SQL2
              END

         EXEC (@SQL2)


         SET @SQL = '
				CREATE TABLE [tempdb].dbo.DYNPERF_QUERY_HASH
				(
				QUERY_PLAN_HASH VARBINARY(64), 
				PLAN_HANDLE VARBINARY(64)
				)'


         SET @SQL2 = ' 
				  SET QUOTED_IDENTIFIER OFF
				  EXEC (' + '"' + @SQL + '"' + ') AT [' + @SERVER_NAME
									 + ']'

         IF @DEBUG = 'Y'
              BEGIN
                  PRINT '@SQL= ' + @SQL2
              END

         EXEC (@SQL2)

         SET @SQL = '

					;WITH Query_Stats_CTE ( QUERY_PLAN_HASH, PLAN_HANDLE)
						 AS (SELECT DISTINCT  QUERY_PLAN_HASH, PLAN_HANDLE FROM 
						(SELECT  SERVER_NAME, DATABASE_NAME, QUERY_PLAN_HASH,
							PLAN_HANDLE
							 FROM   QUERY_STATS QS
							 WHERE  QS.STATS_TIME >= ' + ''''
										+ CONVERT(NVARCHAR(24), @LAST_RUN, 121)
										+ ''''
										+ '
									AND DATABASE_NAME = '
										+ '''' + @DATABASE_NAME + ''''
										+ '
									AND SERVER_NAME = ' + '''' +
										+ @SERVER_NAME + ''''
										+ ' AND DATEADD(Mm,LAST_ELAPSED_TIME/60000000,LAST_EXECUTION_TIME) >= ' + '''' +CONVERT(NVARCHAR(24), @LAST_RUN, 121) + '''' 
            + ' AND QUERY_PLAN_HASH > 0x00000000
					
                                   ) AS A
								   WHERE  NOT EXISTS (SELECT ''X''
													FROM   QUERY_PLANS QP
												 WHERE  QP.QUERY_PLAN_HASH = A.QUERY_PLAN_HASH
														AND QP.DATABASE_NAME = A.DATABASE_NAME
														AND QP.SERVER_NAME = A.SERVER_NAME)
										AND EXISTS (SELECT TOP ' + CAST(@TOPPLANPCT AS VARCHAR(4)) + ' PERCENT CASE WHEN (QH.SQL_TEXT LIKE ' + '''' + '%TEMPDB.%DBO%.T%' + '''' + ' ) THEN NULL ELSE ''X''  END  ''X'' 
										FROM QUERY_HISTORY_VW QH
											WHERE QH.SERVER_NAME = A.SERVER_NAME 
												AND QH.DATABASE_NAME = A.DATABASE_NAME
												AND QH.QUERY_PLAN_HASH = A.QUERY_PLAN_HASH
												
												AND FLAG = ''D'' AND DATE = ' + '''' + CAST ((SELECT dateadd(DAY,datediff(DAY,0,@STATS_DATE),0)) AS VARCHAR(50)) +''''
											+ CHAR(10) + '  ORDER BY TOTAL_ELAPSED_TIME DESC )
								   
								   )

						INSERT INTO OPENQUERY([' + @SERVER_NAME
										+ '], ''SELECT QUERY_PLAN_HASH, PLAN_HANDLE FROM '
										+ '[tempdb].dbo.DYNPERF_QUERY_HASH'')
					                            
					  
					SELECT QUERY_PLAN_HASH, PLAN_HANDLE 
					FROM   (SELECT RN = ROW_NUMBER()
										  OVER (
											PARTITION BY CTE.QUERY_PLAN_HASH, CTE.PLAN_HANDLE
											ORDER BY CTE.QUERY_PLAN_HASH, CTE.PLAN_HANDLE DESC),
								   CTE.QUERY_PLAN_HASH, CTE.PLAN_HANDLE 
					            
								FROM   Query_Stats_CTE CTE
							   ) AS RH
					WHERE  RN = 1  '

		IF @DEBUG = 'Y'
			 BEGIN
				 PRINT '@SQL= ' + @SQL
			 END 


         EXEC(@SQL)

			SET @SQL = 'SELECT 
				   QUERY_PLAN_HASH,
				   cast(query_plan as nvarchar(max)) as QUERY_PLAN

			FROM   (SELECT RN = ROW_NUMBER()
								  OVER (
									PARTITION BY QUERY_PLAN_HASH
									ORDER BY QUERY_PLAN_HASH DESC),
						   QUERY_PLAN_HASH,
						   query_plan 
					FROM   [tempdb].dbo.DYNPERF_QUERY_HASH CTE
						   OUTER APPLY sys.dm_exec_query_plan(CTE.PLAN_HANDLE)) AS RH
			WHERE  RN = 1 AND query_plan IS NOT NULL' 


         IF @DEBUG = 'Y'
              BEGIN
                  PRINT '@SQL= ' + @SQL
              END
              
              
		SET @SQL2 = ' 
		  SET QUOTED_IDENTIFIER OFF
		  INSERT INTO DynamicsPerf.dbo.QUERY_PLANS
						 SELECT ' + '''' + @SERVER_NAME + '''' + ',' + ''''
					+ @DATABASE_NAME + ''''
					+ ',
		                    QUERY_PLAN_HASH, CAST(QUERY_PLAN AS XML), ' + QUOTENAME('','''') + ',0,0,GETDATE() FROM OPENQUERY([' + @SERVER_NAME + '], ' +'"' + @SQL +'"' + ')' --RH '
					--		RH.QUERY_PLAN_HASH, RH.QUERY_PLAN, '''', 0, 0, GETDATE() FROM OPENQUERY(['
					--+ @SERVER_NAME + '], ' + ''' + @SQL + ''' + ') RH ' 

		 IF @DEBUG = 'Y'
			  BEGIN
				  PRINT '@SQL= ' + @SQL2
			  END 
		 

         EXEC(@SQL2)
         

		 --REH Drop the table at the end of the process

         SET @SQL = '

				IF EXISTS (SELECT * FROM  [tempdb].sys.objects WHERE name = ''DYNPERF_QUERY_HASH'') 
				 DROP TABLE  [tempdb].dbo.DYNPERF_QUERY_HASH '
				 
			SET @SQL2 = ' 
							  SET QUOTED_IDENTIFIER OFF
							  EXEC (' + '"' + @SQL + '"' + ') AT ['
						+ @SERVER_NAME + ']' 


         IF @DEBUG = 'Y'
              BEGIN
                  PRINT '@SQL= ' + @SQL2
              END

         EXEC (@SQL2)
     
     END 





UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'SUCCESSFULLY '
              + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' Inserted ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' ROWS ' +  CHAR(10) 
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)


PRINT ''
PRINT 'SUCCESSFULLY CAPTURED ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


RETURN(0)  --REH RETURN SUCCESS


END TRY 


/********************************************************************************************************************************
*   END OF TASK
*********************************************************************************************************************************/


BEGIN CATCH
    UPDATE CAPTURE_LOG
    SET    TEXT = TEXT + 'FAILED !!! to '
	      + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
                  + ISNULL(@SERVER_NAME, '') + ' on database '
                  + ISNULL(@DATABASE_NAME, '') + ' at '
                  + CONVERT(VARCHAR, GETDATE(), 109) 
				  + ' ERROR = ' + CAST(@@ERROR AS VARCHAR(MAX))
				  + ', ' 
				  + CHAR(10)
    WHERE  STATS_TIME = @STATS_DATE
	AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



    PRINT 'ERROR WHILE COLLECTING '
          + ISNULL(@TASK_DESC, '') + ' !!!!!!!!!!!!!!'

    RETURN(1) --REH RETURN ERROR, TRAPPED BY SPROC
END CATCH
GO
PRINT N'Altering [dbo].[DYNPERF_COLLECT_QUERY_STATS]...';


GO

ALTER PROCEDURE DYNPERF_COLLECT_QUERY_STATS (@TASK_ID       INT,
                                              @SERVER_NAME   NVARCHAR(128),
                                              @DATABASE_NAME NVARCHAR(128),
                                              @TASK_PARAMS   NVARCHAR(1024),
                                              @TASK_DESC     NVARCHAR(256),
                                              @LAST_RUN      DATETIME,
                                              @RUN_NAME      NVARCHAR(255),
                                              @STATS_DATE    DATETIME,
                                              @REMOTE_SERVER NVARCHAR(1),
											  @AZURE_DB		 BIT,
											  @SQL_TZ_OFFSET INT,
											  @DPA_TZ_OFFSET INT,
                                              @DEBUG         NVARCHAR(1))
AS


/************************************************************************************************************
*  SETUP
*		DECLARE VARIABLES, CREATE SYNONYMS, ETC
*
*************************************************************************************************************/

    SET NOCOUNT ON
    SET DATEFORMAT MDY

    DECLARE @SQL NVARCHAR(MAX), @SQL2 NVARCHAR(MAX), @SQL_BUILD NVARCHAR(128), @MIN_TIME INT, @TOPQUERYPCT INT

	--REH Get the build so we can add the new columns to the query_stats table from SQL2016 and above
    SELECT @SQL_BUILD = SQL_VERSION  FROM STATS_COLLECTION_SUMMARY SCS WHERE SERVER_NAME = @SERVER_NAME AND DATABASE_NAME=@DATABASE_NAME AND STATS_TIME = @STATS_DATE
    

	--REH Get the Minimum time for queries to collect
	SELECT @MIN_TIME = [IGNORE_QUERIES_UNDER_MS],
		   @TOPQUERYPCT = COLLECT_TOP_X_QUERIES
	FROM   DATABASES_2_COLLECT
	WHERE  LINKED_SERVER = @SERVER_NAME
		   AND DATABASE_NAME = @DATABASE_NAME 



/*************************************************

--REH Template for creating a synonym, 
--Will help avoid having to use EXEC (@SQL) code
-- and make the code more dynamic to the inputs


***************************************************/

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_QS_STATS')
  EXEC ('DROP SYNONYM [dbo].DYN_QS_STATS') 
  
IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_PLAN_ATTRIBUTES')
  EXEC ('DROP SYNONYM [dbo].DYN_PLAN_ATTRIBUTES')



         SET @SQL = '
				CREATE SYNONYM DYN_QS_STATS
				FOR [' + @DATABASE_NAME + '].sys.dm_exec_query_stats'

EXEC (@SQL)


         SET @SQL = '
				CREATE SYNONYM DYN_PLAN_ATTRIBUTES
				FOR [' + @DATABASE_NAME + '].sys.dm_exec_plan_attributes'

EXEC (@SQL)


/********************************************************************************************************************************
*   STARTING TASK
*********************************************************************************************************************************/

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'STARTING to ' + ISNULL(@TASK_DESC, 'TASK')
              + ' for SERVER ' + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' USING PARMS @LAST_RUN ' + CAST(@LAST_RUN AS VARCHAR(30)) 
			  + ' @DPA_TZ_OFFSET = ' + CAST (@DPA_TZ_OFFSET AS VARCHAR(10))
			  + ' @SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET  AS VARCHAR(10))
			  + ' @STATS_DATE = ' + CAST(@STATS_DATE AS VARCHAR(30)) 
			  + ' @AZURE_DB = ' + CAST(@AZURE_DB AS VARCHAR(10))
			  + ' @REMOTE = ' + @REMOTE_SERVER
			  + ' @PARMS = ' + ISNULL(@TASK_PARAMS, '')
			  + ', '
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)




--REH  Time Zone code for all procedures
IF @LAST_RUN > '1/1/1901'
  BEGIN
      IF @REMOTE_SERVER = 'N'
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @DPA_TZ_OFFSET, @LAST_RUN) --REH DPA and DB are on same server so use DPA Time Zone Offset
        END
      ELSE
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @SQL_TZ_OFFSET, @LAST_RUN)  --REH DPA and DB are on different servers so use DB Time Zone Offset
        END
  END 





PRINT 'TIME ZONE OFFSET AT TASK ' + CAST(@DPA_TZ_OFFSET AS VARCHAR(10))
PRINT 'LAST RUN AT TASK ' + CAST(@LAST_RUN AS VARCHAR(20))


PRINT 'LAST RUN WITH OFFSET ' + CAST(@LAST_RUN AS VARCHAR(20))
 


BEGIN TRY
PRINT 'STARTING ' + ISNULL(@TASK_DESC, ' TASK')
PRINT ''




IF @DEBUG = 'Y'
  BEGIN
      PRINT '@LAST_RUN = '

      PRINT @LAST_RUN
  END 
  
  
  IF @REMOTE_SERVER = 'N'
       BEGIN
			--IF @SQL_BUILD >= '13.' --REH  SQL2016 or above
		          
 SET @SQL =  ' INSERT INTO DynamicsPerf.dbo.QUERY_STATS

          SELECT TOP ' + CAST(@TOPQUERYPCT AS VARCHAR(4)) + ' PERCENT   MIN(' + '''' + @SERVER_NAME + '''' + '), MAX(' + '''' + CONVERT(NVARCHAR(24), @STATS_DATE, 121) +'''' + '),MIN('
				  + '''' + @DATABASE_NAME + '''' + '), 
                  MIN(qs.plan_handle),
                  MAX(plan_generation_num),
                  creation_time,
                  MAX(last_execution_time),
                  SUM(execution_count),
                  SUM(total_worker_time),
                  AVG(last_worker_time),
                  MIN(min_worker_time),
                  MAX(max_worker_time),
                  SUM(total_physical_reads),
                  AVG(last_physical_reads),
                  MIN(min_physical_reads),
                  MAX(max_physical_reads),
                  SUM(total_logical_writes),
                  AVG(last_logical_writes),
                  MIN(min_logical_writes),
                  MAX(max_logical_writes),
                  SUM(total_logical_reads),
                  AVG(last_logical_reads),
                  MIN(min_logical_reads),
                  MAX(max_logical_reads),
                  SUM(total_clr_time),
                  AVG(last_clr_time),
                  MIN(min_clr_time),
                  MAX(max_clr_time),
                  SUM(total_elapsed_time),
                  AVG(last_elapsed_time),
                  MIN(min_elapsed_time),
                  MAX(max_elapsed_time),
                  qs.query_hash,
                  qs.query_plan_hash,
                  SUM ( total_rows),
                  SUM ( last_rows),
                  MAX ( max_rows),
                  MIN ( min_rows),'

				  IF @SQL_BUILD >= '13.' or (@SQL_BUILD >= '11.0.6020' and @SQL_BUILD < '12.') --REH correct build per version
				  BEGIN
					  SELECT @SQL = @SQL + 'SUM(total_dop), AVG(last_dop), MIN(min_dop), MAX(max_dop) '

				  END
				  ELSE
				  BEGIN
					SELECT @SQL = @SQL + 'SUM(-1), SUM(-1), SUM(-1), SUM(-1) '


				  END
SELECT @SQL = @SQL + '

           FROM   sys.dm_exec_query_stats qs
                  OUTER APPLY sys.dm_exec_plan_attributes (qs.plan_handle)
				  CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
           WHERE  attribute = N''dbid'' AND query_hash > 0x00000000000000000000000000000
                  AND DB_NAME(CONVERT(INT, value)) = ' + QUOTENAME(@DATABASE_NAME, '''') + '
                  AND dateadd(ms,last_elapsed_time/1000,last_execution_time) >= ''' +CONVERT(NVARCHAR(24), @LAST_RUN, 121) + '''
				AND NOT (st.text like ' + '''' + '%tempdb.%DBO%.T%' + '''' + ' 
					 AND  qs.total_elapsed_time / case execution_count WHEN 0 then 1 ELSE execution_count end / 1000.00 < 100.0 ) 
		   GROUP  BY query_hash,
                     query_plan_hash,
					 creation_time
			HAVING SUM(total_elapsed_time) / CASE SUM(execution_count) WHEN 0 THEN 1 ELSE SUM(execution_count) end / 1000.000 > ' + CAST(@MIN_TIME AS VARCHAR(4))
			+ ' ORDER BY SUM(total_elapsed_time)  DESC '
					 


					 
			IF @DEBUG = 'Y'
			  BEGIN
				  PRINT @SQL
			  END 
  
			  EXEC (@SQL)

		END

  IF @REMOTE_SERVER = 'Y'
       BEGIN
       
    

           --INSERT INTO QUERY_STATS
           
 SET @SQL = ' SET DATEFORMAT MDY 
           SELECT TOP ' + CAST(@TOPQUERYPCT AS VARCHAR(4)) + ' PERCENT 
                  MIN(qs.plan_handle),
                  MAX(plan_generation_num),
                  creation_time,
                  MAX(last_execution_time),
                  SUM(execution_count),
                  SUM(total_worker_time),
                  AVG(last_worker_time),
                  MIN(min_worker_time),
                  MAX(max_worker_time),
                  SUM(total_physical_reads),
                  AVG(last_physical_reads),
                  MIN(min_physical_reads),
                  MAX(max_physical_reads),
                  SUM(total_logical_writes),
                  AVG(last_logical_writes),
                  MIN(min_logical_writes),
                  MAX(max_logical_writes),
                  SUM(total_logical_reads),
                  AVG(last_logical_reads),
                  MIN(min_logical_reads),
                  MAX(max_logical_reads),
                  SUM(total_clr_time),
                  AVG(last_clr_time),
                  MIN(min_clr_time),
                  MAX(max_clr_time),
                  SUM(total_elapsed_time),
                  AVG(last_elapsed_time),
                  MIN(min_elapsed_time),
                  MAX(max_elapsed_time),
                  qs.query_hash,
                  qs.query_plan_hash,
                  SUM ( total_rows),
                  SUM ( last_rows),
                  MAX ( max_rows),
                  MIN ( min_rows),'

				   IF @SQL_BUILD >= '13.' or (@SQL_BUILD >= '11.0.6020' and @SQL_BUILD < '12.') --REH correct build per version
				  BEGIN
					  SELECT @SQL = @SQL + 'SUM(total_dop), AVG(last_dop), MIN(min_dop), MAX(max_dop) '

				  END
				  ELSE
				  BEGIN
					SELECT @SQL = @SQL + 'SUM(-1), SUM(-1), SUM(-1), SUM(-1) '


				  END
SELECT @SQL = @SQL + '

           FROM   sys.dm_exec_query_stats qs
                  OUTER APPLY sys.dm_exec_plan_attributes (plan_handle)
				  CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
           WHERE  attribute = N''dbid'' AND query_hash > 0x00000000000000000000000000000
                  AND DB_NAME(CONVERT(INT, value)) = ' + QUOTENAME(@DATABASE_NAME, '''') + '
                  AND dateadd(ms,last_elapsed_time/1000,last_execution_time) >= ''' +CONVERT(NVARCHAR(24), @LAST_RUN, 121) + '''
           AND NOT (st.text like ' + '''' + '%tempdb.%DBO%.T%' + '''' + ' 
					AND qs.total_elapsed_time / case execution_count WHEN 0 then 1 ELSE execution_count end /1000.000 < 100.0 ) 
		  
		   GROUP  BY query_hash,
                     query_plan_hash,
					 creation_time
					 HAVING SUM(total_elapsed_time) / CASE SUM(execution_count) WHEN 0 THEN 1 ELSE SUM(execution_count) end / 1000.000 > ' + CAST(@MIN_TIME AS VARCHAR(4))
                    + ' ORDER BY SUM(total_elapsed_time)  DESC '



                    SET @SQL2 = ' 
  SET QUOTED_IDENTIFIER OFF
  INSERT INTO DynamicsPerf.dbo.QUERY_STATS
				 SELECT ' + '''' + @SERVER_NAME + '''' + ',' + '''' + CONVERT(NVARCHAR(24), @STATS_DATE, 121) +'''' + ','
				  + '''' + @DATABASE_NAME + '''' + ',
                    
                    RH.* FROM OPENQUERY([' + @SERVER_NAME + '], ' +'"' + @SQL +'"' + ') RH '

				 
				 EXECUTE (@SQL2)
				 
       END 
  




UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'SUCCESSFULLY '
              + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' Inserted ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' ROWS ' +  CHAR(10) 
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)


PRINT ''
PRINT 'SUCCESSFULLY CAPTURED ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


RETURN(0)  --REH RETURN SUCCESS


END TRY 


/********************************************************************************************************************************
*   END OF TASK
*********************************************************************************************************************************/



BEGIN CATCH
    UPDATE CAPTURE_LOG
    SET    TEXT = TEXT + 'FAILED !!! to '
	      + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
                  + ISNULL(@SERVER_NAME, '') + ' on database '
                  + ISNULL(@DATABASE_NAME, '') + ' at '
                  + CONVERT(VARCHAR, GETDATE(), 109) 
				  + ' ERROR = ' + CAST(@@ERROR AS VARCHAR(MAX))
				  + ', ' 
				  + CHAR(10)
    WHERE  STATS_TIME = @STATS_DATE
	AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



    PRINT 'ERROR WHILE COLLECTING '
          + ISNULL(@TASK_DESC, '') + ' !!!!!!!!!!!!!!'

    RETURN(1) --REH RETURN ERROR, TRAPPED BY SPROC
END CATCH
GO
PRINT N'Altering [dbo].[DYNPERF_COLLECT_SQL_TEXT]...';


GO

ALTER PROCEDURE DYNPERF_COLLECT_SQL_TEXT (@TASK_ID       INT,
                                              @SERVER_NAME   NVARCHAR(128),
                                              @DATABASE_NAME NVARCHAR(128),
                                              @TASK_PARAMS   NVARCHAR(1024),
                                              @TASK_DESC     NVARCHAR(256),
                                              @LAST_RUN      DATETIME,
                                              @RUN_NAME      NVARCHAR(255),
                                              @STATS_DATE    DATETIME,
                                              @REMOTE_SERVER NVARCHAR(1),
											  @AZURE_DB		 BIT,
											  @SQL_TZ_OFFSET INT,
											  @DPA_TZ_OFFSET INT,
                                              @DEBUG         NVARCHAR(1))
AS

/************************************************************************************************************
*  SETUP
*		DECLARE VARIABLES, CREATE SYNONYMS, ETC
*
*************************************************************************************************************/

    SET NOCOUNT ON
    SET DATEFORMAT MDY

    DECLARE @SQL NVARCHAR(MAX), @SQL2 NVARCHAR(MAX)
    
/********************************************************************************************************************************
*   STARTING TASK
*********************************************************************************************************************************/

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'STARTING to ' + ISNULL(@TASK_DESC, 'TASK')
              + ' for SERVER ' + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' USING PARMS @LAST_RUN ' + CAST(@LAST_RUN AS VARCHAR(30)) 
			  + ' @DPA_TZ_OFFSET = ' + CAST (@DPA_TZ_OFFSET AS VARCHAR(10))
			  + ' @SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET  AS VARCHAR(10))
			  + ' @STATS_DATE = ' + CAST(@STATS_DATE AS VARCHAR(30)) 
			  + ' @AZURE_DB = ' + CAST(@AZURE_DB AS VARCHAR(10))
			  + ' @REMOTE = ' + @REMOTE_SERVER
			  + ' @PARMS = ' + ISNULL(@TASK_PARAMS, '')
			  + ', '
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)





--REH  Time Zone code for all procedures
IF @LAST_RUN > '1/1/1901'
  BEGIN
	--This value is passed back to the QUERY_STATS table that lives in the DynamicsPerf database
	SET @LAST_RUN = DATEADD(MI, @DPA_TZ_OFFSET, @LAST_RUN)

      --IF @REMOTE_SERVER = 'N'
      --  BEGIN
      --      SET @LAST_RUN = DATEADD(MI, @DPA_TZ_OFFSET, @LAST_RUN) --REH DPA and DB are on same server so use DPA Time Zone Offset
      --  END
      --ELSE
      --  BEGIN
      --      SET @LAST_RUN = DATEADD(MI, @SQL_TZ_OFFSET, @LAST_RUN)  --REH DPA and DB are on different servers so use DB Time Zone Offset
      --  END
  END 




BEGIN TRY
PRINT 'STARTING ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''



IF @REMOTE_SERVER = 'N'
     BEGIN ;
         WITH Query_Stats_CTE ( QUERY_HASH, PLAN_HANDLE)
              AS (SELECT DISTINCT QUERY_HASH, PLAN_HANDLE
                  FROM   QUERY_STATS QS
                  WHERE  QS.STATS_TIME >= @LAST_RUN
                         AND DATABASE_NAME = @DATABASE_NAME
                         AND SERVER_NAME = @SERVER_NAME 
						-- AND DATEADD(MS,LAST_ELAPSED_TIME/1000,LAST_EXECUTION_TIME) >= @LAST_RUN
                         AND NOT EXISTS (SELECT 'X'
                                         FROM   QUERY_TEXT QT
                                         WHERE  QS.QUERY_HASH = QT.QUERY_HASH
                                                AND QS.DATABASE_NAME = QT.DATABASE_NAME
                                                AND QS.SERVER_NAME = QT.SERVER_NAME ))
         INSERT QUERY_TEXT
         SELECT @SERVER_NAME,
                @DATABASE_NAME,
                QUERY_HASH,
                SQL_TEXT,
				@STATS_DATE
         FROM   (SELECT RN = ROW_NUMBER()
                               OVER (
                                 PARTITION BY CTE.QUERY_HASH
                                 ORDER BY CTE.QUERY_HASH DESC),
                        qs.query_hash                                                                                              AS QUERY_HASH,
                        SUBSTRING(st.text, ( qs.statement_start_offset / 2 ) + 1, ( ( CASE qs.statement_end_offset
                                                                                        WHEN -1 THEN DATALENGTH(st.text)
                                                                                        ELSE qs.statement_end_offset
                                                                                      END - qs.statement_start_offset ) / 2 ) + 1) AS SQL_TEXT
                 FROM   Query_Stats_CTE CTE
                        INNER JOIN sys.dm_exec_query_stats AS qs
                                ON CTE.QUERY_HASH = qs.query_hash and CTE.PLAN_HANDLE = qs.plan_handle
                        OUTER APPLY sys.dm_exec_plan_attributes (qs.plan_handle)
                        CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
                 WHERE  attribute = N'dbid'
                        AND DB_NAME(CONVERT(INT, value)) = @DATABASE_NAME
                        AND last_execution_time >= @LAST_RUN
						) AS RH
         WHERE  RN = 1
     END 


 IF @REMOTE_SERVER = 'Y'
 BEGIN
 


				 
SET @SQL = '

IF EXISTS (SELECT * FROM  [tempdb].sys.objects WHERE name = ''DYNPERF_QUERY_HASH'') 
 DROP TABLE  [tempdb].dbo.DYNPERF_QUERY_HASH '
				 
			SET @SQL2 = ' 
							  SET QUOTED_IDENTIFIER OFF
							  EXEC (' + '"' + @SQL + '"' + ') AT ['
						+ @SERVER_NAME + ']' 


         IF @DEBUG = 'Y'
              BEGIN
                  PRINT '@SQL= ' + @SQL2
              END

         EXEC (@SQL2)



 SET @SQL = '
CREATE TABLE  [tempdb].dbo.DYNPERF_QUERY_HASH
(
QUERY_HASH VARBINARY(64),
PLAN_HANDLE VARBINARY(64)
)' 



 SET @SQL2 = ' 
  SET QUOTED_IDENTIFIER OFF
  EXEC ('+'"' + @SQL +'"' + ') AT [' + @SERVER_NAME + ']'
  
 IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL2
END

EXEC (@SQL2)


SET @SQL = '

;WITH Query_Stats_CTE ( QUERY_HASH, PLAN_HANDLE)
     AS (SELECT DISTINCT QUERY_HASH,PLAN_HANDLE
         FROM   QUERY_STATS QS
         WHERE  QS.STATS_TIME >= '  +'''' + CONVERT(NVARCHAR(24), @LAST_RUN, 121) +'''' +  '
                AND DATABASE_NAME = ' + '''' + @DATABASE_NAME + '''' + '
                AND SERVER_NAME = ' + '''' + +@SERVER_NAME + '''' 
				--+ ' AND DATEADD(MS,LAST_ELAPSED_TIME/1000,LAST_EXECUTION_TIME) >= ' + '''' +CONVERT(NVARCHAR(24), @LAST_RUN, 121) + '''' 
				+ ' AND NOT EXISTS (SELECT ''X''
                                FROM   QUERY_TEXT QT
                                WHERE  QS.QUERY_HASH = QT.QUERY_HASH
                                AND QS.DATABASE_NAME = QT.DATABASE_NAME
                                AND QS.SERVER_NAME = QT.SERVER_NAME 
                                ))
INSERT INTO OPENQUERY([' + @SERVER_NAME + '], ''SELECT QUERY_HASH, PLAN_HANDLE FROM  [tempdb].dbo.DYNPERF_QUERY_HASH'')

SELECT QUERY_HASH, PLAN_HANDLE
FROM   (SELECT RN = ROW_NUMBER()
                      OVER (
                        PARTITION BY CTE.QUERY_HASH, CTE.PLAN_HANDLE
                        ORDER BY CTE.QUERY_HASH ,  CTE.PLAN_HANDLE DESC),
               QUERY_HASH,
			   PLAN_HANDLE
            
            FROM   Query_Stats_CTE CTE
           ) AS RH
WHERE  RN = 1 '

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END


EXEC (@SQL)


        
 SET @SQL = '
         SELECT QUERY_HASH, SQL_TEXT
         FROM (
         SELECT RN = ROW_NUMBER() OVER (PARTITION BY CTE.QUERY_HASH ORDER BY CTE.QUERY_HASH DESC),
          qs.query_hash AS QUERY_HASH,
                         SUBSTRING(st.text, ( qs.statement_start_offset / 2 ) + 1, ( ( CASE qs.statement_end_offset
                                                                                         WHEN -1 THEN DATALENGTH(st.text)
                                                                                         ELSE qs.statement_end_offset
                                                                                       END - qs.statement_start_offset ) / 2 ) + 1) AS SQL_TEXT
         FROM    [tempdb].dbo.DYNPERF_QUERY_HASH CTE
                INNER JOIN sys.dm_exec_query_stats AS qs
                        ON CTE.QUERY_HASH = qs.query_hash AND CTE.PLAN_HANDLE = qs.plan_handle
                OUTER APPLY sys.dm_exec_plan_attributes (qs.plan_handle)
                CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
         WHERE  attribute = N''dbid''
                AND DB_NAME(CONVERT(INT, value)) = ' + QUOTENAME(@DATABASE_NAME, '''') + '
				AND last_execution_time >= ' +'''' + CONVERT(NVARCHAR(24), @LAST_RUN, 121) +'''' + '
                ) AS RH  
                WHERE RN = 1 '
PRINT ''
PRINT ''
                  
IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END


                    SET @SQL2 = ' 
  SET QUOTED_IDENTIFIER OFF
  INSERT INTO DynamicsPerf.dbo.QUERY_TEXT
				 SELECT ' + '''' + @SERVER_NAME + '''' + ',' + '''' + @DATABASE_NAME + '''' + ',
                    
                    RH.*, ' + '''' + CONVERT(NVARCHAR(24), @STATS_DATE, 121) +'''' + ' FROM OPENQUERY([' + @SERVER_NAME + '], ' +'"' + @SQL +'"' + ') RH '


IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL2
END
				 
				 EXECUTE (@SQL2)
				 
 --REH  Delete the table back out
 
 
SET @SQL = '

IF EXISTS (SELECT * FROM  [tempdb].sys.objects WHERE name = ''DYNPERF_QUERY_HASH'') 
 DROP TABLE  [tempdb].dbo.DYNPERF_QUERY_HASH '
				 
			SET @SQL2 = ' 
							  SET QUOTED_IDENTIFIER OFF
							  EXEC (' + '"' + @SQL + '"' + ') AT ['
						+ @SERVER_NAME + ']' 


         IF @DEBUG = 'Y'
              BEGIN
                  PRINT '@SQL= ' + @SQL2
              END

         EXEC (@SQL2)

 
 END
 
    

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'SUCCESSFULLY '
              + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' Inserted ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' ROWS ' +  CHAR(10) 
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



PRINT ''
PRINT 'SUCCESSFULLY CAPTURED ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


RETURN(0)  --REH RETURN SUCCESS


END TRY 


/********************************************************************************************************************************
*   END OF TASK
*********************************************************************************************************************************/


BEGIN CATCH
    UPDATE CAPTURE_LOG
    SET    TEXT = TEXT + 'FAILED !!! to '
	      + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
                  + ISNULL(@SERVER_NAME, '') + ' on database '
                  + ISNULL(@DATABASE_NAME, '') + ' at '
                  + CONVERT(VARCHAR, GETDATE(), 109) 
				  + ' ERROR = ' + CAST(@@ERROR AS VARCHAR(MAX))
				  + ', ' 
				  + CHAR(10)
    WHERE  STATS_TIME = @STATS_DATE
	AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



    PRINT 'ERROR WHILE COLLECTING '
          + ISNULL(@TASK_DESC, '') + ' !!!!!!!!!!!!!!'

    RETURN(1) --REH RETURN ERROR, TRAPPED BY SPROC
END CATCH
GO
PRINT N'Altering [dbo].[DYNPERF_COLLECT_SSRS_EXECUTIONLOG]...';


GO

ALTER PROCEDURE DYNPERF_COLLECT_SSRS_EXECUTIONLOG (
											  @DEBUG         NVARCHAR(1))
AS

/************************************************************************************************************
*  SETUP
*		DECLARE VARIABLES, CREATE SYNONYMS, ETC
*
*************************************************************************************************************/

    SET NOCOUNT ON
    SET DATEFORMAT MDY

DECLARE @SQL              NVARCHAR(MAX),
        @SQL2             NVARCHAR(MAX),
        @C_SERVER_NAME    NVARCHAR(128),
        @C_LAST_COLLECTED DATETIME,
        @UTC_TIME         DATETIME,
        @ROW_COUNT        BIGINT = 0,
        @C_DATABASE_NAME  NVARCHAR(128),
        @REMOTE_SERVER    NVARCHAR(1) = 'Y',
        @STATS_DATE       DATETIME = GETDATE(),
        @SQL_TZ_OFFSET    INT,
        @DPA_TZ_OFFSET    INT,
        @TASK_ID          INT,
        @SERVER_NAME      NVARCHAR(128),
        @DATABASE_NAME    NVARCHAR(128),
        @LAST_RUN         DATETIME 

		

    
 INSERT CAPTURE_LOG  SELECT 'SSRS', @STATS_DATE, 'STARTING to COLLECT SSRS ExecutionLog2  @DEBUG = ' + @DEBUG + '  ' + CHAR(10) + CHAR(13)

   
    
/********************************************************************************************************************************
*   STARTING TASK
*********************************************************************************************************************************/

SET @DPA_TZ_OFFSET = DATEDIFF(MI,GETUTCDATE(),GETDATE())

SET @UTC_TIME = DATEADD(MI,@DPA_TZ_OFFSET,@STATS_DATE)




BEGIN TRY
PRINT 'STARTING to COLLECT SSRS Data'
PRINT ''


DECLARE TASK_CURSOR CURSOR  LOCAL
FOR
SELECT SERVER_NAME,
       Isnull(LAST_COLLECTED, '1/1/1900'), 
	   DATABASE_NAME
FROM   DynamicsPerf..SSRS_CONFIG SSRS
WHERE LAST_COLLECTED < @UTC_TIME



/* Open the cursor */
/*if the cursor isn't open you will get an error when you fetch the record*/
OPEN TASK_CURSOR 

/* Get the first record */
/* you can FETCH NEXT, FIRST, LAST, PREVIOUS */
FETCH NEXT FROM TASK_CURSOR INTO @C_SERVER_NAME, @C_LAST_COLLECTED, @C_DATABASE_NAME



/* Verify that we got a record*/
/* status 0 means we got a good record*/

WHILE @@fetch_status = 0  /* no errors */
BEGIN /* Top of Loop */

	          SET @REMOTE_SERVER = CASE ISNULL(@C_SERVER_NAME, @@SERVERNAME)
                                WHEN @@SERVERNAME THEN 'N'
                                ELSE 'Y'
                              END


  -- CREATE TABLE #SQL_INFO
  --   (
  --      SQL_STARTTIME DATETIME,
  --      SQL_BUILD NVARCHAR(20),
		--SQL_TZ_OFFSET INT
  --   )
   
   SET NOCOUNT ON
   

   
TRUNCATE TABLE WRK_TZ_SQL_INFO   --REH clear out table to repopulate

 
SELECT @SQL = 'SELECT create_date AS SQL_STARTTIME,
       CAST(Serverproperty(''ProductVersion'') AS NVARCHAR(20))    AS SQL_BUILD,
	   DATEDIFF(MI,GETUTCDATE(),GETDATE()) AS TZ_OFFSET
		FROM master.sys.databases WHERE name = ''TempDB'''

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

SET @REMOTE_SERVER = 'N'
IF @C_SERVER_NAME <> @@SERVERNAME  SET @REMOTE_SERVER = 'Y'
   
   SET NOCOUNT ON
 
IF @REMOTE_SERVER = 'N'
BEGIN
		   INSERT WRK_TZ_SQL_INFO
		EXEC( @SQL)
END

 IF @REMOTE_SERVER = 'Y'
 BEGIN
				SET @SQL2 = ' 
				SET QUOTED_IDENTIFIER OFF
					SELECT  * FROM OPENQUERY(['+@C_SERVER_NAME+ '],"
				SELECT create_date� AS SQL_STARTTIME,
				CAST(Serverproperty(''ProductVersion'') AS NVARCHAR(20))  AS SQL_BUILD,
				DATEDIFF(MI,GETUTCDATE(),GETDATE()) AS TZ_OFFSET
				FROM�master.sys.databases WHERE name = ''TempDB'' "	)'
		


				IF @DEBUG = 'Y'
                  BEGIN
                      PRINT '@SQL= ' + @SQL2
                  END 
                
			INSERT WRK_TZ_SQL_INFO
				EXEC (@SQL2) 
 
 END
 
 --INSERT @SQL_INFO SELECT SQL_STARTTIME,  SQL_BUILD,TZ_OFFSET FROM WRK_TZ_SQL_INFO


 SET @SQL_TZ_OFFSET = (SELECT TZ_OFFSET FROM WRK_TZ_SQL_INFO)


   --INSERT #SQL_INFO
   --EXECUTE SP_TZOFFSET
   --  @SERVER_NAME = @C_SERVER_NAME,
   --  @DATABASE_NAME = @C_DATABASE_NAME--, @DEBUG = 'N'





--REH LAST_COLLECTED IS STORE IN UTC TIME, NEED TO CONVERT BACK TO LOCAL TIME AS TIMEEND IN EXECUTIONLOG2 IS LOCAL SQL TIME

IF @C_LAST_COLLECTED > '1/1/1901'
  BEGIN
      IF @REMOTE_SERVER = 'N'
        BEGIN
            SET @C_LAST_COLLECTED = DATEADD(MI, @DPA_TZ_OFFSET*-1, @C_LAST_COLLECTED) --REH STORED AS UTC TIME, NEED TO CONVERT TO LOCAL TIME
        END
      ELSE
        BEGIN
            SET @C_LAST_COLLECTED = DATEADD(MI, @SQL_TZ_OFFSET*-1, @C_LAST_COLLECTED)  --REH STORED AS UTC TIME, NEED TO CONVERT TO LOCAL TIME
        END
  END 

  --PRINT '@C_LAST_COLLECTED ' + CAST(@C_LAST_COLLECTED AS VARCHAR(50))



IF @REMOTE_SERVER = 'N'
BEGIN

	
		SET @SQL = 'SET DATEFORMAT MDY 
		INSERT INTO DynamicsPerf.dbo.SSRS_EXECUTIONLOG

	SELECT '
	+ QUOTENAME( @C_SERVER_NAME,'''') + ', '
	+ '''' +  CONVERT(NVARCHAR(24), @STATS_DATE, 121) + '''' + ', '
	+ '''' + @C_DATABASE_NAME + '''' + ', ' 
	+'InstanceName, 
	REPLACE(COALESCE(C.Path, ''Unknown''),C.Name,'+'''' + ''''+') AS ReportPath, 
	C.Name,
	''Removed for security reason'', --UserName,
	ExecutionId, 
	CASE(RequestType)
		WHEN 0 THEN ''Interactive''
		WHEN 1 THEN ''Subscription''
		ELSE ''Unknown''
		END AS RequestType, 
	-- SubscriptionId, 
	Format, 
	Parameters, 
	CASE(ReportAction)		
		WHEN 1 THEN ''Render''
		WHEN 2 THEN ''BookmarkNavigation''
		WHEN 3 THEN ''DocumentMapNavigation''
		WHEN 4 THEN ''DrillThrough''
		WHEN 5 THEN ''FindString''
		WHEN 6 THEN ''GetDocumentMap''
		WHEN 7 THEN ''Toggle''
		WHEN 8 THEN ''Sort''
		ELSE ''Unknown''
		END AS ReportAction,
	TimeStart, 
	TimeEnd, 
	TimeDataRetrieval, 
	TimeProcessing, 
	TimeRendering,
	CASE(Source)
		WHEN 1 THEN ''Live''
		WHEN 2 THEN ''Cache''
		WHEN 3 THEN ''Snapshot'' 
		WHEN 4 THEN ''History''
		WHEN 5 THEN ''AdHoc''
		WHEN 6 THEN ''Session''
		WHEN 7 THEN ''Rdce''
		ELSE ''Unknown''
		END AS Source,
	Status,
	ByteCount,
	[RowCount]
FROM ['+@C_DATABASE_NAME + '].dbo.ExecutionLogStorage EL WITH(NOLOCK)
LEFT OUTER JOIN ['+@C_DATABASE_NAME + '].dbo.Catalog C WITH(NOLOCK) ON (EL.ReportID = C.ItemID)
WHERE TimeEnd >= ' +'''' + CONVERT(NVARCHAR(24), @C_LAST_COLLECTED, 121) +''''

	EXEC (@sql)
	
	
END

 IF @REMOTE_SERVER = 'Y'
 BEGIN
 
 
		SET @SQL = 'SET DATEFORMAT MDY 
	SELECT '
		+ QUOTENAME( @C_SERVER_NAME,'''') +  ', '
	+ '''' +  CONVERT(NVARCHAR(24), @STATS_DATE, 121) + '''' + ', '
	+ '''' + @C_DATABASE_NAME + '''' + ', ' +
	'InstanceName, 
	REPLACE(COALESCE(C.Path, ''Unknown''),C.Name,'+'''' + ''''+') AS ReportPath, 
	C.Name,
	''Removed for security reason'', --UserName,
	ExecutionId, 
	CASE(RequestType)
		WHEN 0 THEN ''Interactive''
		WHEN 1 THEN ''Subscription''
		ELSE ''Unknown''
		END AS RequestType, 
	-- SubscriptionId, 
	Format, 
	Parameters, 
	CASE(ReportAction)		
		WHEN 1 THEN ''Render''
		WHEN 2 THEN ''BookmarkNavigation''
		WHEN 3 THEN ''DocumentMapNavigation''
		WHEN 4 THEN ''DrillThrough''
		WHEN 5 THEN ''FindString''
		WHEN 6 THEN ''GetDocumentMap''
		WHEN 7 THEN ''Toggle''
		WHEN 8 THEN ''Sort''
		ELSE ''Unknown''
		END AS ReportAction,
	TimeStart, 
	TimeEnd, 
	TimeDataRetrieval, 
	TimeProcessing, 
	TimeRendering,
	CASE(Source)
		WHEN 1 THEN ''Live''
		WHEN 2 THEN ''Cache''
		WHEN 3 THEN ''Snapshot'' 
		WHEN 4 THEN ''History''
		WHEN 5 THEN ''AdHoc''
		WHEN 6 THEN ''Session''
		WHEN 7 THEN ''Rdce''
		ELSE ''Unknown''
		END AS Source,
	Status,
	ByteCount,
	[RowCount]
FROM ['+@C_DATABASE_NAME + '].dbo.ExecutionLogStorage EL WITH(NOLOCK)
LEFT OUTER JOIN ['+@C_DATABASE_NAME + '].dbo.Catalog C WITH(NOLOCK) ON (EL.ReportID = C.ItemID)
WHERE TimeEnd >= ' +'''' + CONVERT(NVARCHAR(24), @C_LAST_COLLECTED, 121) +''''



		                    SET @SQL2 = ' 
  SET QUOTED_IDENTIFIER OFF
  INSERT INTO DynamicsPerf.dbo.SSRS_EXECUTIONLOG
				 SELECT * FROM OPENQUERY([' + @C_SERVER_NAME + '], ' +'"' + @SQL +'"' + ') RH '
                    
                    EXEC (@SQL2)
           
               
 
 
 END
 
 SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT


 UPDATE SSRS_CONFIG SET LAST_COLLECTED = @UTC_TIME WHERE SERVER_NAME = @C_SERVER_NAME

 --PRINT '@DPA_TZ_OFFSET ' + CAST(@DPA_TZ_OFFSET AS VARCHAR(50))
 --PRINT '@STATS_DATE ' + CAST(@STATS_DATE AS VARCHAR(50))
 --PRINT '@UTC_TIME ' + CAST(@UTC_TIME AS VARCHAR(50))

 
UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'SUCCESSFULLY collected SSRS data for SERVER ' + @C_SERVER_NAME 
              + ' on database ' + @C_DATABASE_NAME
             +  CHAR(10) + CHAR(13)
WHERE  STATS_TIME = @STATS_DATE AND TASK_TYPE = 'SSRS'


 TRUNCATE TABLE WRK_TZ_SQL_INFO --REH Cleanout the table for next loop

FETCH NEXT FROM TASK_CURSOR INTO @C_SERVER_NAME, @C_LAST_COLLECTED, @C_DATABASE_NAME



END  /*End of the loop */
CLOSE TASK_CURSOR  /*close the cursor to free memory in SQL*/
DEALLOCATE TASK_CURSOR /*Must deallocate the cursor to destroy it and free SQL resources*/
 
 


UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'SUCCESSFULLY collected SSRS Data'
WHERE  STATS_TIME = @STATS_DATE AND TASK_TYPE = 'SSRS'


PRINT ''
PRINT 'SUCCESSFULLY COLLECTED SSRS DATA'
PRINT ''


RETURN(0)  --REH RETURN SUCCESS


END TRY 


/********************************************************************************************************************************
*   END OF TASK
*********************************************************************************************************************************/



BEGIN CATCH
    UPDATE CAPTURE_LOG
    SET    TEXT = TEXT + 'FAILED !!! to collect SSRS Data '
				  + ' TRYING TO PROCESS REPORT SERVER ' + ISNULL(@C_SERVER_NAME,'') + '  '
                  + ISNULL(@SERVER_NAME, '') + ' on database '
                  + ISNULL(@DATABASE_NAME, '') + ' at '
                  + CONVERT(VARCHAR, GETDATE(), 109) 
				  + ' ERROR = ' + CAST(@@ERROR AS VARCHAR(MAX))
				  + ', ' 
				  + CHAR(10)
    WHERE  STATS_TIME = @STATS_DATE
	AND TASK_TYPE ='SSRS'



    PRINT 'ERROR WHILE COLLECTING SSRS DATA'
          

   -- RETURN(1) --REH RETURN ERROR, TRAPPED BY SPROC
END CATCH
GO
PRINT N'Altering [dbo].[DYNPERF_PROCESS_AXSQLTRACE]...';


GO
ALTER PROCEDURE [dbo].[DYNPERF_PROCESS_AXSQLTRACE]
		(@TASK_ID       INT,
                                              @SERVER_NAME   NVARCHAR(128),
                                              @DATABASE_NAME NVARCHAR(128),
                                              @TASK_PARAMS   NVARCHAR(1024),
                                              @TASK_DESC     NVARCHAR(256),
                                              @LAST_RUN      DATETIME,
                                              @RUN_NAME      NVARCHAR(255),
                                              @STATS_DATE    DATETIME,
                                              @REMOTE_SERVER NVARCHAR(1),
											  @AZURE_DB		 BIT,
											  @SQL_TZ_OFFSET INT,
											  @DPA_TZ_OFFSET INT,
                                              @DEBUG         NVARCHAR(1))
AS

/************************************************************************************************************
*  SETUP
*		DECLARE VARIABLES, CREATE SYNONYMS, ETC
*
*************************************************************************************************************/


    SET NOCOUNT ON
    SET DATEFORMAT MDY

    DECLARE @SQL NVARCHAR(MAX), @SQL2 NVARCHAR(MAX)
    



/********************************************************************************************************************************
*   STARTING TASK
*********************************************************************************************************************************/

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'STARTING to ' + ISNULL(@TASK_DESC, 'TASK')
              + ' for SERVER ' + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' USING PARMS @LAST_RUN ' + CAST(@LAST_RUN AS VARCHAR(30)) 
			  + ' @DPA_TZ_OFFSET = ' + CAST (@DPA_TZ_OFFSET AS VARCHAR(10))
			  + ' @SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET  AS VARCHAR(10))
			  + ' @STATS_DATE = ' + CAST(@STATS_DATE AS VARCHAR(30)) 
			  + ' @AZURE_DB = ' + CAST(@AZURE_DB AS VARCHAR(10))
			  + ' @REMOTE = ' + @REMOTE_SERVER
			  + ' @PARMS = ' + ISNULL(@TASK_PARAMS, '')
			  + ', '
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)




--REH  Time Zone code for all procedures
IF @LAST_RUN > '1/1/1901'
  BEGIN
      IF @REMOTE_SERVER = 'N'
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @DPA_TZ_OFFSET, @LAST_RUN) --REH DPA and DB are on same server so use DPA Time Zone Offset
        END
      ELSE
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @SQL_TZ_OFFSET, @LAST_RUN)  --REH DPA and DB are on different servers so use DB Time Zone Offset
        END
  END 


BEGIN TRY
PRINT 'STARTING ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''

SELECT TOP 10 SERVER_NAME,
              DATABASE_NAME,
              QUERY_HASH,
              SQL_TEXT,
              ROW_NUM
INTO   #AX_SQLTRACE
FROM   AX_SQLTRACE AST WITH (NOLOCK)
WHERE  SERVER_NAME = @SERVER_NAME
       AND DATABASE_NAME = @DATABASE_NAME
       AND AST.CANPROCESS = 1 --REH This is a computed column on the AX_SQLTRACE table
--   AND AST.QUERY_HASH IS NULL 
--   AND LEN(AST.SQL_TEXT) < 4000
ORDER  BY ROW_NUM DESC 



UPDATE AST
SET    QUERY_HASH = COALESCE(A.QUERY_HASH, 0X00) --REH There could be several. We are only getting the first
FROM   #AX_SQLTRACE AST
       CROSS APPLY (SELECT QUERY_HASH
                    FROM   (SELECT TOP 1 QUERY_HASH,
                                         SQL_TEXT
                            FROM   QUERY_TEXT QT WITH (NOLOCK)
                            WHERE  QT.SERVER_NAME = AST.SERVER_NAME
                                   AND QT.DATABASE_NAME = AST.DATABASE_NAME
                                   AND QT.SQL_TEXT LIKE Substring(AST.SQL_TEXT, 1, 10) + '%') AS B
                    WHERE  B.SQL_TEXT LIKE Replace(AST.SQL_TEXT, '?', '%')) AS A 




--WHERE  SERVER_NAME = @SERVER_NAME
--       AND DATABASE_NAME = @DATABASE_NAME
--       AND AST.QUERY_HASH IS NULL 
--	   AND LEN(AST.SQL_TEXT) < 4000 --REH LIKE command is limited to 8k characters

UPDATE AST
SET QUERY_HASH = ASTEMP.QUERY_HASH
FROM AX_SQLTRACE AST WITH (ROWLOCK)
INNER JOIN #AX_SQLTRACE ASTEMP ON AST.ROW_NUM = ASTEMP.ROW_NUM

DROP TABLE #AX_SQLTRACE

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'SUCCESSFULLY '
              + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' Inserted ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' ROWS ' +  CHAR(10) 
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



PRINT ''
PRINT 'SUCCESSFULLY CAPTURED ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


RETURN(0)  --REH RETURN SUCCESS


END TRY 


/********************************************************************************************************************************
*   END OF TASK
*********************************************************************************************************************************/


BEGIN CATCH
    UPDATE CAPTURE_LOG
    SET    TEXT = TEXT + 'FAILED !!! to '
	      + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
                  + ISNULL(@SERVER_NAME, '') + ' on database '
                  + ISNULL(@DATABASE_NAME, '') + ' at '
                  + CONVERT(VARCHAR, GETDATE(), 109) 
				  + ' ERROR = ' + CAST(@@ERROR AS VARCHAR(MAX))
				  + ', ' 
				  + CHAR(10)
    WHERE  STATS_TIME = @STATS_DATE
	AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



    PRINT 'ERROR WHILE COLLECTING '
          + ISNULL(@TASK_DESC, '') + ' !!!!!!!!!!!!!!'

    RETURN(1) --REH RETURN ERROR, TRAPPED BY SPROC
END CATCH
GO
PRINT N'Altering [dbo].[DYNPERF_PROCESS_QUERY_PLANS]...';


GO
ALTER PROCEDURE [dbo].[DYNPERF_PROCESS_QUERY_PLANS]
       (@TASK_ID       INT,
                                              @SERVER_NAME   NVARCHAR(128),
                                              @DATABASE_NAME NVARCHAR(128),
                                              @TASK_PARAMS   NVARCHAR(1024),
                                              @TASK_DESC     NVARCHAR(256),
                                              @LAST_RUN      DATETIME,
                                              @RUN_NAME      NVARCHAR(255),
                                              @STATS_DATE    DATETIME,
                                              @REMOTE_SERVER NVARCHAR(1),
                                                                             @AZURE_DB           BIT,
                                                                             @SQL_TZ_OFFSET INT,
                                                                             @DPA_TZ_OFFSET INT,
                                              @DEBUG         NVARCHAR(1))
AS

/************************************************************************************************************
*  SETUP
*		DECLARE VARIABLES, CREATE SYNONYMS, ETC
*
*************************************************************************************************************/


    SET NOCOUNT ON
    SET DATEFORMAT MDY

    DECLARE @SQL NVARCHAR(MAX), @SQL2 NVARCHAR(MAX), @CPU INT
    



/********************************************************************************************************************************
*   STARTING TASK
*********************************************************************************************************************************/

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'STARTING to ' + ISNULL(@TASK_DESC, 'TASK')
              + ' for SERVER ' + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' USING PARMS @LAST_RUN ' + CAST(@LAST_RUN AS VARCHAR(30)) 
			  + ' @DPA_TZ_OFFSET = ' + CAST (@DPA_TZ_OFFSET AS VARCHAR(10))
			  + ' @SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET  AS VARCHAR(10))
			  + ' @STATS_DATE = ' + CAST(@STATS_DATE AS VARCHAR(30)) 
			  + ' @AZURE_DB = ' + CAST(@AZURE_DB AS VARCHAR(10))
			  + ' @REMOTE = ' + @REMOTE_SERVER
			  + ' @PARMS = ' + ISNULL(@TASK_PARAMS, '')
			  + ', '
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)




--REH  Time Zone code for all procedures
IF @LAST_RUN > '1/1/1901'
  BEGIN
      IF @REMOTE_SERVER = 'N'
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @DPA_TZ_OFFSET, @LAST_RUN) --REH DPA and DB are on same server so use DPA Time Zone Offset
        END
      ELSE
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @SQL_TZ_OFFSET, @LAST_RUN)  --REH DPA and DB are on different servers so use DB Time Zone Offset
        END
  END 


BEGIN TRY
PRINT 'STARTING ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''

--REH Need to delete any old data in case QUERY_PLAN refresh updates the flag.  We need to delete old parsed plans

DELETE QPP
FROM   QUERY_PLANS_PARSED QPP WITH (ROWLOCK)
       INNER JOIN QUERY_PLANS QP WITH (NOLOCK)
               ON QPP.SERVER_NAME = QP.SERVER_NAME
                  AND QPP.DATABASE_NAME = QP.DATABASE_NAME
                  AND QPP.QUERY_PLAN_HASH = QP.QUERY_PLAN_HASH
WHERE  QP.PARSED_FLAG = 0 and QP.SERVER_NAME = @SERVER_NAME and QP.DATABASE_NAME = @DATABASE_NAME

IF EXISTS (SELECT * FROM [tempdb].sys.objects WHERE name = '#PARSE_PLANS')
DROP TABLE #PARSE_PLANS

--;WITH XMLNAMESPACES ('http://schemas.microsoft.com/sqlserver/2004/07/showplan' AS sp)
SELECT	TOP 10000	QT.SERVER_NAME, QT.DATABASE_NAME, QT.[QUERY_PLAN_HASH],
'' as SQL_PARAMS -- CONVERT (NVARCHAR(MAX), index_node.query('for $qplan in //sp:QueryPlan, $plist in $qplan/sp:ParameterList, $colref in $plist/sp:ColumnReference  return concat(string($colref/@Column),":",string($colref/@ParameterCompiledValue),",   "),"  "')) as SQL_PARAMS
  
INTO #PARSE_PLANS

  FROM [QUERY_PLANS] QT WITH (NOLOCK)
  --REH Changed this to query_history from query_stats to work on smaller potential dataset
  --  SELECT TOP 10,000 FOR THE MONTH
  	INNER LOOP JOIN QUERY_HISTORY QS WITH (NOLOCK) ON QT.SERVER_NAME = QS.SERVER_NAME AND QT.DATABASE_NAME = QS.DATABASE_NAME
		AND QT.QUERY_PLAN_HASH = QS.QUERY_PLAN_HASH AND FLAG = 'M' AND DATE =  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)
      --OUTER APPLY QUERY_PLAN.nodes('//sp:Batch') AS Batch(index_node)
    
WHERE PARSED_FLAG = 0 AND QT.SERVER_NAME = @SERVER_NAME AND QT.DATABASE_NAME = @DATABASE_NAME
	AND QT.QUERY_PLAN_HASH > 0X000000000000000  --REH Don't process the 0 hash values
	ORDER BY QS.ELAPSED_TIME_TODAY DESC  --REH do the top execution times first, most likely to show up in query views


--REH Parse out the QUERY_PLANS table into it's vital statistics

SET QUOTED_IDENTIFIER OFF
SELECT @CPU = cpu_count * .25 FROM sys.dm_os_sys_info

IF @CPU < 2 SET @CPU = 2

SET @SQL = '
 ;WITH XMLNAMESPACES (''http://schemas.microsoft.com/sqlserver/2004/07/showplan'' AS sp)

 INSERT QUERY_PLANS_PARSED
 SELECT DISTINCT *
FROM   (SELECT QUERY_PLANS.SERVER_NAME, QUERY_PLANS.DATABASE_NAME, QUERY_PLANS.QUERY_PLAN_HASH,
			   CAST(isnull(index_node.value(''(..//@NodeId)[1]'', ''nvarchar(128)''),''0'') AS INT) AS NodeID,
               CAST(Replace(Replace(index_node.value(''(.//@Table)[1]'', ''NVARCHAR(128)''), ''['', ''''), '']'', '''') AS NVARCHAR(128))  AS TABLE_NAME,
               CAST(Replace(Replace(index_node.value(''(.//@Index)[1]'', ''NVARCHAR(128)''), ''['', ''''), '']'', '''') AS NVARCHAR(128)) AS INDEX_NAME,
			   CAST(isnull(index_node.value(''(.//@Lookup)[1]'', ''nvarchar(128)''),''0'') AS INT) AS LOOKUP,
			   CAST(isnull(index_node.value(''(..//@Parallel)[1]'', ''nvarchar(128)''),''0'') AS INT) AS PARALLEL,
			   CAST(index_node.value(''(..//@PhysicalOp)[1]'', ''nvarchar(128)'') AS NVARCHAR(128)) AS PHYSICALOP,
			   CAST(index_node.value(''(..//@LogicalOp)[1]'', ''nvarchar(128)'') AS NVARCHAR(128)) AS LOGICALOP,
			   CAST(str(ISNULL(index_node.value(''(..//@EstimateRows)[1]'', ''nvarchar(128)''),''0.0''),30,17) AS DECIMAL(14,0)) AS ESTIMATEROWS,
			   CAST(str(ISNULL(index_node.value(''(..//@EstimateIO)[1]'', ''nvarchar(128)''),''0.0''),30,17) AS DECIMAL(20,7)) AS EstimateIO,
			   CAST(str(ISNULL(index_node.value(''(..//@EstimateCPU)[1]'', ''nvarchar(128)''),''0.0''),30,17) AS DECIMAL(20,7)) AS ESTIMATECPU,
			   CAST(str(ISNULL(index_node.value(''(..//@AvgRowSize)[1]'', ''nvarchar(128)''),''0.0''),30,17) AS DECIMAL(14,0)) AS AVGROWSIZE,
			   CAST(str(isnull(index_node.value(''(..//@EstimatedTotalSubtreeCost)[1]'', ''nvarchar(128)'') ,''0.0''),30,17) AS DECIMAL (20,7)) AS ESTIMATEDTOTALSUBTREECOST,
               CONVERT(NVARCHAR(MAX), index_node.query(''for $seekpredicate in ./sp:SeekPredicates,
                                                            $rangecolumns in $seekpredicate//sp:RangeColumns,
                                                            $columnreference in $rangecolumns/sp:ColumnReference
                                        return string($columnreference/@Column)''))        AS SEEK_COLUMNS,

              CONVERT(NVARCHAR(MAX), index_node.query(''for $predicate2 in ./sp:Predicate,
                                                           $Ident in  $predicate2//sp:Identifier,
														   $COLREF2 in  $Ident/sp:ColumnReference
                                                            
                                        return string($COLREF2/@Column)'')) AS PREDICATES,

		    REPLACE( REPLACE( CONVERT(NVARCHAR(MAX), index_node.query(''for $predicate in ./sp:Predicate,
                                                $rangecolumn in $predicate//sp:ScalarOperator
                                                            
                            return string($rangecolumn/@ScalarString)''))
							,''&lt;'', ''<'')   ,''&gt;'', ''>'')         AS PREDICATE_TEXT
        FROM  #PARSE_PLANS  WITH (NOLOCK)
			INNER LOOP JOIN QUERY_PLANS ON QUERY_PLANS.SERVER_NAME = #PARSE_PLANS.SERVER_NAME
					AND QUERY_PLANS.DATABASE_NAME = #PARSE_PLANS.DATABASE_NAME
					AND QUERY_PLANS.QUERY_PLAN_HASH = #PARSE_PLANS.QUERY_PLAN_HASH
			OUTER APPLY QUERY_PLAN.nodes(''//sp:RelOp/sp:IndexScan'') AS SeekPredicates(index_node)
               --CROSS APPLY QUERY_PLAN.nodes(''//sp:Batch'') AS Batch(index_node2)
			WHERE QUERY_PLANS.SERVER_NAME = ' + '''' + @SERVER_NAME + '''' +'  AND QUERY_PLANS.DATABASE_NAME = '+ '''' +  @DATABASE_NAME +'''' + ' 
			   AND QUERY_PLANS.PARSED_FLAG = 0

			   ) A
			   OPTION(MAXDOP ' + CAST(@CPU AS VARCHAR(4)) + ')'

			   IF @DEBUG = 'Y'
			   BEGIN
				 PRINT @SQL
			   END


			   EXEC (@SQL)



UPDATE QP SET PARSED_FLAG = 1 --,SQL_PARMS = PP.SQL_PARAMS

FROM #PARSE_PLANS PP  
INNER LOOP JOIN QUERY_PLANS QP WITH (ROWLOCK, READPAST) ON QP.SERVER_NAME = PP.SERVER_NAME
			AND QP.DATABASE_NAME = PP.DATABASE_NAME
			AND QP.QUERY_PLAN_HASH = PP.QUERY_PLAN_HASH

 WHERE PP.SERVER_NAME = @SERVER_NAME AND PP.DATABASE_NAME = @DATABASE_NAME --AND QP.PARSED_FLAG = 0 
 OPTION(MAXDOP 1)
 

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'SUCCESSFULLY '
              + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' Inserted ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' ROWS ' +  CHAR(10) 
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



PRINT ''
PRINT 'SUCCESSFULLY CAPTURED ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


RETURN(0)  --REH RETURN SUCCESS


END TRY 


/********************************************************************************************************************************
*   END OF TASK
*********************************************************************************************************************************/


BEGIN CATCH
    UPDATE CAPTURE_LOG
    SET    TEXT = TEXT + 'FAILED !!! to '
	      + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
                  + ISNULL(@SERVER_NAME, '') + ' on database '
                  + ISNULL(@DATABASE_NAME, '') + ' at '
                  + CONVERT(VARCHAR, GETDATE(), 109) 
				  + ' ERROR = ' + CAST(@@ERROR AS VARCHAR(MAX))
				  + ', ' 
				  + CHAR(10)
    WHERE  STATS_TIME = @STATS_DATE
	AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



    PRINT 'ERROR WHILE COLLECTING '
          + ISNULL(@TASK_DESC, '') + ' !!!!!!!!!!!!!!'

    RETURN(1) --REH RETURN ERROR, TRAPPED BY SPROC
END CATCH
GO
PRINT N'Altering [dbo].[DYNPERF_REFRESH_QUERY_PLANS]...';


GO
ALTER PROCEDURE [dbo].DYNPERF_REFRESH_QUERY_PLANS
(@TASK_ID       INT,
                                              @SERVER_NAME   NVARCHAR(128),
                                              @DATABASE_NAME NVARCHAR(128),
                                              @TASK_PARAMS   NVARCHAR(1024),
                                              @TASK_DESC     NVARCHAR(256),
                                              @LAST_RUN      DATETIME,
                                              @RUN_NAME      NVARCHAR(255),
                                              @STATS_DATE    DATETIME,
                                              @REMOTE_SERVER NVARCHAR(1),
											  @AZURE_DB		 BIT,
											  @SQL_TZ_OFFSET INT,
											  @DPA_TZ_OFFSET INT,
                                              @DEBUG         NVARCHAR(1))
AS

/************************************************************************************************************
*  SETUP
*		DECLARE VARIABLES, CREATE SYNONYMS, ETC
*
*************************************************************************************************************/


    SET NOCOUNT ON
    SET DATEFORMAT MDY

    DECLARE @SQL NVARCHAR(MAX), @SQL2 NVARCHAR(MAX), @REFRESH_PLAN_DAYS INT
    
/*************************************************

--REH Template for creating a synonym, 
--Will help avoid having to use EXEC (@SQL) code
-- and make the code more dynamic to the inputs


***************************************************/

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_RQP_STATS')
  EXEC ('DROP SYNONYM [dbo].DYN_RQP_STATS')


IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_RQP_STATS
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].sys.dm_exec_query_stats'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_RQP_STATS
				FOR [' + @DATABASE_NAME + '].sys.dm_exec_query_stats'

EXEC (@SQL)


/********************************************************************************************************************************
*   STARTING TASK
*********************************************************************************************************************************/

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'STARTING to ' + ISNULL(@TASK_DESC, 'TASK')
              + ' for SERVER ' + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' USING PARMS @LAST_RUN ' + CAST(@LAST_RUN AS VARCHAR(30)) 
			  + ' @DPA_TZ_OFFSET = ' + CAST (@DPA_TZ_OFFSET AS VARCHAR(10))
			  + ' @SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET  AS VARCHAR(10))
			  + ' @STATS_DATE = ' + CAST(@STATS_DATE AS VARCHAR(30)) 
			  + ' @AZURE_DB = ' + CAST(@AZURE_DB AS VARCHAR(10))
			  + ' @REMOTE = ' + @REMOTE_SERVER
			  + ' @PARMS = ' + ISNULL(@TASK_PARAMS, '')
			  + ', '
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



--REH  Time Zone code for all procedures
IF @LAST_RUN > '1/1/1901'
  BEGIN
      IF @REMOTE_SERVER = 'N'
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @DPA_TZ_OFFSET, @LAST_RUN) --REH DPA and DB are on same server so use DPA Time Zone Offset
        END
      ELSE
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @SQL_TZ_OFFSET, @LAST_RUN)  --REH DPA and DB are on different servers so use DB Time Zone Offset
        END
  END 


  SELECT @REFRESH_PLAN_DAYS = REFRESH_PLAN_DAYS FROM DATABASES_2_COLLECT WHERE LINKED_SERVER = @SERVER_NAME AND DATABASE_NAME = @DATABASE_NAME



BEGIN TRY
PRINT 'STARTING ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''

IF @REMOTE_SERVER = 'N'
BEGIN
;WITH Query_Stats_CTE (SERVER_NAME, DATABASE_NAME, QUERY_PLAN_HASH, PLAN_HANDLE )
     AS
     -- Define the CTE query.
     (SELECT TOP 10000 * FROM 
     (SELECT DISTINCT SERVER_NAME, DATABASE_NAME, QUERY_PLAN_HASH,
                      PLAN_HANDLE
      FROM   QUERY_STATS AS QS WITH (NOLOCK)
      WHERE  STATS_TIME > DATEADD(D,-1,GETDATE())  --REH ANY QUERIES COLLECTED IN THE LAST DAY
             AND DATABASE_NAME = @DATABASE_NAME
             AND SERVER_NAME = @SERVER_NAME 
             AND QUERY_PLAN_HASH > 0x00000000
             AND  EXISTS (SELECT 'X'
                             FROM   QUERY_PLANS QP WITH (NOLOCK)
                             WHERE  QP.QUERY_PLAN_HASH = QS.QUERY_PLAN_HASH
                                    AND QS.DATABASE_NAME = QP.DATABASE_NAME
                                    AND QS.SERVER_NAME = QP.SERVER_NAME 
									AND QP.DATE_UPDATED <= DATEADD(D,-@REFRESH_PLAN_DAYS,GETDATE() ) --REH ANY PLANS THAT HAVEN'T BEEN UPDATED IN THE LAST 7 DAYS
									)) AS A )
									 
UPDATE QP 
SET QUERY_PLAN = COALESCE(RH.QUERY_PLAN,QP.QUERY_PLAN), DATE_UPDATED = GETDATE(), PARSED_FLAG = 0
FROM   QUERY_PLANS QP WITH (ROWLOCK, READPAST)
INNER JOIN (SELECT RN = ROW_NUMBER()
                      OVER (
                        PARTITION BY CTE.QUERY_PLAN_HASH
                        ORDER BY CTE.QUERY_PLAN_HASH DESC),
                        SERVER_NAME, 
                        DATABASE_NAME,
               CTE.QUERY_PLAN_HASH,
               query_plan AS QUERY_PLAN
        FROM   Query_Stats_CTE CTE WITH (NOLOCK)
               OUTER APPLY sys.dm_exec_query_plan(CTE.PLAN_HANDLE)) AS RH ON RH.SERVER_NAME = QP.SERVER_NAME AND RH.DATABASE_NAME = QP.DATABASE_NAME
               AND RH.QUERY_PLAN_HASH = QP.QUERY_PLAN_HASH
WHERE  RN = 1 AND QP.SERVER_NAME = @SERVER_NAME AND QP.DATABASE_NAME = @DATABASE_NAME AND QP.QUERY_PLAN_HASH <> 0x0000000000000000


END

IF @REMOTE_SERVER = 'Y'
     BEGIN
SET @SQL = '

IF EXISTS (SELECT * FROM  [tempdb].sys.objects WHERE name = ''DYNPERF_QUERY_HASH_REFRESH'') 
 DROP TABLE  [tempdb].dbo.DYNPERF_QUERY_HASH_REFRESH '
				 
			SET @SQL2 = ' 
							  SET QUOTED_IDENTIFIER OFF
							  EXEC (' + '"' + @SQL + '"' + ') AT ['
						+ @SERVER_NAME + ']' 


         IF @DEBUG = 'Y'
              BEGIN
                  PRINT '@SQL= ' + @SQL2
              END

         EXEC (@SQL2)


         SET @SQL = '
				CREATE TABLE [tempdb].dbo.DYNPERF_QUERY_HASH_REFRESH
				(
				QUERY_PLAN_HASH VARBINARY(64), 
				PLAN_HANDLE VARBINARY(64)
				)'

		IF @DEBUG = 'Y'
		BEGIN
         PRINT @SQL
		 END


         SET @SQL2 = ' 
				  SET QUOTED_IDENTIFIER OFF
				  EXEC (' + '"' + @SQL + '"' + ') AT [' + @SERVER_NAME
									 + ']'

         IF @DEBUG = 'Y'
              BEGIN
                  PRINT '@SQL= ' + @SQL2
              END

         EXEC (@SQL2)

         SET @SQL = '

					;WITH Query_Stats_CTE ( QUERY_PLAN_HASH, PLAN_HANDLE)
						 AS (SELECT DISTINCT TOP 10000 QUERY_PLAN_HASH,
										  PLAN_HANDLE
							 FROM   QUERY_STATS QS WITH (NOLOCK)
							 WHERE  QS.STATS_TIME >=  DATEADD(D,-1,GETDATE()) 
							  AND QUERY_PLAN_HASH > 0x00000000
									AND DATABASE_NAME = '
										+ '''' + @DATABASE_NAME + ''''
										+ '
									AND SERVER_NAME = ' + '''' +
										+ @SERVER_NAME + ''''
										+ ' 
									AND EXISTS (SELECT ''X''
													FROM   QUERY_PLANS QP WITH (NOLOCK)
												 WHERE  QP.QUERY_PLAN_HASH = QS.QUERY_PLAN_HASH
														AND QS.DATABASE_NAME = QP.DATABASE_NAME
														AND QS.SERVER_NAME = QP.SERVER_NAME 
															AND QP.DATE_UPDATED <= DATEADD(D,-' + CAST(@REFRESH_PLAN_DAYS AS VARCHAR(4)) +',GETDATE() ) 
													))
						INSERT INTO OPENQUERY([' + @SERVER_NAME
										+ '], ''SELECT QUERY_PLAN_HASH, PLAN_HANDLE FROM [tempdb].dbo.DYNPERF_QUERY_HASH_REFRESH'')
					                            
					  
					SELECT QUERY_PLAN_HASH, PLAN_HANDLE 
					FROM   (SELECT RN = ROW_NUMBER()
										  OVER (
											PARTITION BY CTE.QUERY_PLAN_HASH, CTE.PLAN_HANDLE
											ORDER BY CTE.QUERY_PLAN_HASH, CTE.PLAN_HANDLE DESC),
								   CTE.QUERY_PLAN_HASH, CTE.PLAN_HANDLE 
					            
								FROM   Query_Stats_CTE CTE
							   ) AS RH
					WHERE  RN = 1 '

		IF @DEBUG = 'Y'
			 BEGIN
				 PRINT '@SQL= ' + @SQL
			 END 


         EXEC(@SQL)



			SET @SQL = 'SELECT 
				   QUERY_PLAN_HASH,
				   cast(query_plan as nvarchar(max)) as QUERY_PLAN

			FROM   (SELECT RN = ROW_NUMBER()
								  OVER (
									PARTITION BY QUERY_PLAN_HASH
									ORDER BY QUERY_PLAN_HASH DESC),
						   QUERY_PLAN_HASH,
						   query_plan 
					FROM   [tempdb].dbo.DYNPERF_QUERY_HASH_REFRESH CTE
						   OUTER APPLY sys.dm_exec_query_plan(CTE.PLAN_HANDLE)) AS RH
			WHERE  RN = 1 ' 


         IF @DEBUG = 'Y'
              BEGIN
                  PRINT '@SQL= ' + @SQL
              END
              
              
		SET @SQL2 = ' 
		  SET QUOTED_IDENTIFIER OFF
		  UPDATE DynamicsPerf.dbo.QUERY_PLANS WITH (ROWLOCK, READPAST)
						 SET QUERY_PLAN =  COALESCE( RH.QUERY_PLAN, QUERY_PLANS.QUERY_PLAN), PARSED_FLAG = 0, DATE_UPDATED = ' + '''' + CAST(GETDATE() AS VARCHAR(20)) + '''' 
						 + 'FROM OPENQUERY([' + @SERVER_NAME + '], ' +'"' + @SQL +'"' + ') AS RH
						 WHERE SERVER_NAME = ' + '''' + @SERVER_NAME + '''' +
						  '   AND DATABASE_NAME = ' + '''' + @DATABASE_NAME + '''' + 
						  '  AND RH.QUERY_PLAN_HASH = QUERY_PLANS.QUERY_PLAN_HASH' 

		 IF @DEBUG = 'Y'
			  BEGIN
				  PRINT '@SQL= ' + @SQL2
			  END 
		 

         EXEC(@SQL2)
         

		 --REH Drop the table at the end of the process

         SET @SQL = '

				IF EXISTS (SELECT * FROM  [' + @DATABASE_NAME + '].sys.objects WHERE name = ''DYNPERF_QUERY_HASH_REFRESH'') 
				 DROP TABLE  [' + @DATABASE_NAME + '].dbo.DYNPERF_QUERY_HASH_REFRESH '
				 
			SET @SQL2 = ' 
							  SET QUOTED_IDENTIFIER OFF
							  EXEC (' + '"' + @SQL + '"' + ') AT ['
						+ @SERVER_NAME + ']' 


         IF @DEBUG = 'Y'
              BEGIN
                  PRINT '@SQL= ' + @SQL2
              END

         EXEC (@SQL2)
     
     END 




UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'SUCCESSFULLY '
              + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  +  CHAR(10) 
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



PRINT ''
PRINT 'SUCCESSFULLY CAPTURED ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


RETURN(0)  --REH RETURN SUCCESS


END TRY 


/********************************************************************************************************************************
*   END OF TASK
*********************************************************************************************************************************/


BEGIN CATCH
    UPDATE CAPTURE_LOG
    SET    TEXT = TEXT + 'FAILED !!! to '
	      + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
                  + ISNULL(@SERVER_NAME, '') + ' on database '
                  + ISNULL(@DATABASE_NAME, '') + ' at '
                  + CONVERT(VARCHAR, GETDATE(), 109) 
				  + ' ERROR = ' + CAST(@@ERROR AS VARCHAR(MAX))
				  + ', ' 
				  + CHAR(10)
    WHERE  STATS_TIME = @STATS_DATE
	AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)

	
         SET @SQL = '

				IF EXISTS (SELECT * FROM  [' + @DATABASE_NAME + '].sys.objects WHERE name = ''DYNPERF_QUERY_HASH_REFRESH'') 
				 DROP TABLE  [' + @DATABASE_NAME + '].dbo.DYNPERF_QUERY_HASH_REFRESH '
				 
			SET @SQL2 = ' 
							  SET QUOTED_IDENTIFIER OFF
							  EXEC (' + '"' + @SQL + '"' + ') AT ['
						+ @SERVER_NAME + ']' 

				EXEC(@SQL2)


    PRINT 'ERROR WHILE COLLECTING '
          + ISNULL(@TASK_DESC, '') + ' !!!!!!!!!!!!!!'

    RETURN(1) --REH RETURN ERROR, TRAPPED BY SPROC
END CATCH
GO
PRINT N'Altering [dbo].[DYNPERF_REFRESH_QUERY_TEXT]...';


GO
ALTER PROCEDURE [dbo].[DYNPERF_REFRESH_QUERY_TEXT]
 (@TASK_ID       INT,
                                              @SERVER_NAME   NVARCHAR(128),
                                              @DATABASE_NAME NVARCHAR(128),
                                              @TASK_PARAMS   NVARCHAR(1024),
                                              @TASK_DESC     NVARCHAR(256),
                                              @LAST_RUN      DATETIME,
                                              @RUN_NAME      NVARCHAR(255),
                                              @STATS_DATE    DATETIME,
                                              @REMOTE_SERVER NVARCHAR(1),
											  @AZURE_DB		 BIT,
											  @SQL_TZ_OFFSET INT,
											  @DPA_TZ_OFFSET INT,
                                              @DEBUG         NVARCHAR(1))
AS

/************************************************************************************************************
*  SETUP
*		DECLARE VARIABLES, CREATE SYNONYMS, ETC
*
*************************************************************************************************************/

    SET NOCOUNT ON
    SET DATEFORMAT MDY

    DECLARE @SQL NVARCHAR(MAX), @SQL2 NVARCHAR(MAX), @REFRESH_PLAN_DAYS INT
    
/********************************************************************************************************************************
*   STARTING TASK
*********************************************************************************************************************************/

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'STARTING to ' + ISNULL(@TASK_DESC, 'TASK')
              + ' for SERVER ' + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' USING PARMS @LAST_RUN ' + CAST(@LAST_RUN AS VARCHAR(30)) 
			  + ' @DPA_TZ_OFFSET = ' + CAST (@DPA_TZ_OFFSET AS VARCHAR(10))
			  + ' @SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET  AS VARCHAR(10))
			  + ' @STATS_DATE = ' + CAST(@STATS_DATE AS VARCHAR(30)) 
			  + ' @AZURE_DB = ' + CAST(@AZURE_DB AS VARCHAR(10))
			  + ' @REMOTE = ' + @REMOTE_SERVER
			  + ' @PARMS = ' + ISNULL(@TASK_PARAMS, '')
			  + ', '
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)





--REH  Time Zone code for all procedures
IF @LAST_RUN > '1/1/1901'
  BEGIN
      IF @REMOTE_SERVER = 'N'
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @DPA_TZ_OFFSET, @LAST_RUN) --REH DPA and DB are on same server so use DPA Time Zone Offset
        END
      ELSE
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @SQL_TZ_OFFSET, @LAST_RUN)  --REH DPA and DB are on different servers so use DB Time Zone Offset
        END
  END 


  SELECT @REFRESH_PLAN_DAYS = REFRESH_PLAN_DAYS FROM DATABASES_2_COLLECT WHERE LINKED_SERVER = @SERVER_NAME AND DATABASE_NAME = @DATABASE_NAME


BEGIN TRY
PRINT 'STARTING ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''



IF @REMOTE_SERVER = 'N'
     BEGIN ;
         WITH Query_Stats_CTE ( QUERY_HASH)
              AS (SELECT  QUERY_HASH
                  FROM   QUERY_STATS QS WITH (NOLOCK)
                  WHERE  QS.STATS_TIME >= DATEADD(D,-1,GETDATE())
                         AND DATABASE_NAME = @DATABASE_NAME
                         AND SERVER_NAME = @SERVER_NAME 
						 AND QUERY_HASH > 0x0000000000
                         AND  EXISTS (SELECT 'X'
                                         FROM   QUERY_TEXT QT WITH (NOLOCK)
                                         WHERE  QS.QUERY_HASH = QT.QUERY_HASH
                                                AND QS.DATABASE_NAME = QT.DATABASE_NAME
                                                AND QS.SERVER_NAME = QT.SERVER_NAME
												AND QT.DATE_UPDATED <= DATEADD(D,-@REFRESH_PLAN_DAYS,GETDATE() ) --REH ANY PLANS THAT HAVEN'T BEEN UPDATED IN THE LAST 7 DAYS
												 ))
    --     INSERT QUERY_TEXT
    --     SELECT @SERVER_NAME,
    --            @DATABASE_NAME,
    --            QUERY_HASH,
    --            SQL_TEXT,
				--@STATS_DATE
				
	UPDATE QT 
	SET SQL_TEXT = COALESCE(RH.SQL_TEXT, QT.SQL_TEXT), DATE_UPDATED = @STATS_DATE
         FROM   
         QUERY_TEXT QT WITH (ROWLOCK, READPAST) INNER JOIN 
         (SELECT RN = ROW_NUMBER()
                               OVER (
                                 PARTITION BY CTE.QUERY_HASH
                                 ORDER BY CTE.QUERY_HASH DESC),
                        qs.query_hash                                                                                              AS QUERY_HASH,
                        SUBSTRING(st.text, ( qs.statement_start_offset / 2 ) + 1, ( ( CASE qs.statement_end_offset
                                                                                        WHEN -1 THEN DATALENGTH(st.text)
                                                                                        ELSE qs.statement_end_offset
                                                                                      END - qs.statement_start_offset ) / 2 ) + 1) AS SQL_TEXT
                 FROM   Query_Stats_CTE CTE
                        INNER JOIN sys.dm_exec_query_stats AS qs
                                ON CTE.QUERY_HASH = qs.query_hash
                        OUTER APPLY sys.dm_exec_plan_attributes (qs.plan_handle)
                        CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
                 WHERE  attribute = N'dbid'
                        AND DB_NAME(CONVERT(INT, value)) = @DATABASE_NAME
                        AND last_execution_time >= @LAST_RUN
						) AS RH ON RH.QUERY_HASH = QT.QUERY_HASH AND QT.SERVER_NAME = @SERVER_NAME AND QT.DATABASE_NAME = @DATABASE_NAME
         WHERE  RN = 1
     END 


 IF @REMOTE_SERVER = 'Y'
 BEGIN
 


				 
SET @SQL = '

IF EXISTS (SELECT * FROM  [tempdb].sys.objects WHERE name = ''DYNPERF_QUERY_HASH_REFRESH'') 
 DROP TABLE  [tempdb].dbo.DYNPERF_QUERY_HASH_REFRESH '
				 
			SET @SQL2 = ' 
							  SET QUOTED_IDENTIFIER OFF
							  EXEC (' + '"' + @SQL + '"' + ') AT ['
						+ @SERVER_NAME + ']' 


         IF @DEBUG = 'Y'
              BEGIN
                  PRINT '@SQL= ' + @SQL2
              END

         EXEC (@SQL2)



 SET @SQL = '
CREATE TABLE  [tempdb].dbo.DYNPERF_QUERY_HASH_REFRESH
(
QUERY_HASH VARBINARY(64)
)' 



 SET @SQL2 = ' 
  SET QUOTED_IDENTIFIER OFF
  EXEC ('+'"' + @SQL +'"' + ') AT [' + @SERVER_NAME + ']'
  
 IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL2
END

EXEC (@SQL2)


SET @SQL = '

;WITH Query_Stats_CTE ( QUERY_HASH)
     AS (SELECT  QUERY_HASH
         FROM   QUERY_STATS QS
         WHERE  QS.STATS_TIME >= DATEADD(D,-1, GETDATE()  )
                AND DATABASE_NAME = ' + '''' + @DATABASE_NAME + '''' + '
                AND SERVER_NAME = ' + '''' + +@SERVER_NAME + '''' + ' 
				AND QUERY_HASH > 0x0000000000
                AND  EXISTS (SELECT ''X''
                                FROM   QUERY_TEXT QT WITH (NOLOCK)
                                WHERE  QS.QUERY_HASH = QT.QUERY_HASH
                                AND QS.DATABASE_NAME = QT.DATABASE_NAME
                                AND QS.SERVER_NAME = QT.SERVER_NAME 
								AND QT.DATE_UPDATED <= DATEADD(D,-'+CAST(@REFRESH_PLAN_DAYS AS VARCHAR(4))+',GETDATE() )
                                ))
INSERT INTO OPENQUERY([' + @SERVER_NAME + '], ''SELECT QUERY_HASH FROM  [tempdb].dbo.DYNPERF_QUERY_HASH_REFRESH'')

SELECT QUERY_HASH
FROM   (SELECT RN = ROW_NUMBER()
                      OVER (
                        PARTITION BY CTE.QUERY_HASH
                        ORDER BY CTE.QUERY_HASH DESC),
               QUERY_HASH 
            
            FROM   Query_Stats_CTE CTE
           ) AS RH
WHERE  RN = 1 '

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END


EXEC (@SQL)


        
 SET @SQL = '
         SELECT QUERY_HASH, SQL_TEXT
         FROM (
         SELECT RN = ROW_NUMBER() OVER (PARTITION BY CTE.QUERY_HASH ORDER BY CTE.QUERY_HASH DESC),
          qs.query_hash AS QUERY_HASH,
                         SUBSTRING(st.text, ( qs.statement_start_offset / 2 ) + 1, ( ( CASE qs.statement_end_offset
                                                                                         WHEN -1 THEN DATALENGTH(st.text)
                                                                                         ELSE qs.statement_end_offset
                                                                                       END - qs.statement_start_offset ) / 2 ) + 1) AS SQL_TEXT
         FROM    [tempdb].dbo.DYNPERF_QUERY_HASH_REFRESH CTE
                INNER JOIN sys.dm_exec_query_stats AS qs
                        ON CTE.QUERY_HASH = qs.query_hash
                OUTER APPLY sys.dm_exec_plan_attributes (qs.plan_handle)
                CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS st
         WHERE  attribute = N''dbid''
                AND DB_NAME(CONVERT(INT, value)) = ' + QUOTENAME(@DATABASE_NAME, '''') + '
                ) AS RH  
                WHERE RN = 1 '
PRINT ''
PRINT ''
                  
IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END


                    SET @SQL2 = ' 
  SET QUOTED_IDENTIFIER OFF
  	UPDATE QT 
	SET SQL_TEXT = COALESCE(A.SQL_TEXT,QT.SQL_TEXT), DATE_UPDATED =' + '''' + CONVERT(NVARCHAR(24), @STATS_DATE, 121) +'''' +
	' FROM QUERY_TEXT QT WITH (ROWLOCK, READPAST) INNER JOIN  (' +
				 '  SELECT RH.* FROM OPENQUERY([' + @SERVER_NAME + '], ' +'"' + @SQL +'"' + ') RH
                    ) AS A ON A.QUERY_HASH = QT.QUERY_HASH AND QT.SERVER_NAME = ' +'''' + @SERVER_NAME + '''' +
                    '   AND QT.DATABASE_NAME = ' + '''' + @DATABASE_NAME +''''
                   


IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL2
END
				 
				 EXECUTE (@SQL2)
				 
 --REH  Delete the table back out
 
 
SET @SQL = '

IF EXISTS (SELECT * FROM  [tempdb].sys.objects WHERE name = ''DYNPERF_QUERY_HASH_REFRESH'') 
 DROP TABLE  [tempdb].dbo.DYNPERF_QUERY_HASH_REFRESH '
				 
			SET @SQL2 = ' 
							  SET QUOTED_IDENTIFIER OFF
							  EXEC (' + '"' + @SQL + '"' + ') AT ['
						+ @SERVER_NAME + ']' 


         IF @DEBUG = 'Y'
              BEGIN
                  PRINT '@SQL= ' + @SQL2
              END

         EXEC (@SQL2)

 
 END
 
    

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'SUCCESSFULLY '
              + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' Inserted ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' ROWS ' +  CHAR(10) 
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



PRINT ''
PRINT 'SUCCESSFULLY CAPTURED ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


RETURN(0)  --REH RETURN SUCCESS


END TRY 


/********************************************************************************************************************************
*   END OF TASK
*********************************************************************************************************************************/


BEGIN CATCH
    UPDATE CAPTURE_LOG
    SET    TEXT = TEXT + 'FAILED !!! to '
	      + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
                  + ISNULL(@SERVER_NAME, '') + ' on database '
                  + ISNULL(@DATABASE_NAME, '') + ' at '
                  + CONVERT(VARCHAR, GETDATE(), 109) 
				  + ' ERROR = ' + CAST(@@ERROR AS VARCHAR(MAX))
				  + ', ' 
				  + CHAR(10)
    WHERE  STATS_TIME = @STATS_DATE
	AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)

	
         SET @SQL = '

				IF EXISTS (SELECT * FROM  [' + @DATABASE_NAME + '].sys.objects WHERE name = ''DYNPERF_QUERY_HASH_REFRESH'') 
				 DROP TABLE  [' + @DATABASE_NAME + '].dbo.DYNPERF_QUERY_HASH_REFRESH '
				 
			SET @SQL2 = ' 
							  SET QUOTED_IDENTIFIER OFF
							  EXEC (' + '"' + @SQL + '"' + ') AT ['
						+ @SERVER_NAME + ']' 

			EXEC (@SQL2)


    PRINT 'ERROR WHILE COLLECTING '
          + ISNULL(@TASK_DESC, '') + ' !!!!!!!!!!!!!!'

    RETURN(1) --REH RETURN ERROR, TRAPPED BY SPROC
END CATCH
GO
PRINT N'Altering [dbo].[SET_AX_SQLTRACE]...';


GO


ALTER PROCEDURE [dbo].[SET_AX_SQLTRACE] @SERVER_NAME NVARCHAR(128) = @@SERVERNAME,
								@DATABASE_NAME    NVARCHAR(128),
                                 @QUERY_TIME_LIMIT INT = 5000,
                                 @AX_ID            NVARCHAR(10) = NULL,
                                 @TRACE_STATUS     NVARCHAR(3) = 'ON', 
                               --  @CLIENTACESSLOG   INT = 0,
								 @OVERRIDE		INT = 0
AS

  DECLARE @SQL NVARCHAR(1000),
          @RC  INT

  SET @RC = 0



         IF EXISTS (SELECT *
                    FROM   sys.synonyms
                    WHERE  name = 'DYN_AXT_SYSDATABASES')
           EXEC ('DROP SYNONYM [dbo].DYN_AXT_SYSDATABASES')

         IF @SERVER_NAME <> @@SERVERNAME
              BEGIN
                  --REH  You CANNOT use synonms for queries that pull XML or use FUNCTIONS
                  SET @SQL = '
				CREATE SYNONYM DYN_AXT_SYSDATABASES
				FOR [' + @SERVER_NAME
                             + '].master.sys.databases'
              END
         ELSE
           SET @SQL = '
				CREATE SYNONYM DYN_AXT_SYSDATABASES
				FOR master.sys.databases'


         EXEC (@SQL) -- CREATE SYNONYM

         IF (SELECT COUNT(*)
             FROM   DynamicsPerf.dbo.DYN_AXT_SYSDATABASES
             WHERE  name = @DATABASE_NAME) < 1
              BEGIN
                  PRINT 'DATABASE ' + ISNULL(@DATABASE_NAME, 'NULL')
                        + ' does not exist on server '
                        + ISNULL(@SERVER_NAME, 'NULL')

                  RETURN( 0 );
              END

IF @OVERRIDE = 0 AND @QUERY_TIME_LIMIT < 5000 SET @QUERY_TIME_LIMIT = 5000

  IF @TRACE_STATUS = 'ON'
    BEGIN
        
          SET @SQL = 'UPDATE [' +@SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.USERINFO
				SET QUERYTIMELIMIT = ' + Str(@QUERY_TIME_LIMIT) + ',
					DEBUGINFO = DEBUGINFO | 256,
					TRACEINFO =  TRACEINFO | 2048'
			IF @AX_ID IS NOT NULL	
			SET @SQL = @SQL + 	' WHERE ID = ''' + @AX_ID + ''''	
			

				MERGE AX_SQLTRACE_CONFIG AS target
				USING (SELECT @SERVER_NAME AS SERVER_NAME,
							  @DATABASE_NAME AS DATABASE_NAME,
							  @QUERY_TIME_LIMIT AS SQL_DURATION,
							  1                 AS TRACE_ON,		--REH Turns it ON
							  14 AS AXDB_DELETION_DAYS
) AS source
				ON ( source.SERVER_NAME = target.SERVER_NAME
					 AND source.DATABASE_NAME = target.DATABASE_NAME )
				WHEN MATCHED THEN
				  UPDATE SET SQL_DURATION = source.SQL_DURATION,
							 TRACE_ON = source.TRACE_ON
				WHEN NOT MATCHED THEN
				  INSERT ( [SERVER_NAME],
						   [DATABASE_NAME],
						   [SQL_DURATION],
						   [TRACE_ON],
						   [AXDB_DELETION_DAYS])
				  VALUES (source.[SERVER_NAME],
						  source.[DATABASE_NAME],
						  source.[SQL_DURATION],
						  source.[TRACE_ON],
						  14);		--REH default 14 days, DYNPERF_SET_AX_SQLTRACE sproc will delete from systracetable in the AX database using this value
									-- setting it to 0 disables this feature
			
			END
  ELSE
    IF @TRACE_STATUS = 'OFF'
      BEGIN
          IF @AX_ID IS NULL
            SET @SQL = 'UPDATE [' +@SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.USERINFO
				SET QUERYTIMELIMIT = 0,
                    DEBUGINFO = DEBUGINFO & 2147483391,
                    TRACEINFO = TRACEINFO & 2147481599'
					
			IF @AX_ID IS NOT NULL	
			SET @SQL = @SQL + 	' WHERE ID = ''' + @AX_ID + ''''	

        	--REH Insert a record so that our scheduled job auto updates it
MERGE AX_SQLTRACE_CONFIG AS target
				USING (SELECT @SERVER_NAME AS SERVER_NAME,
							  @DATABASE_NAME AS DATABASE_NAME,
							  @QUERY_TIME_LIMIT AS SQL_DURATION,
							  0                 AS TRACE_ON,		--REH Turns it OFF
							  14 AS AXDB_DELETION_DAYS
					  ) AS source
				ON ( source.SERVER_NAME = target.SERVER_NAME
					 AND source.DATABASE_NAME = target.DATABASE_NAME )
				WHEN MATCHED THEN
				  UPDATE SET SQL_DURATION = source.SQL_DURATION,
							 TRACE_ON = source.TRACE_ON
				WHEN NOT MATCHED THEN
				  INSERT ( [SERVER_NAME],
						   [DATABASE_NAME],
						   [SQL_DURATION],
						   [TRACE_ON],
						   [AXDB_DELETION_DAYS])
				  VALUES (source.[SERVER_NAME],
						  source.[DATABASE_NAME],
						  source.[SQL_DURATION],
						  source.[TRACE_ON],
						  14); --REH default 14 days, DYNPERF_SET_AX_SQLTRACE sproc will delete from systracetable in the AX database using this value
								-- setting it to 0 disables this feature
      END
    ELSE
      PRINT 'Invalid @TRACE_STATUS option; must be ON or OFF'

  PRINT @SQL
  EXEC (@SQL)
 

 
  ENDPROC:

  ERROR:

  RETURN @RC
GO
PRINT N'Altering [dbo].[SP_CAPTURESTATS]...';


GO



ALTER	PROCEDURE [dbo].[SP_CAPTURESTATS]
		@SERVER_NAME	NVARCHAR(128) = NULL,
		@DATABASE_NAME	NVARCHAR(128) = NULL ,
		@DYNAMICS_PRODUCT NVARCHAR(3)  = NULL,
		@TASK_TYPE		VARCHAR(50) = 'COLLECT',
		@AZURE_DB		BIT = 0,
		@TOP_ROWS		INT = 0,
		@TOP_COLUMN		NVARCHAR(128) = 'total_elapsed_time',
		@RUN_NAME		NVARCHAR(128) = NULL,
		@INDEX_PHYSICAL_STATS 	NCHAR(1)= 'N',
		@DEBUG			NVARCHAR(1)= 'N'

AS


SET NOCOUNT ON
SET DATEFORMAT MDY

SET ANSI_NULLS ON
SET ANSI_WARNINGS ON
SET ANSI_NULL_DFLT_ON ON
SET ANSI_PADDING ON


DECLARE @STATS_DATE		DATETIME, 
		@STATS_DATE_HOLD DATETIME,
		@C_SCHED_UNITS CHAR(2),
		@SQL_VERSION	NVARCHAR(1000), 
		@DYNAMICS_VERSION NVARCHAR(MAX),
		@DATABASE_ID	INT,
		@RETURN_CODE	INT,
		@SQL			NVARCHAR(MAX),
		@RUN_DESCRIPTION NVARCHAR(1000),
		@SQL_TOP_CLAUSE	NVARCHAR(128),
		@SQL_ORDERBY_CLAUSE	NVARCHAR(128),
		@PARM			NVARCHAR(500),
		@SQL_SERVER_STARTTIME DATETIME,
		@RC INT,
		@TASK_PROCEDURE NVARCHAR(128),
		@TASK_PARAMETERS NVARCHAR(1024),
		@TASK_DESCRIPTION NVARCHAR(256),
		@LAST_SERVER_NAME NVARCHAR(128) = 'ZZZ',  --REH This is used to trigger inserting a new STATS_COLLECTION_SUMMARY record
		@LAST_DATABASE_NAME NVARCHAR(128) = 'ZZZ',
		@LAST_STATS_DATE DATETIME,
		@REMOTE_SERVER NVARCHAR(1) = 'N',
		@TASK_STARTTIME DATETIME,
		@TASK_ENDTIME DATETIME,
		@TASK_TIME BIGINT,
		@SQL_STARTTIME DATETIME,
		@SQL_BUILD NVARCHAR(20),
		@SQL2 NVARCHAR(MAX),
		@MANUAL_CAPTURE NVARCHAR(1) = 'N',
		@SQL_TZ_OFFSET INT,
		@DPA_TZ_OFFSET INT,
		@RETRY_COUNT INT

		
		
DECLARE
	@C_SERVER_NAME NVARCHAR(128),
	@C_DATABASE_NAME NVARCHAR(128),
	@C_TASK_ID INT,
	@C_TASK_PROCEDURE NVARCHAR(128),
	@C_TASK_PARAMS NVARCHAR(1024),
	@C_TASK_DESC NVARCHAR(256),
	@C_SERVER_LEVEL_TASK BIT,
	@C_AZURE_DB  BIT,
	@C_LAST_RUN DATETIME
	
		
--REH Time zone off set for the DynamicsPerf database at time of collection
		SET @DPA_TZ_OFFSET = DATEDIFF(MI,GETUTCDATE(),GETDATE())

	IF @DATABASE_NAME IS NOT NULL SET @MANUAL_CAPTURE = 'Y'

	SET @STATS_DATE =  DATEADD(MI, DATEDIFF(MI, 0, getdate()), 0) --nearest minute, should end up being 00:00
--REH  Verify database exists if being manually passed, skip check if Azure DB, no access to sys.databases catalogue

IF ( @AZURE_DB = 0 and ( @SERVER_NAME IS NOT NULL AND @SERVER_NAME <> '(local)'
      OR @DATABASE_NAME IS NOT NULL ))
     BEGIN

	 
	          SET @REMOTE_SERVER = CASE ISNULL(@SERVER_NAME, @@SERVERNAME)
                                WHEN @@SERVERNAME THEN 'N'
                                ELSE 'Y'
                              END


         IF EXISTS (SELECT *
                    FROM   sys.synonyms
                    WHERE  name = 'DYN_CS_QUERY_SYSDATABASES')
           EXEC ('DROP SYNONYM [dbo].DYN_CS_QUERY_SYSDATABASES')

         IF @REMOTE_SERVER = 'Y'
              BEGIN
                  --REH  You CANNOT use synonms for queries that pull XML or use FUNCTIONS
                  SET @SQL = '
				CREATE SYNONYM DYN_CS_QUERY_SYSDATABASES
				FOR [' + @SERVER_NAME
                             + '].master.sys.databases'
              END
         ELSE
           SET @SQL = '
				CREATE SYNONYM DYN_CS_QUERY_SYSDATABASES
				FOR master.sys.databases'

         IF @DEBUG = 'Y'
              BEGIN
                  PRINT '@SQL= ' + @SQL
              END

         EXEC (@SQL) -- SELECT * FROM DYN_CS_QUERY_SYSDATABASES

         IF (SELECT COUNT(*)
             FROM   DynamicsPerf.dbo.DYN_CS_QUERY_SYSDATABASES
             WHERE  name = @DATABASE_NAME) < 1
              BEGIN
                  PRINT 'DATABASE ' + ISNULL(@DATABASE_NAME, 'NULL')
                        + ' does not exist on server '
                        + ISNULL(@SERVER_NAME, 'NULL')

                  RETURN( 0 );
              END

         --REH Make sure there is a record in DATABASES_2_COLLECT or insert if new combination
         IF (SELECT COUNT(*)
             FROM   DATABASES_2_COLLECT
             WHERE  LINKED_SERVER = ISNULL(@SERVER_NAME, @@SERVERNAME)
                    AND DATABASE_NAME = @DATABASE_NAME) < 1
              BEGIN
                  INSERT DATABASES_2_COLLECT
                  VALUES(ISNULL(@SERVER_NAME,@@SERVERNAME),
                         @DATABASE_NAME,
                         ISNULL(@DYNAMICS_PRODUCT, 'ALL'),
                         1,
                         2,
                         24,
						 60,
						 2,
						 90,
						 7,
						 -1,
						 0,
						 100,
						 100,
						 100,
						 100,
						 60)
              END
     END 


	          SET @REMOTE_SERVER = CASE ISNULL(@SERVER_NAME, @@SERVERNAME)
                                WHEN @@SERVERNAME THEN 'N'
                                ELSE 'Y'
                              END



---------------------------------------------------------------------------------------------
--
--  Insert Capture_log entry with paramater values used for the run
--
----------------------------------------------------------------------------------------------

INSERT CAPTURE_LOG  SELECT @TASK_TYPE, @STATS_DATE, 'SP_CAPTURESTATS PARMS PASSED @SERVER_NAME = ' + ISNULL(@SERVER_NAME,'NOT PASSED') + ' @DATABASE_NAME = ' + ISNULL(@DATABASE_NAME,'NOT PASSED') +  ' @DEBUG = ' + @DEBUG + '  ' + CHAR(10) + CHAR(13)



SET @RETURN_CODE = 0

DELETE FROM  COLLECTIONDATABASES WHERE TASK_TYPE = @TASK_TYPE  --REH Default is 'COLLECT' for this sproc.  CAN'T TRUNCATE MULTIPLE SPROCS USING THIS TABLE



IF @DATABASE_NAME IS NULL  --REH AKA, not a manual capture
  BEGIN
      INSERT COLLECTIONDATABASES
      SELECT ISNULL(LINKED_SERVER, @@SERVERNAME),
             [DATABASE_NAME],
             [DYNAMICS_PRODUCT],
             [AZURE_DB],
             [ENABLED],
			 @TASK_TYPE
      FROM   DATABASES_2_COLLECT
      WHERE  ENABLED = 1 -- db must be enabled for autostats collection to work with it
  END
ELSE
  BEGIN   --REH  Insert DBname of the manual capture
      INSERT COLLECTIONDATABASES
      VALUES(ISNULL(@SERVER_NAME, @@SERVERNAME),
             @DATABASE_NAME,
             @DYNAMICS_PRODUCT,
             @AZURE_DB,
             1,
			 @TASK_TYPE)
  END 


--REH Insert any missing task history records in case it's a new database being collected, so we don't fail to capture against the db because of no records
-- yes, this is a cartesian join between these 2 tables

INSERT DYNPERF_TASK_HISTORY
SELECT CD.LINKED_SERVER,
       CD.DATABASE_NAME,
       DTS.TASK_ID,
       NULL,
       NULL,
       NULL,
       '1/1/1900',
       0
FROM   DYNPERF_TASK_SCHEDULER DTS
       CROSS APPLY COLLECTIONDATABASES CD
WHERE  CD.TASK_TYPE = @TASK_TYPE	--REH default is 'COLLECT' in parm definition of this sproc
       AND NOT EXISTS (SELECT 'X'
                       FROM   DYNPERF_TASK_HISTORY DTH
                       WHERE  DTS.TASK_ID = DTH.TASK_ID
                              AND CD.LINKED_SERVER = DTH.LINKEDSERVER_NAME
                              AND CD.DATABASE_NAME = DTH.DATABASE_NAME)
       --REH IF DB is Azure then task must support Azure, otherwise all tasks for Non-Azure dbs
       AND ( ( DTS.AZURE_DB_SUPPORTED = 1
               AND CD.AZURE_DB = 1 )
              OR CD.AZURE_DB = 0 )
       AND DTS.TASK_TYPE = @TASK_TYPE
       AND DTS.SERVER_LEVEL_TASK = 0 --REH Ok, to put 1 record per database in for DB type tasks


	   
--REH Need to insert 1 bogus record for each server level task, or the join on the cursor will fail

INSERT COLLECTIONDATABASES 
 SELECT	DISTINCT [LINKED_SERVER],
             'N/A',
            'ALL',
             [AZURE_DB],
             [ENABLED],
			 [TASK_TYPE]
FROM COLLECTIONDATABASES CD
WHERE DATABASE_NAME <> 'N/A'
AND TASK_TYPE = @TASK_TYPE
AND NOT EXISTS (SELECT 'X' FROM COLLECTIONDATABASES CD2 WHERE CD2.LINKED_SERVER = CD.LINKED_SERVER AND CD2.DATABASE_NAME = 'N/A')



--REH now lets insert server level tasks with a blank DB name so we only do them once per server
INSERT DYNPERF_TASK_HISTORY
SELECT CD.LINKED_SERVER,
       'N/A',
       DTS.TASK_ID,
       NULL,
       NULL,
       NULL,
       '1/1/1900',
       0
FROM   DYNPERF_TASK_SCHEDULER DTS
       CROSS APPLY COLLECTIONDATABASES CD
WHERE  CD.TASK_TYPE = @TASK_TYPE  --REH default is 'COLLECT' in parm definition of this sproc
		AND CD.DATABASE_NAME <> 'N/A'
       AND NOT EXISTS (SELECT 'X'
                   FROM   DYNPERF_TASK_HISTORY DTH
                   WHERE  DTS.TASK_ID = DTH.TASK_ID
                          AND CD.LINKED_SERVER = DTH.LINKEDSERVER_NAME
                          AND DTH.DATABASE_NAME = 'N/A') --REH making the db name = 'N/A' for server level tasks
       --REH IF DB is Azure then task must support Azure, otherwise all tasks for Non-Azure dbs
       AND ( ( DTS.AZURE_DB_SUPPORTED = 1
               AND CD.AZURE_DB = 1 )
              OR CD.AZURE_DB = 0 )
       AND DTS.TASK_TYPE = @TASK_TYPE
       AND DTS.SERVER_LEVEL_TASK = 1 






	IF @DEBUG = 'Y'
	BEGIN
		PRINT 'MANUAL_CAPTURE = ' + @MANUAL_CAPTURE
	END

	--REH Create here and truncate table in each loop

	 --  CREATE TABLE #SQL_INFO
  --   (
  --      SQL_STARTTIME DATETIME,
  --      SQL_BUILD NVARCHAR(20),
		--TZ_OFFSET INT
  --   )


/********************************************************************************
Rod Hansen

Added a trigger to DATABASES_2_COLLECT so that we always have a 
DYNPERF_TASK_HISTORY record for this code 

********************************************************************************/

DECLARE TASK_CURSOR CURSOR  LOCAL
FOR
SELECT DISTINCT DTS.TASK_ID,
       CD.LINKED_SERVER,
       CD.DATABASE_NAME,
       DTS.TASK_PROCEDURE,
       DTS.TASK_PARAMETERS,
       DTS.TASK_DESCRIPTION,
       DTS.SERVER_LEVEL_TASK,
       CD.AZURE_DB,
       ISNULL(DTH.LAST_RUN, '1/1/1900'),
	   COALESCE(DTH.SCHEDULE_UNITS, DTS.SCHEDULE_UNITS)  -- Need this to do calculations after task is run

FROM   DynamicsPerf..[DYNPERF_TASK_SCHEDULER] DTS
       LEFT OUTER JOIN DynamicsPerf..[DYNPERF_TASK_HISTORY] DTH
                    ON DTH.TASK_ID = DTS.TASK_ID
       INNER JOIN DynamicsPerf..COLLECTIONDATABASES CD
               ON CD.DATABASE_NAME = DTH.DATABASE_NAME
                  AND CD.LINKED_SERVER = DTH.LINKEDSERVER_NAME
WHERE
  --REH Task is enabled
  DTS.ENABLED = 1
  AND
  --REH It's the correct task type C = COLLECTOR, P = PROCESS, M = MONITOR, ETC
  DTS.TASK_TYPE = @TASK_TYPE
  AND
  --REH database is enabled
  CD.ENABLED = 1
  AND
  --REH Azure_db, if Azure db, then task must support it
  ( CD.AZURE_DB = DTS.AZURE_DB_SUPPORTED
     OR CD.AZURE_DB = 0 )
  --REH Either its an Azure Task, all Azure tasks will run locally, so if task supports AZ and we pass 0, run it anyways
  AND ( DTS.AZURE_DB_SUPPORTED = @AZURE_DB
         OR ( DTS.AZURE_DB_SUPPORTED = 1
              AND @AZURE_DB = 0 ) )
  AND
  --REH it's either All products or matches the Dynamics Product
  ( DTS.DYNAMICS_PRODUCT = 'ALL'
     OR DTS.DYNAMICS_PRODUCT = CD.DYNAMICS_PRODUCT )
  AND
  --REH Scheduling options now
(
  --REH In the case of minutes or hours, we ignore schedule time and just figure out if it's time to run again
  ( @MANUAL_CAPTURE = 'Y'
     OR ( @MANUAL_CAPTURE = 'N'
          AND ( CASE COALESCE(DTH.SCHEDULE_UNITS, DTS.SCHEDULE_UNITS)
                  WHEN 'MI' THEN DATEADD(MINUTE, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                END ) <= GETDATE()
           OR ( ( CASE COALESCE(DTH.SCHEDULE_UNITS, DTS.SCHEDULE_UNITS)
                    WHEN 'HH' THEN DATEADD(HOUR, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                  END ) <= GETDATE()
                --REH and it is on the hour
                AND ( ABS(DATEDIFF(MI, DATEADD(Hour, DATEDIFF(Hour, 0, GETDATE()), 0), GETDATE())) <= 1 ) )
           OR ( ( CASE COALESCE(DTH.SCHEDULE_UNITS, DTS.SCHEDULE_UNITS)
                    WHEN 'DD' THEN DATEADD(DAY, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                    WHEN 'WK' THEN DATEADD(WEEK, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                    WHEN 'MM' THEN DATEADD(WEEK, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                    WHEN 'QQ' THEN DATEADD(WEEK, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                    WHEN 'YY' THEN DATEADD(WEEK, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                  END ) <= GETDATE()
                AND ( --REH TIME IS NULL SO IGNORE IT
                    COALESCE(DTH.SCHEDULE_TIME, DTS.SCHEDULE_TIME) IS NULL
                     OR --REH Current time = Scheduled time 
                    ( SUBSTRING((SELECT REPLACE(CONVERT(VARCHAR(10), GETDATE(), 108), ':', '')), 1, 4) = (SELECT REPLICATE('0', 4 - LEN( COALESCE(DTH.SCHEDULE_TIME, DTS.SCHEDULE_TIME)))
                                                                                                                 + CAST( COALESCE(DTH.SCHEDULE_TIME, DTS.SCHEDULE_TIME) AS VARCHAR(4))) ) ) )
         --REH and last_run < current time
         )--AND CONVERT(VARCHAR(10), LAST_RUN, 108) <= CONVERT(VARCHAR(10), Getdate(), 108) ) 
   )
)
ORDER  BY CD.LINKED_SERVER,
          CD.DATABASE_NAME,
          DTS.TASK_ID 



/* Open the cursor */
/*if the cursor isn't open you will get an error when you fetch the record*/
OPEN TASK_CURSOR 

/* Get the first record */
/* you can FETCH NEXT, FIRST, LAST, PREVIOUS */
FETCH NEXT FROM TASK_CURSOR INTO @C_TASK_ID, @C_SERVER_NAME, @C_DATABASE_NAME, @C_TASK_PROCEDURE, @C_TASK_PARAMS, @C_TASK_DESC, @C_SERVER_LEVEL_TASK,@C_AZURE_DB, @C_LAST_RUN, @C_SCHED_UNITS


/* Verify that we got a record*/
/* status 0 means we got a good record*/

WHILE @@fetch_status = 0  /* no errors */
BEGIN /* Top of Loop */


	          SET @REMOTE_SERVER = CASE ISNULL(@C_SERVER_NAME, @@SERVERNAME)
                                WHEN @@SERVERNAME THEN 'N'
                                ELSE 'Y'
                              END


--Insert new STATS_COLLECTION_SUMMARY RECORD, we want 1 RUN_NAME per server not per database
IF @C_SERVER_NAME <> @LAST_SERVER_NAME OR @C_DATABASE_NAME <> @LAST_DATABASE_NAME
BEGIN
    SET @RUN_NAME = ISNULL(@C_SERVER_NAME, @@SERVERNAME)+ ' '
                    + CAST(@STATS_DATE AS VARCHAR(30))

TRUNCATE TABLE WRK_CS_SQL_INFO   --REH clear out table to repopulate

 DELETE FROM COLLECTIONDATABASES WHERE LINKED_SERVER = @LAST_SERVER_NAME AND DATABASE_NAME = @LAST_DATABASE_NAME AND TASK_TYPE = @TASK_TYPE  --REH CLEANUP IN CASE SOMEBODY ELSE RUNS MANUAL CAPTURE


 
SELECT @SQL = 'SELECT create_date AS SQL_STARTTIME,
       CAST(Serverproperty(''ProductVersion'') AS NVARCHAR(20))    AS SQL_BUILD,
	   DATEDIFF(MI,GETUTCDATE(),GETDATE()) AS TZ_OFFSET
		FROM sys.databases WHERE name = ''TempDB'''

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END


   
   SET NOCOUNT ON
 
IF @REMOTE_SERVER = 'N'
BEGIN
		   INSERT WRK_CS_SQL_INFO
		EXEC( @SQL)
END

 IF @REMOTE_SERVER = 'Y'
 BEGIN
			IF @C_AZURE_DB = 0
			BEGIN
				SET @SQL2 = ' 
				SET QUOTED_IDENTIFIER OFF
					SELECT  * FROM OPENQUERY(['+@C_SERVER_NAME+ '],"
				SELECT create_date AS SQL_STARTTIME,
				CAST(Serverproperty(''ProductVersion'') AS NVARCHAR(20))  AS SQL_BUILD,
				DATEDIFF(MI,GETUTCDATE(),GETDATE()) AS TZ_OFFSET
				FROM sys.databases WHERE name = ''TempDB''"	)'
			END
			IF @C_AZURE_DB = 1
			BEGIN
				SET @SQL2 = ' 
				SET QUOTED_IDENTIFIER OFF
					SELECT  * FROM OPENQUERY(['+@C_SERVER_NAME+ '],"
				SELECT DATEADD(ms,�AVG(-wait_time_ms), GETDATE())� AS SQL_STARTTIME,
				CAST(Serverproperty(''ProductVersion'') AS NVARCHAR(20))  AS SQL_BUILD,
				DATEDIFF(MI,GETUTCDATE(),GETDATE()) AS TZ_OFFSET
				FROM�sys.dm_os_wait_stats w� WHERE�wait_type�
IN�(''DIRTY_PAGE_POLL'',''HADR_FILESTREAM_IOMGR_IOCOMPLETION'',''LAZYWRITER_SLEEP'',''LOGMGR_QUEUE'',''REQUEST_FOR_DEADLOCK_SEARCH'',''XE_DISPATCHER_WAIT'',''XE_TIMER_EVENT'') "	)'
			END


				IF @DEBUG = 'Y'
                  BEGIN
                      PRINT '@SQL= ' + @SQL2
                  END 
                
			INSERT WRK_CS_SQL_INFO
				EXEC (@SQL2) 
 
 END
 
 SELECT @SQL_STARTTIME = SQL_STARTTIME, @SQL_BUILD = SQL_BUILD, @SQL_TZ_OFFSET = TZ_OFFSET FROM WRK_CS_SQL_INFO
 TRUNCATE TABLE WRK_CS_SQL_INFO --REH Cleanout the table for next loop





		INSERT INTO [DynamicsPerf].[dbo].[STATS_COLLECTION_SUMMARY]
					([SERVER_NAME],
					 [STATS_TIME],
					 [RUN_NAME],
					 [DATABASE_NAME],
					 [SQL_VERSION],
					 [DYNAMICS_VERSION],
					 [RUN_DESCRIPTION],
					 [SQL_SERVER_STARTTIME],
					 [SQL_SERVER_TZ_OFFSET] ,
					 [DPA_TZ_OFFSET])
		VALUES      (@C_SERVER_NAME,
					 @STATS_DATE,
					 @RUN_NAME,
					 @C_DATABASE_NAME,
					 @SQL_BUILD,--<SQL_VERSION>
					 '',--<DYNAMICS_VERSION>
					 '',--<RUN_DESCRIPTION>
					 @SQL_STARTTIME, -- <SQL_SERVER_STARTTIME>
					 @SQL_TZ_OFFSET,  -- Time Zone offset in minutes of database collected
					 @DPA_TZ_OFFSET  -- Time Zone of the DynamicsPerf database
					) 
				
END 

SET @LAST_SERVER_NAME = @C_SERVER_NAME
SET @LAST_DATABASE_NAME = @C_DATABASE_NAME


SET @REMOTE_SERVER = CASE @C_SERVER_NAME
                       WHEN @@SERVERNAME THEN 'N'
                       ELSE 'Y'
                     END 



--Create synonyms for the sproc

--IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = 'DYN_CS_CAPTURE_SPROC')
--DROP SYNONYM [dbo].[DYN_CS_CAPTURE_SPROC]
--SET @SQL = '
--CREATE SYNONYM DYN_CS_CAPTURE_SPROC
--FOR [DynamicsPerf].dbo.[' + @C_TASK_PROCEDURE + ']'

--IF @DEBUG = 'Y' 
--BEGIN
--PRINT '@SQL= ' + @SQL
--END

--EXEC(@SQL) 

IF @DEBUG = 'Y' 
BEGIN
PRINT 'TASK ID = ' + CAST(@C_TASK_ID AS VARCHAR(10))
PRINT 'SERVER NAME = ' + @C_SERVER_NAME 
PRINT 'DATABASE NAME = ' + @C_DATABASE_NAME
PRINT 'TASK PARMS = ' + ISNULL(@C_TASK_PARAMS, '')
PRINT 'TASK DESC = ' + ISNULL(@C_TASK_DESC,'')
PRINT 'LAST RUN = ' + ISNULL(CAST(@C_LAST_RUN AS VARCHAR(30)),'')
PRINT 'RUN NAME = ' + ISNULL(@RUN_NAME,'')
PRINT 'STATS DATE = ' + CAST(@STATS_DATE AS VARCHAR(30))
PRINT 'REMNOTE SERVER FLAG = ' + ISNULL(@REMOTE_SERVER,'')
PRINT 'AZURE DB = ' + CAST(@C_AZURE_DB AS CHAR(1))


END
			
	

BEGIN TRY
PRINT 'STARTING ' + ISNULL(@C_TASK_DESC, '') + CONVERT(VARCHAR, GETDATE(), 109)
PRINT ''


SET @TASK_STARTTIME = GETDATE()
SET @C_TASK_PARAMS = ISNULL(@C_TASK_PARAMS,'')


IF @DEBUG = 'Y'
BEGIN

	PRINT 'SERVER TIME ZONE OFFSET = ' + CAST(@DPA_TZ_OFFSET AS VARCHAR(10))
	PRINT 'AT LAST RUN  = ' + CAST(@C_LAST_RUN AS VARCHAR(30))

END

--REH Adjust the last_run time to UTC Time, the called sproc's will adjust it to local time unless we've never collected
IF @C_LAST_RUN > '1/1/1901'
BEGIN
SET @C_LAST_RUN = DATEADD(MI,@DPA_TZ_OFFSET *-1 ,@C_LAST_RUN)
END


-- REH Adjusting last_run when its never be run to get things in last 5 mins
--   This is to prevent the massive data load on QUERY_STATS on 1st collection on large memory systems
IF @C_LAST_RUN < '1/1/2016'
BEGIN
SET @C_LAST_RUN = DATEADD(MI,@DPA_TZ_OFFSET *-1 ,DATEADD(MI,-5,GETDATE()))
END


IF @DEBUG = 'Y'
BEGIN
	PRINT 'AT LAST RUN TIME BEING PASSED TO SPROC ' + CAST(@C_LAST_RUN AS VARCHAR(30))
END

SELECT @SQL = 'EXEC ' + @C_TASK_PROCEDURE + '  @TASK_ID=' + CAST(@C_TASK_ID AS NVARCHAR(10)) + 
' ,@SERVER_NAME = ' + '''' +  @C_SERVER_NAME + '''' +
' ,@DATABASE_NAME = ' + '''' +  @C_DATABASE_NAME + '''' +
' ,@TASK_PARAMS = ' +  '''' +  @C_TASK_PARAMS + '''' +
' ,@TASK_DESC = ' + '''' +  @C_TASK_DESC + '''' +
' ,@LAST_RUN = ' + '''' + CONVERT(VARCHAR, @C_LAST_RUN, 109) + '''' +
' ,@RUN_NAME = ' + '''' +  @RUN_NAME + '''' +
' ,@STATS_DATE = ' + '''' + CONVERT(VARCHAR, @STATS_DATE, 109) + '''' +
' ,@REMOTE_SERVER = ' + '''' +  @REMOTE_SERVER + '''' +
' ,@AZURE_DB = ' + CAST(@C_AZURE_DB AS NVARCHAR(10)) + 
' ,@SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET AS NVARCHAR(10)) + 
' ,@DPA_TZ_OFFSET = ' + CAST(@DPA_TZ_OFFSET AS NVARCHAR(10)) + 


' ,@DEBUG = '  + '''' +  @DEBUG + ''''



UPDATE CAPTURE_LOG
SET    TEXT = TEXT  + CHAR(13) + CHAR(10) + '***** ' + @C_TASK_PROCEDURE
			+ CHAR(13) + CHAR(10)
WHERE  STATS_TIME = @STATS_DATE AND TASK_TYPE = @TASK_TYPE



EXECUTE @RC = sp_executesql @SQL


	
   					  
SET @TASK_ENDTIME = GETDATE()

SET @TASK_TIME = DATEDIFF(ss,@TASK_STARTTIME, @TASK_ENDTIME)

 
 /*************** RETRY LOGIC ************************/
IF @RC = 1
   AND @TASK_TIME < 10 -- IT FAILED AND WAS LESS THEN 10 SECONDS
  BEGIN
      WAITFOR DELAY '00:00:02' -- REH Wait 2 seconds and try again if sproc trapped the error
      EXECUTE @RC = Sp_executesql
        @SQL

      SET @TASK_ENDTIME = GETDATE()
      SET @TASK_TIME = DATEDIFF(SS, @TASK_STARTTIME, @TASK_ENDTIME)
  END 

  
--REH update last  [DYNPERF_TASK_HISTORY] IF THE TASK WAS SUCCESSFUL


  
 IF @RC = 0
      BEGIN
          PRINT ''
 
          PRINT 'SUCCESSFULLY CAPTURED '
                + ISNULL(@C_TASK_DESC, '') +  ' for SERVER '
              + ISNULL(@C_SERVER_NAME, '') + ' on database '
              + ISNULL(@C_DATABASE_NAME, '') + ' in ' + cast(@TASK_TIME AS VARCHAR(20)) + ' SECONDS '
 
 -- REH set last run for daily tasks to previous day so that they will run at midnight from here forward
 SET @STATS_DATE_HOLD = @STATS_DATE
 IF @C_SCHED_UNITS IN ('DD','WK','MM','QQ', 'YY') 

 BEGIN
	--REH Adjust to midnight the previous night if last run was 1/1/1900 so that all daily tasks will then run at midnight

		--REH floor it to today then subtract 2 mins so that its before midnight so that daily tasks will run at 
		-- midnight from now on and not run when we installed DynamicsPerf

	 SET @STATS_DATE_HOLD = DATEADD(MI,-2,dateadd(DAY,datediff(DAY,0,@STATS_DATE),0))


 END

       --REH if a manual capture don't update last run so we don't mess up the scheduling engine
				 IF @MANUAL_CAPTURE = 'N'
				 BEGIN
						  MERGE DynamicsPerf..[DYNPERF_TASK_HISTORY] AS target
						  USING (SELECT @C_SERVER_NAME   AS SERVER_NAME,
										@C_DATABASE_NAME AS DATABASE_NAME,
										@C_TASK_ID       AS TASK_ID,
										@STATS_DATE_HOLD AS LAST_RUN,
										@TASK_TIME	AS LAST_EXECUTION_TIME_SECS 
												) AS source
						  ON ( source.SERVER_NAME = target.LINKEDSERVER_NAME
							   AND source.DATABASE_NAME = target.DATABASE_NAME
							   AND source.TASK_ID = target.TASK_ID )
						  WHEN MATCHED THEN
							UPDATE SET LAST_RUN = source.LAST_RUN, [LAST_EXECUTION_TIME_SECS] = source.[LAST_EXECUTION_TIME_SECS]
						  WHEN NOT MATCHED THEN
							INSERT ( [LINKEDSERVER_NAME],
									 [DATABASE_NAME],
									 [TASK_ID],
									 [LAST_RUN],
									 [LAST_EXECUTION_TIME_SECS])
							VALUES (source.SERVER_NAME,
									source.DATABASE_NAME,
									source.TASK_ID,
									source.LAST_RUN,
									source.LAST_EXECUTION_TIME_SECS );
				END
      END
 ELSE
	IF @RC = 1  --REH SPROC HANDLED THE ERROR
      BEGIN
          PRINT ''
 
          PRINT 'FAILED !!!!!! ' + ISNULL(@C_TASK_DESC, '')
 
          PRINT ''
      END 
 
  


           IF EXISTS (SELECT *
                    FROM   sys.synonyms
                    WHERE  name = 'DYN_CS_QUERY_SYSDATABASES')
           EXEC ('DROP SYNONYM [dbo].DYN_CS_QUERY_SYSDATABASES')



END TRY 

BEGIN CATCH


UPDATE CAPTURE_LOG
SET    TEXT = TEXT + ' PROCEDURE FAILED !!! '
              + ISNULL(@C_TASK_DESC, 'TASK') + ' for SERVER
        '
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) + ', '
                          + ' ERROR = ' + CAST(@@ERROR AS VARCHAR(MAX)) 
WHERE  STATS_TIME = @STATS_DATE AND TASK_TYPE = @TASK_TYPE


PRINT 'ERROR WHILE COLLECTING ' + ISNULL(@C_TASK_DESC, '') +' !!!!!!!!!!!!!!'




         IF EXISTS (SELECT *
                    FROM   sys.synonyms
                    WHERE  name = 'DYN_CS_QUERY_SYSDATABASES')
           EXEC ('DROP SYNONYM [dbo].DYN_CS_QUERY_SYSDATABASES')

END CATCH



FETCH NEXT FROM TASK_CURSOR INTO @C_TASK_ID, @C_SERVER_NAME, @C_DATABASE_NAME, @C_TASK_PROCEDURE, @C_TASK_PARAMS, @C_TASK_DESC, @C_SERVER_LEVEL_TASK,@C_AZURE_DB, @C_LAST_RUN, @C_SCHED_UNITS


END  /*End of the loop */
CLOSE TASK_CURSOR  /*close the cursor to free memory in SQL*/
DEALLOCATE TASK_CURSOR /*Must deallocate the cursor to destroy it and free SQL resources*/
 
	  DELETE FROM COLLECTIONDATABASES WHERE TASK_TYPE = @TASK_TYPE  --REH CLEANUP IN CASE SOMEBODY ELSE RUNS MANUAL CAPTURE
		

ENDPROC:
PRINT 'RUN NAME = '+ @RUN_NAME
GO
PRINT N'Altering [dbo].[SP_LOGBLOCKS_MS]...';


GO


ALTER PROCEDURE [dbo].[SP_LOGBLOCKS_MS]
AS



SET nocount ON
SET DATEFORMAT MDY 


-- ***********************************************************************
-- Copyright � Microsoft Corporation.� All rights reserved.�
-- This script is made available to you without any express, implied or statutory warranty, 
-- not even the implied warranty of merchantability or fitness for a particular purpose, 
-- or the warranty of title or non-infringement.� 
-- The entire risk of the use or the results from the use of this script remains with you.
-- ***********************************************************************

DECLARE @BLOCKED TABLE(
  BLOCKER_LOGIN          NVARCHAR(128) COLLATE database_default,
  BLOCKER_PROGRAM        NVARCHAR(128) COLLATE database_default,
  BLOCKER_HOSTNAME       NVARCHAR(128) COLLATE database_default,
  BLOCKED_LOGIN          NVARCHAR(128) COLLATE database_default,
  BLOCKED_PROGRAM        NVARCHAR(128) COLLATE database_default,
  BLOCKED_HOSTNAME       NVARCHAR(128) COLLATE database_default,
  BLOCKER_SESSION_ID     SMALLINT,
  BLOCKER_CONTEXT_INFO	 BINARY (128),
  BLOCKER_CONTEXT        NVARCHAR(MAX) COLLATE database_default,
  BLOCKER_TRAN_ISOLATION NVARCHAR(20) COLLATE database_default,
  BLOCKER_STATUS         NVARCHAR(18) COLLATE database_default,
  BLOCKED_SESSION_ID     SMALLINT,
  BLOCKED_CONTEXT_INFO	 BINARY(128),
  BLOCKED_CONTEXT        NVARCHAR(MAX) COLLATE database_default,
  BLOCKED_TRAN_ISOLATION NVARCHAR(20) COLLATE database_default,
  TRANSACTION_ID		 BIGINT,
  WAIT_TIME              BIGINT,
  LOCK_MODE              NVARCHAR(60) COLLATE database_default,
  LOCK_SIZE              NVARCHAR(6) COLLATE database_default,
  DATABASE_NAME          NVARCHAR(128) COLLATE database_default,
  OBJECT_NAME            NVARCHAR(128) COLLATE database_default,
  INDEX_ID               INT,
  BLOCKER_SQL            NVARCHAR(MAX) COLLATE database_default,
  BLOCKER_PLAN           XML,
  BLOCKED_SQL            NVARCHAR(MAX) COLLATE database_default,
  BLOCKED_PLAN           XML ) 




DECLARE @BLOCKER_SESSION_ID     SMALLINT,
        @BLOCKER_CONTEXT        NVARCHAR(MAX),
        @BLOCKER_CONTEXT_INFO	BINARY(128),
        @BLOCKER_TRAN_ISOLATION NVARCHAR(20),
        @BLOCKER_STATUS         NVARCHAR(18),
        @BLOCKED_SESSION_ID     SMALLINT,
        @BLOCKED_CONTEXT        NVARCHAR(MAX),
        @BLOCKED_CONTEXT_INFO	BINARY(128),
        @BLOCKED_TRAN_ISOLATION NVARCHAR(20),
        @WAITTIME               BIGINT,
        @LOCK_MODE              NVARCHAR(60),
        @LOCK_SIZE              CHAR(6),
        @DATABASE_NAME          NVARCHAR(128),
        @ASSOCIATEDOBJECTID     BIGINT,
        @OBJECT_NAME            NVARCHAR(128),
        @INDEX_ID               INT,
        @BLOCKER_SQL            NVARCHAR(MAX),
        @BLOCKER_PLAN           XML,
        @BLOCKED_SQL            NVARCHAR(MAX),
        @BLOCKED_PLAN           XML,
        @SQL                    NVARCHAR(4000),
        @PARM                   NVARCHAR(500),
        @BLOCKED_LOGIN          NVARCHAR(128),
        @BLOCKED_PROGRAM        NVARCHAR(128),
        @BLOCKED_HOSTNAME       NVARCHAR(128),
        @BLOCKER_LOGIN          NVARCHAR(128),
        @BLOCKER_PROGRAM        NVARCHAR(128),
        @BLOCKER_HOSTNAME       NVARCHAR(128),
        @TRANSACTION_ID			BIGINT,
        @rows                   BIGINT 



SET NOCOUNT ON
SET DATEFORMAT MDY
--	-------------------------------------------------------------------------------------
--	Populate temporary table #BLOCKED from sysindexes for blocked and blocking processes
--	-------------------------------------------------------------------------------------
DECLARE BLOCKED CURSOR FOR
SELECT WAIT.blocking_session_id,
       WAIT.session_id,
       Rtrim(CONVERT(NVARCHAR(MAX), BLOCKED.context_info)),
       CASE BLOCKED.transaction_isolation_level
         WHEN 1 THEN 'Read Uncommitted'
         WHEN 2 THEN 'Read Committed'
         WHEN 3 THEN 'Repeatable Read'
         WHEN 4 THEN 'Serializable'
         WHEN 5 THEN 'Snapshot'
         ELSE Str(BLOCKED.transaction_isolation_level)
       END,
       WAIT.wait_duration_ms,
       WAIT.wait_type,
       CASE
         WHEN resource_description LIKE 'objectlock%' THEN 'Object'
         WHEN resource_description LIKE 'pagelock%' THEN 'Page'
         WHEN resource_description LIKE 'keylock%' THEN 'Key'
         WHEN resource_description LIKE 'ridlock%' THEN 'Row'
         ELSE 'N/A'
       END,
       Db_name(BLOCKED.database_id),
       CASE
         WHEN resource_description LIKE '%associatedObjectId%' THEN CONVERT(BIGINT, Substring (resource_description, Charindex('associatedObjectId=', resource_description)
                                                                                                                     + 19, ( Len(resource_description) + 1 ) - ( Charindex('associatedObjectId=', resource_description)
                                                                                                                                                                 + 19 )))
         ELSE 0
       END,
       BLOCKEDSQL.text,
       BLOCKEDPLAN.query_plan,
       BLOCKED.transaction_id
FROM   sys.dm_os_waiting_tasks WAIT
       INNER LOOP JOIN sys.dm_exec_requests AS BLOCKED
                    ON WAIT.session_id = BLOCKED.session_id
       OUTER APPLY sys.dm_exec_sql_text(BLOCKED.sql_handle) AS BLOCKEDSQL
       OUTER APPLY sys.dm_exec_query_plan(BLOCKED.plan_handle) AS BLOCKEDPLAN
WHERE  WAIT.wait_type LIKE 'LCK%' 


--AND			database_id = db_id()


OPEN BLOCKED

FETCH BLOCKED INTO 
	@BLOCKER_SESSION_ID		,
	@BLOCKED_SESSION_ID		,
	@BLOCKED_CONTEXT		, 
	@BLOCKED_TRAN_ISOLATION		,
	@WAITTIME				,
	@LOCK_MODE				,
	@LOCK_SIZE				,
	@DATABASE_NAME			,
	@ASSOCIATEDOBJECTID		,
	@BLOCKED_SQL			,
	@BLOCKED_PLAN			,
	@TRANSACTION_ID		

WHILE @@FETCH_STATUS = 0
	BEGIN
		IF EXISTS (SELECT * FROM sys.dm_exec_requests where session_id = @BLOCKER_SESSION_ID)
			
			BEGIN
				SELECT @BLOCKER_CONTEXT = '; Waiting on ' + wait_type,
                       @BLOCKER_TRAN_ISOLATION = CASE transaction_isolation_level
                                                   WHEN 1 THEN 'Read Uncommitted'
                                                   WHEN 2 THEN 'Read Committed'
                                                   WHEN 3 THEN 'Repeatable Read'
                                                   WHEN 4 THEN 'Serializable'
                                                   WHEN 5 THEN 'Snapshot'
                                                   ELSE Str(transaction_isolation_level)
                                                 END,
                       --	-------------------------------------------------------------------------------------
                       --	If blocking process is not waiting on a lock, it is a lead blocker
                       --	-------------------------------------------------------------------------------------
                       @BLOCKER_STATUS = CASE
                                           WHEN blocking_session_id = 0 THEN 'Lead Blocker'
                                           WHEN REQUESTS.session_id = blocking_session_id THEN 'Lead Blocker'
                                           ELSE 'In Blocking Chain'
                                         END,
                       @BLOCKER_SQL = BLOCKERSQL.text,
                       @BLOCKER_PLAN = query_plan
                FROM   sys.dm_exec_requests AS REQUESTS
                       OUTER APPLY sys.dm_exec_sql_text(sql_handle) AS BLOCKERSQL
                       OUTER APPLY sys.dm_exec_query_plan(plan_handle)
                WHERE  REQUESTS.session_id = @BLOCKER_SESSION_ID 
                
		END
	ELSE IF EXISTS (SELECT * FROM  sys.dm_exec_connections WHERE session_id = @BLOCKER_SESSION_ID)
--	-------------------------------------------------------------------------------------
--	If blocker does not have an active request, retrieve most recent information from
--      sys.dm_exec_connections.  
--	SQL txt is via sys.dm_exec_connections.most_recent_sql_handle
--	and the query plan via sys.dm_exec_query_stats.plan_handle
--	-------------------------------------------------------------------------------------
		BEGIN
			SELECT @BLOCKER_CONTEXT = '',
				   @BLOCKER_TRAN_ISOLATION = 'n/a',
				   @BLOCKER_STATUS = 'Lead Blocker',
				   @BLOCKER_SQL = text,
				   @BLOCKER_PLAN = query_plan
			FROM   sys.dm_exec_connections AS CONNECTIONS
				   OUTER APPLY sys.dm_exec_sql_text(CONNECTIONS.most_recent_sql_handle)
				   LEFT JOIN sys.dm_exec_query_stats AS QUERYSTATS
						  ON most_recent_sql_handle = sql_handle
				   OUTER APPLY sys.dm_exec_query_plan(QUERYSTATS.plan_handle)
			WHERE  session_id = @BLOCKER_SESSION_ID 


--	-------------------------------------------------------------------------------------
--	Retrieve blocker's session INFORMATION
--	-------------------------------------------------------------------------------------
			SELECT
			--	@BLOCKER_CONTEXT = '',
			@BLOCKER_TRAN_ISOLATION = CASE transaction_isolation_level
										WHEN 1 THEN 'Read Uncommitted'
										WHEN 2 THEN 'Read Committed'
										WHEN 3 THEN 'Repeatable Read'
										WHEN 4 THEN 'Serializable'
										WHEN 5 THEN 'Snapshot'
										ELSE Str(transaction_isolation_level)
									  END,
			@BLOCKER_LOGIN = login_name,
			@BLOCKER_PROGRAM = program_name,
			@BLOCKER_HOSTNAME = host_name
			FROM   sys.dm_exec_sessions
			WHERE  session_id = @BLOCKER_SESSION_ID 

		END
		
--	-------------------------------------------------------------------------------------
--	Determine User INformation 
--	-------------------------------------------------------------------------------------

			SELECT @BLOCKER_LOGIN = login_name,
				   @BLOCKER_PROGRAM = program_name,
				   @BLOCKER_HOSTNAME = host_name,
				   @BLOCKER_CONTEXT_INFO = context_info 
			FROM   sys.dm_exec_sessions
			WHERE  session_id = @BLOCKER_SESSION_ID

			SELECT @BLOCKED_LOGIN = login_name,
				   @BLOCKED_PROGRAM = program_name,
				   @BLOCKED_HOSTNAME = host_name,
				   @BLOCKED_CONTEXT_INFO = context_info
			FROM   sys.dm_exec_sessions
			WHERE  session_id = @BLOCKED_SESSION_ID 
			

			

		
--	-------------------------------------------------------------------------------------
--	Determine Object ID of lock request
--	-------------------------------------------------------------------------------------


	IF @LOCK_SIZE IN('Row','Key','Page')
		 BEGIN
			SET @SQL=	'USE ['+ @DATABASE_NAME + '] SELECT @OBJECT_NAME_OUT = OBJECT_NAME(object_id),@INDEX_ID_OUT = index_id, @rows_out = 0	FROM '+
						@DATABASE_NAME+
						'.sys.partitions PAR with (NOLOCK)  JOIN ' +@DATABASE_NAME+ + '.sys.sysobjects OBJ ON OBJ.ID = PAR.OBJECT_ID	WHERE partition_id = ' + cast(@ASSOCIATEDOBJECTID as varchar(MAX))
			SET	@PARM = '@OBJECT_NAME_OUT NVARCHAR(128) OUTPUT, @INDEX_ID_OUT INT OUTPUT,@rows_out bigint OUTPUT'

			EXEC sp_executesql	@SQL, 
								@PARM,
								@OBJECT_NAME_OUT    = @OBJECT_NAME OUTPUT,
								@INDEX_ID_OUT = @INDEX_ID OUTPUT,
								@rows_out = @rows OUTPUT
								
								--print @SQL
		END
	ELSE
		BEGIN
			SET @SQL=	'USE ['+ @DATABASE_NAME + '] SELECT @OBJECT_NAME_OUT  = name,@INDEX_ID_OUT = 0, @rows_out = 0	FROM '+
						@DATABASE_NAME+
						'.sys.objects with (NOLOCK)	WHERE object_id = '+ cast(@ASSOCIATEDOBJECTID as varchar(MAX))
			SET	@PARM = '@OBJECT_NAME_OUT NVARCHAR(128) OUTPUT, @INDEX_ID_OUT INT OUTPUT, @rows_out BIGINT OUTPUT'

			EXEC sp_executesql	@SQL, 
								@PARM,
								@OBJECT_NAME_OUT    = @OBJECT_NAME OUTPUT,
								@INDEX_ID_OUT		= @INDEX_ID OUTPUT,
								@rows_out = @rows OUTPUT
		END
		
		--print @SQL
--	-------------------------------------------------------------------------------------

		INSERT INTO @BLOCKED VALUES (
			@BLOCKER_LOGIN			,
			@BLOCKER_PROGRAM		,
			@BLOCKER_HOSTNAME		,
			@BLOCKED_LOGIN			,
			@BLOCKED_PROGRAM		,
			@BLOCKED_HOSTNAME		,
			@BLOCKER_SESSION_ID		,
			@BLOCKER_CONTEXT_INFO   ,
			@BLOCKER_CONTEXT		,
			@BLOCKER_TRAN_ISOLATION	,
			@BLOCKER_STATUS			,
			@BLOCKED_SESSION_ID		,
			@BLOCKED_CONTEXT_INFO   ,
			@BLOCKED_CONTEXT		,
			@BLOCKED_TRAN_ISOLATION	,
			@TRANSACTION_ID			,
			@WAITTIME				,
			@LOCK_MODE				,
			@LOCK_SIZE				,
			@DATABASE_NAME			,
			@OBJECT_NAME			,
			@INDEX_ID				,
			@BLOCKER_SQL			,
			@BLOCKER_PLAN			,
			@BLOCKED_SQL			,
			@BLOCKED_PLAN			)

	FETCH BLOCKED INTO 
		@BLOCKER_SESSION_ID		,
		@BLOCKED_SESSION_ID		,
		@BLOCKED_CONTEXT		, 
		@BLOCKED_TRAN_ISOLATION		,
		@WAITTIME				,
		@LOCK_MODE				,
		@LOCK_SIZE				,
		@DATABASE_NAME			,
		@ASSOCIATEDOBJECTID		,
		@BLOCKED_SQL			,
		@BLOCKED_PLAN			,
		@TRANSACTION_ID	
			
	END

DEALLOCATE BLOCKED;

--print @ASSOCIATEDOBJECTID


SELECT 
    @@SERVERNAME as SERVER_NAME,
	GETDATE() AS BLOCKED_DTTM,
	BLOCKER_LOGIN			,
	BLOCKER_PROGRAM		,
	BLOCKER_HOSTNAME		,
	BLOCKED_LOGIN			,
	BLOCKED_PROGRAM		,
	BLOCKED_HOSTNAME		,
	BLOCKER_SESSION_ID		,
	BLOCKER_CONTEXT_INFO	,
	BLOCKER_CONTEXT	= 
		CASE
				WHEN BLOCKER_CURSORS.properties IS NULL THEN BLOCKER_CONTEXT
				ELSE BLOCKER_CURSORS.properties+'; Dormant for '+ltrim(str(BLOCKER_CURSORS.dormant_duration))+' milleseconds'+BLOCKER_CONTEXT
		END
	
		,
	BLOCKER_TRAN_ISOLATION	,
	BLOCKER_STATUS			,
	BLOCKED_SESSION_ID		,
	BLOCKED_CONTEXT_INFO	,
	BLOCKED_CONTEXT			= 
	
		CASE
				WHEN BLOCKED_CURSORS.properties IS NULL THEN BLOCKED_CONTEXT
				ELSE BLOCKED_CURSORS.properties+'; Dormant for '+ltrim(str(BLOCKED_CURSORS.dormant_duration))+' milleseconds'+BLOCKED_CONTEXT
		END	
		,
	BLOCKED_TRAN_ISOLATION	,
	TRANSACTION_ID			,
	WAIT_TIME				,
	LOCK_MODE				,
	LOCK_SIZE				,
	DATABASE_NAME			,
	ALLOW_SNAPSHOT_ISOLATION = snapshot_isolation_state_desc,
	READ_COMMITTED_SNAPSHOT = 
		CASE is_read_committed_snapshot_on
			WHEN 0 THEN 'OFF'
			WHEN 1 THEN 'ON'
		END,
	OBJECT_NAME				,
	INDEX_ID				,
	BLOCKER_SQL =	
		CASE
				WHEN BLOCKER_SQL LIKE 'FETCH API_CURSOR%' THEN isnull( BLOCKER_CURSORSQL.text, BLOCKER_SQL)
				WHEN BLOCKER_SQL IS NULL THEN BLOCKER_CURSORSQL.text
				ELSE BLOCKER_SQL
		END
			,
	BLOCKER_PLAN = 
		CASE
				WHEN BLOCKER_SQL LIKE 'FETCH API_CURSOR%' THEN isnull (BLOCKER_CURSORPLAN.query_plan, BLOCKER_PLAN)
				WHEN BLOCKER_SQL IS NULL THEN BLOCKER_CURSORPLAN.query_plan
				ELSE BLOCKER_PLAN	
			END,
	BLOCKED_SQL = 
		CASE
				WHEN BLOCKED_SQL LIKE 'FETCH API_CURSOR%' THEN isnull('Cursor: '+BLOCKED_CURSORSQL.text, BLOCKED_SQL)
				ELSE	BLOCKED_SQL
		END,
	BLOCKED_PLAN = 
	   CASE
				WHEN BLOCKED_SQL LIKE 'FETCH API_CURSOR%' THEN isnull(BLOCKED_CURSORPLAN.query_plan, BLOCKED_PLAN)
				ELSE BLOCKED_PLAN	
	   END
FROM	@BLOCKED
JOIN	sys.databases ON name = DATABASE_NAME COLLATE database_default
--	-------------------------------------------------------------------------------------
--	Special Handling for Cursors
--	If the blocking process is a cursor, get SQL text via  sys.dm_exec_cursors.sql_handle
--	and the query plan via sys.dm_exec_query_stats.plan_handle
--	-------------------------------------------------------------------------------------

OUTER APPLY		sys.dm_exec_cursors(BLOCKER_SESSION_ID) AS BLOCKER_CURSORS 

OUTER APPLY		sys.dm_exec_sql_text(BLOCKER_CURSORS.sql_handle) AS BLOCKER_CURSORSQL
LEFT JOIN		sys.dm_exec_query_stats AS BLOCKER_CURSORSTATS ON BLOCKER_CURSORSTATS.sql_handle = BLOCKER_CURSORS.sql_handle
OUTER APPLY		sys.dm_exec_query_plan(BLOCKER_CURSORSTATS.plan_handle) AS BLOCKER_CURSORPLAN

--	-------------------------------------------------------------------------------------
--	Special Handling for Cursors
--	If the blocked process is a cursor, get SQL text via  sys.dm_exec_cursors.sql_handle
--	and the query plan via sys.dm_exec_query_stats.plan_handle
--	-------------------------------------------------------------------------------------

OUTER APPLY		sys.dm_exec_cursors(BLOCKED_SESSION_ID) AS BLOCKED_CURSORS

OUTER APPLY		sys.dm_exec_sql_text(BLOCKED_CURSORS.sql_handle) AS BLOCKED_CURSORSQL
LEFT JOIN		sys.dm_exec_query_stats AS BLOCKED_CURSORSTATS ON BLOCKED_CURSORSTATS.sql_handle = BLOCKED_CURSORS.sql_handle
OUTER APPLY		sys.dm_exec_query_plan(BLOCKED_CURSORSTATS.plan_handle) AS BLOCKED_CURSORPLAN

--WHERE BLOCKER_CURSORS.is_open = 1
--AND		BLOCKED_CURSORS.is_open = 1
ORDER BY WAIT_TIME DESC
GO
PRINT N'Altering [dbo].[SP_PROCESS_STATS]...';


GO
ALTER PROCEDURE [dbo].[SP_PROCESS_STATS]
		@SERVER_NAME	NVARCHAR(128) = NULL,
		@DATABASE_NAME	NVARCHAR(128) = NULL ,
		@DYNAMICS_PRODUCT NVARCHAR(3)  = NULL,
		@TASK_TYPE		VARCHAR(50) = 'PROCESS',
		@AZURE_DB		BIT = 0,
		@TOP_ROWS		INT = 0,
		@TOP_COLUMN		NVARCHAR(128) = 'total_elapsed_time',
		@RUN_NAME		NVARCHAR(128) = NULL,
		@INDEX_PHYSICAL_STATS 	NCHAR(1)= 'N',
		@DEBUG			NVARCHAR(1)= 'N'

AS


SET NOCOUNT ON
SET DATEFORMAT MDY

DECLARE @STATS_DATE		DATETIME, 
		@STATS_DATE_HOLD DATETIME,
		@C_SCHED_UNITS CHAR(2),
		@SQL_VERSION	NVARCHAR(1000), 
		@DYNAMICS_VERSION NVARCHAR(MAX),
		@DATABASE_ID	INT,
		@RETURN_CODE	INT,
		@SQL			NVARCHAR(MAX),
		@RUN_DESCRIPTION NVARCHAR(1000),
		@SQL_TOP_CLAUSE	NVARCHAR(128),
		@SQL_ORDERBY_CLAUSE	NVARCHAR(128),
		@PARM			NVARCHAR(500),
		@SQL_SERVER_STARTTIME DATETIME,
		@RC INT,
		@TASK_PROCEDURE NVARCHAR(128),
		@TASK_PARAMETERS NVARCHAR(1024),
		@TASK_DESCRIPTION NVARCHAR(256),
		@LAST_SERVER_NAME NVARCHAR(128) = 'ZZZ',  --REH This is used to trigger inserting a new STATS_COLLECTION_SUMMARY record
		@LAST_DATABASE_NAME NVARCHAR(128) = 'ZZZ',
		@LAST_STATS_DATE DATETIME,
		@REMOTE_SERVER NVARCHAR(1) = 'N',
		@TASK_STARTTIME DATETIME,
		@TASK_ENDTIME DATETIME,
		@TASK_TIME BIGINT,
		@SQL_STARTTIME DATETIME,
		@SQL_BUILD NVARCHAR(20),
		@SQL2 NVARCHAR(MAX),
		@MANUAL_CAPTURE NVARCHAR(1) = 'N',
		@SQL_TZ_OFFSET INT,
		@DPA_TZ_OFFSET INT 

		
		
DECLARE
	@C_SERVER_NAME NVARCHAR(128),
	@C_DATABASE_NAME NVARCHAR(128),
	@C_TASK_ID INT,
	@C_TASK_PROCEDURE NVARCHAR(128),
	@C_TASK_PARAMS NVARCHAR(1024),
	@C_TASK_DESC NVARCHAR(256),
	@C_SERVER_LEVEL_TASK BIT,
	@C_AZURE_DB  BIT,
	@C_LAST_RUN DATETIME
	
		
--REH Time zone off set for the DynamicsPerf database at time of collection
		SET @DPA_TZ_OFFSET = DATEDIFF(MI,GETUTCDATE(),GETDATE())

	IF @DATABASE_NAME IS NOT NULL SET @MANUAL_CAPTURE = 'Y'

	SET @STATS_DATE = DATEADD(MI, DATEDIFF(MI, 0, getdate()), 0)
--REH  Verify database exists if being manually passed, skip check if Azure DB, no access to sys.databases catalogue

IF ( @AZURE_DB = 0 and ( @SERVER_NAME IS NOT NULL
      OR @DATABASE_NAME IS NOT NULL ))
     BEGIN

	 
	          SET @REMOTE_SERVER = CASE ISNULL(@SERVER_NAME, @@SERVERNAME)
                                WHEN @@SERVERNAME THEN 'N'
                                ELSE 'Y'
                              END


         IF EXISTS (SELECT *
                    FROM   sys.synonyms
                    WHERE  name = 'DYN_PS_QUERY_SYSDATABASES')
           EXEC ('DROP SYNONYM [dbo].DYN_PS_QUERY_SYSDATABASES')

         IF @REMOTE_SERVER = 'Y'
              BEGIN
                  --REH  You CANNOT use synonms for queries that pull XML or use FUNCTIONS
                  SET @SQL = '
				CREATE SYNONYM DYN_PS_QUERY_SYSDATABASES
				FOR [' + @SERVER_NAME
                             + '].master.sys.databases'
              END
         ELSE
           SET @SQL = '
				CREATE SYNONYM DYN_PS_QUERY_SYSDATABASES
				FOR master.sys.databases'

         IF @DEBUG = 'Y'
              BEGIN
                  PRINT '@SQL= ' + @SQL
              END

         EXEC (@SQL) -- SELECT * FROM DYN_PS_QUERY_SYSDATABASES

         IF (SELECT COUNT(*)
             FROM   DynamicsPerf.dbo.DYN_PS_QUERY_SYSDATABASES
             WHERE  name = @DATABASE_NAME) < 1
              BEGIN
                  PRINT 'DATABASE ' + ISNULL(@DATABASE_NAME, 'NULL')
                        + ' does not exist on server '
                        + ISNULL(@SERVER_NAME, 'NULL')

                  RETURN( 0 );
              END

         --REH Make sure there is a record in DATABASES_2_COLLECT or insert if new combination
         IF (SELECT COUNT(*)
             FROM   DATABASES_2_COLLECT
             WHERE  LINKED_SERVER = ISNULL(@SERVER_NAME, @@SERVERNAME)
                    AND DATABASE_NAME = @DATABASE_NAME) < 1
              BEGIN
                  INSERT DATABASES_2_COLLECT
                  VALUES(ISNULL(@SERVER_NAME,@@SERVERNAME),
                         @DATABASE_NAME,
                         ISNULL(@DYNAMICS_PRODUCT, 'ALL'),
                         0,
                         2,
                         24,
						 60,
						 2,
						 90,
						 7,
						 -1,
						 0,
						 100,
						 100,
						 100,
						 100,
						 60)
              END
     END 


	          SET @REMOTE_SERVER = CASE ISNULL(@SERVER_NAME, @@SERVERNAME)
                                WHEN @@SERVERNAME THEN 'N'
                                ELSE 'Y'
                              END



---------------------------------------------------------------------------------------------
--
--  Insert Capture_log entry with paramater values used for the run
--
----------------------------------------------------------------------------------------------

INSERT CAPTURE_LOG  SELECT @TASK_TYPE, @STATS_DATE, 'SP_PROCESS_STATS PARMS PASSED @SERVER_NAME = ' + ISNULL(@SERVER_NAME,'NOT PASSED') + ' @DATABASE_NAME = ' + ISNULL(@DATABASE_NAME,'NOT PASSED') +  ' @DEBUG = ' + @DEBUG + '  ' + CHAR(10) + CHAR(13)



SET @RETURN_CODE = 0

DELETE FROM  COLLECTIONDATABASES WHERE TASK_TYPE = @TASK_TYPE  --REH Default is 'COLLECT' for this sproc.  CAN'T TRUNCATE MULTIPLE SPROCS USING THIS TABLE




IF @DATABASE_NAME IS NULL  --REH AKA, not a manual capture
  BEGIN
      INSERT COLLECTIONDATABASES
      SELECT ISNULL(LINKED_SERVER, @@SERVERNAME),
             [DATABASE_NAME],
             [DYNAMICS_PRODUCT],
             [AZURE_DB],
             [ENABLED],
			 @TASK_TYPE
      FROM   DATABASES_2_COLLECT
      WHERE  ENABLED = 1 -- db must be enabled for autostats collection to work with it
  END
ELSE
  BEGIN   --REH  Insert DBname of the manual capture
      INSERT COLLECTIONDATABASES
      VALUES(ISNULL(@SERVER_NAME, @@SERVERNAME),
             @DATABASE_NAME,
             @DYNAMICS_PRODUCT,
             @AZURE_DB,
             1,
			 @TASK_TYPE)
  END 


--REH Insert any missing task history records in case it's a new database being collected, so we don't fail to capture against the db because of no records
-- yes, this is a cartesian join between these 2 tables

INSERT DYNPERF_TASK_HISTORY
SELECT CD.LINKED_SERVER,
       CD.DATABASE_NAME,
       DTS.TASK_ID,
       NULL,
       NULL,
       NULL,
       '1/1/1900',
       0
FROM   DYNPERF_TASK_SCHEDULER DTS
       CROSS APPLY COLLECTIONDATABASES CD
WHERE  CD.TASK_TYPE = @TASK_TYPE	--REH default is 'PROCESS' in parm definition of this sproc
       AND NOT EXISTS (SELECT 'X'
                       FROM   DYNPERF_TASK_HISTORY DTH
                       WHERE  DTS.TASK_ID = DTH.TASK_ID
                              AND CD.LINKED_SERVER = DTH.LINKEDSERVER_NAME
                              AND CD.DATABASE_NAME = DTH.DATABASE_NAME)
       --REH IF DB is Azure then task must support Azure, otherwise all tasks for Non-Azure dbs
       AND ( ( DTS.AZURE_DB_SUPPORTED = 1
               AND CD.AZURE_DB = 1 )
              OR CD.AZURE_DB = 0 )
       AND DTS.TASK_TYPE = @TASK_TYPE
       AND DTS.SERVER_LEVEL_TASK = 0 --REH Ok, to put 1 record per database in for DB type tasks


	   
--REH Need to insert 1 bogus record for each server level task, or the join on the cursor will fail

INSERT COLLECTIONDATABASES 
 SELECT	DISTINCT [LINKED_SERVER],
             'N/A',
            'ALL',
             [AZURE_DB],
             [ENABLED],
			 [TASK_TYPE]
FROM COLLECTIONDATABASES CD
WHERE DATABASE_NAME <> 'N/A'
AND TASK_TYPE = @TASK_TYPE
AND NOT EXISTS (SELECT 'X' FROM COLLECTIONDATABASES CD2 WHERE CD2.LINKED_SERVER = CD.LINKED_SERVER AND CD2.DATABASE_NAME = 'N/A')



--REH now lets insert server level tasks with a blank DB name so we only do them once per server
INSERT DYNPERF_TASK_HISTORY
SELECT CD.LINKED_SERVER,
       'N/A',
       DTS.TASK_ID,
       NULL,
       NULL,
       NULL,
       '1/1/1900',
       0
FROM   DYNPERF_TASK_SCHEDULER DTS
       CROSS APPLY COLLECTIONDATABASES CD
WHERE  CD.TASK_TYPE = @TASK_TYPE  --REH default is 'COLLECT' in parm definition of this sproc
		AND CD.DATABASE_NAME <> 'N/A'
       AND NOT EXISTS (SELECT 'X'
                   FROM   DYNPERF_TASK_HISTORY DTH
                   WHERE  DTS.TASK_ID = DTH.TASK_ID
                          AND CD.LINKED_SERVER = DTH.LINKEDSERVER_NAME
                          AND DTH.DATABASE_NAME = 'N/A') --REH making the db name = 'N/A' for server level tasks
       --REH IF DB is Azure then task must support Azure, otherwise all tasks for Non-Azure dbs
       AND ( ( DTS.AZURE_DB_SUPPORTED = 1
               AND CD.AZURE_DB = 1 )
              OR CD.AZURE_DB = 0 )
       AND DTS.TASK_TYPE = @TASK_TYPE
       AND DTS.SERVER_LEVEL_TASK = 1 





	IF @DEBUG = 'Y'
	BEGIN
		PRINT 'MANUAL_CAPTURE = ' + @MANUAL_CAPTURE
	END

	--REH Create here and truncate table in each loop
	 --  CREATE TABLE #SQL_INFO
  --   (
  --      SQL_STARTTIME DATETIME,
  --      SQL_BUILD NVARCHAR(20),
		--TZ_OFFSET INT
  --   )
   

/********************************************************************************
Rod Hansen

Added a trigger to DATABASES_2_COLLECT so that we always have a 
DYNPERF_TASK_HISTORY record for this code 

********************************************************************************/

DECLARE TASK_CURSOR CURSOR  LOCAL
FOR
SELECT DISTINCT DTS.TASK_ID,
       CD.LINKED_SERVER,
       CD.DATABASE_NAME,
       DTS.TASK_PROCEDURE,
       DTS.TASK_PARAMETERS,
       DTS.TASK_DESCRIPTION,
       DTS.SERVER_LEVEL_TASK,
       CD.AZURE_DB,
       ISNULL(DTH.LAST_RUN, '1/1/1900'),
	   COALESCE(DTH.SCHEDULE_UNITS, DTS.SCHEDULE_UNITS)  -- Need this to do calculations after task is run

FROM   DynamicsPerf..[DYNPERF_TASK_SCHEDULER] DTS
       LEFT OUTER JOIN DynamicsPerf..[DYNPERF_TASK_HISTORY] DTH
                    ON DTH.TASK_ID = DTS.TASK_ID
       INNER JOIN DynamicsPerf..COLLECTIONDATABASES CD
               ON CD.DATABASE_NAME = DTH.DATABASE_NAME
                  AND CD.LINKED_SERVER = DTH.LINKEDSERVER_NAME
WHERE
  --REH Task is enabled
  DTS.ENABLED = 1
  AND
  --REH It's the correct task type C = COLLECTOR, P = PROCESS, M = MONITOR, ETC
  DTS.TASK_TYPE = @TASK_TYPE
  AND
  --REH database is enabled
  CD.ENABLED = 1
  AND
  --REH Azure_db, if Azure db, then task must support it
  ( CD.AZURE_DB = DTS.AZURE_DB_SUPPORTED
     OR CD.AZURE_DB = 0 )
  --REH Either its an Azure Task, all Azure tasks will run locally, so if task supports AZ and we pass 0, run it anyways
  AND ( DTS.AZURE_DB_SUPPORTED = @AZURE_DB
         OR ( DTS.AZURE_DB_SUPPORTED = 1
              AND @AZURE_DB = 0 ) )
  AND
  --REH it's either All products or matches the Dynamics Product
  ( DTS.DYNAMICS_PRODUCT = 'ALL'
     OR DTS.DYNAMICS_PRODUCT = CD.DYNAMICS_PRODUCT )
  AND
  --REH Scheduling options now
(
  --REH In the case of minutes or hous, we ignore schedule time and just figure out if it's time to run again
  ( @MANUAL_CAPTURE = 'Y'
     OR ( @MANUAL_CAPTURE = 'N'
          AND ( CASE COALESCE(DTH.SCHEDULE_UNITS, DTS.SCHEDULE_UNITS)
                  WHEN 'MI' THEN DATEADD(MINUTE, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                END ) <= GETDATE()
           OR ( ( CASE COALESCE(DTH.SCHEDULE_UNITS, DTS.SCHEDULE_UNITS)
                    WHEN 'HH' THEN DATEADD(HOUR, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                  END ) <= GETDATE()
                --REH and it is on the hour
                AND ( ABS(DATEDIFF(MI, DATEADD(Hour, DATEDIFF(Hour, 0, GETDATE()), 0), GETDATE())) <= 1 ) )
           OR ( ( CASE COALESCE(DTH.SCHEDULE_UNITS, DTS.SCHEDULE_UNITS)
                    WHEN 'DD' THEN DATEADD(DAY, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                    WHEN 'WK' THEN DATEADD(WEEK, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                    WHEN 'MM' THEN DATEADD(WEEK, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                    WHEN 'QQ' THEN DATEADD(WEEK, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                    WHEN 'YY' THEN DATEADD(WEEK, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                  END ) <= GETDATE()
                AND ( --REH TIME IS NULL SO IGNORE IT
                    COALESCE(DTH.SCHEDULE_TIME, DTS.SCHEDULE_TIME) IS NULL
                     OR --REH Current time = Scheduled time 
                    ( SUBSTRING((SELECT REPLACE(CONVERT(VARCHAR(10), GETDATE(), 108), ':', '')), 1, 4) = (SELECT REPLICATE('0', 4 - LEN( COALESCE(DTH.SCHEDULE_TIME, DTS.SCHEDULE_TIME)))
                                                                                                                 + CAST( COALESCE(DTH.SCHEDULE_TIME, DTS.SCHEDULE_TIME) AS VARCHAR(4))) ) ) )
         --REH and last_run < current time
         )--AND CONVERT(VARCHAR(10), LAST_RUN, 108) <= CONVERT(VARCHAR(10), Getdate(), 108) ) 
   )
)
ORDER  BY CD.LINKED_SERVER,
          CD.DATABASE_NAME,
          DTS.TASK_ID 



/* Open the cursor */
/*if the cursor isn't open you will get an error when you fetch the record*/
OPEN TASK_CURSOR 

/* Get the first record */
/* you can FETCH NEXT, FIRST, LAST, PREVIOUS */
FETCH NEXT FROM TASK_CURSOR INTO @C_TASK_ID, @C_SERVER_NAME, @C_DATABASE_NAME, @C_TASK_PROCEDURE, @C_TASK_PARAMS, @C_TASK_DESC, @C_SERVER_LEVEL_TASK,@C_AZURE_DB, @C_LAST_RUN, @C_SCHED_UNITS


/* Verify that we got a record*/
/* status 0 means we got a good record*/

WHILE @@fetch_status = 0  /* no errors */
BEGIN /* Top of Loop */

	SET @REMOTE_SERVER = CASE ISNULL(@C_SERVER_NAME, @@SERVERNAME)
                    WHEN @@SERVERNAME THEN 'N'
                    ELSE 'Y'
                    END

--Insert new STATS_COLLECTION_SUMMARY RECORD, we want 1 RUN_NAME per server not per database
IF @C_SERVER_NAME <> @LAST_SERVER_NAME OR @C_DATABASE_NAME <> @LAST_DATABASE_NAME
BEGIN
    SET @RUN_NAME = ISNULL(@C_SERVER_NAME, @@SERVERNAME)+ ' '
                    + CAST(@STATS_DATE AS VARCHAR(30))


TRUNCATE TABLE WRK_PS_SQL_INFO   

 DELETE FROM COLLECTIONDATABASES WHERE LINKED_SERVER = @LAST_SERVER_NAME AND DATABASE_NAME = @LAST_DATABASE_NAME AND TASK_TYPE = @TASK_TYPE  --REH CLEANUP IN CASE SOMEBODY ELSE RUNS MANUAL CAPTURE
 
SELECT @SQL = 'SELECT create_date AS SQL_STARTTIME,
       CAST(Serverproperty(''ProductVersion'') AS NVARCHAR(20))    AS SQL_BUILD,
	   DATEDIFF(MI,GETUTCDATE(),GETDATE()) AS TZ_OFFSET
		FROM sys.databases WHERE name = ''TempDB'''

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END


   SET NOCOUNT ON
 
IF @REMOTE_SERVER = 'N'
BEGIN
		   INSERT WRK_PS_SQL_INFO
		EXEC( @SQL)
END


 IF @REMOTE_SERVER = 'Y'
 BEGIN
			IF @C_AZURE_DB = 0
			BEGIN
				SET @SQL2 = ' 
				SET QUOTED_IDENTIFIER OFF
					SELECT  * FROM OPENQUERY(['+@C_SERVER_NAME+ '],"
				SELECT create_date AS SQL_STARTTIME,
				CAST(Serverproperty(''ProductVersion'') AS NVARCHAR(20))  AS SQL_BUILD,
				DATEDIFF(MI,GETUTCDATE(),GETDATE()) AS TZ_OFFSET
				FROM sys.databases WHERE name = ''TempDB''"	)'
			END
			IF @C_AZURE_DB = 1
			BEGIN
				SET @SQL2 = ' 
				SET QUOTED_IDENTIFIER OFF
					SELECT  * FROM OPENQUERY(['+@C_SERVER_NAME+ '],"
				SELECT DATEADD(ms,�AVG(-wait_time_ms), GETDATE())� AS SQL_STARTTIME,
				CAST(Serverproperty(''ProductVersion'') AS NVARCHAR(20))  AS SQL_BUILD,
				DATEDIFF(MI,GETUTCDATE(),GETDATE()) AS TZ_OFFSET
				FROM�sys.dm_os_wait_stats w� WHERE�wait_type�
IN�(''DIRTY_PAGE_POLL'',''HADR_FILESTREAM_IOMGR_IOCOMPLETION'',''LAZYWRITER_SLEEP'',''LOGMGR_QUEUE'',''REQUEST_FOR_DEADLOCK_SEARCH'',''XE_DISPATCHER_WAIT'',''XE_TIMER_EVENT'') "	)'
			END


				IF @DEBUG = 'Y'
                  BEGIN
                      PRINT '@SQL= ' + @SQL2
                  END 
                
			INSERT WRK_PS_SQL_INFO
				EXEC (@SQL2) 
 
 END
 
 SELECT @SQL_STARTTIME = SQL_STARTTIME, @SQL_BUILD = SQL_BUILD, @SQL_TZ_OFFSET = TZ_OFFSET FROM WRK_PS_SQL_INFO
 TRUNCATE TABLE WRK_PS_SQL_INFO  -- REH cleanout for next pass


  --REH NOT Collecting so don't need this code in this sproc


		--INSERT INTO [DynamicsPerf].[dbo].[STATS_COLLECTION_SUMMARY]
		--			([SERVER_NAME],
		--			 [STATS_TIME],
		--			 [RUN_NAME],
		--			 [DATABASE_NAME],
		--			 [SQL_VERSION],
		--			 [DYNAMICS_VERSION],
		--			 [RUN_DESCRIPTION],
		--			 [SQL_SERVER_STARTTIME],
		--			 [SQL_SERVER_TZ_OFFSET] ,
		--			 [DPA_TZ_OFFSET])
		--VALUES      (@C_SERVER_NAME,
		--			 @STATS_DATE,
		--			 @RUN_NAME,
		--			 @C_DATABASE_NAME,
		--			 @SQL_BUILD,--<SQL_VERSION>
		--			 '',--<DYNAMICS_VERSION>
		--			 '',--<RUN_DESCRIPTION>
		--			 @SQL_STARTTIME, -- <SQL_SERVER_STARTTIME>
		--			 @SQL_TZ_OFFSET,  -- Time Zone offset in minutes of database collected
		--			 @DPA_TZ_OFFSET  -- Time Zone of the DynamicsPerf database
		--			) 
				
END 

SET @LAST_SERVER_NAME = @C_SERVER_NAME
SET @LAST_DATABASE_NAME = @C_DATABASE_NAME


SET @REMOTE_SERVER = CASE @C_SERVER_NAME
                       WHEN @@SERVERNAME THEN 'N'
                       ELSE 'Y'
                     END 



--Create synonyms for the sproc

--IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = 'DYN_PS_CAPTURE_SPROC')
--DROP SYNONYM [dbo].[DYN_PS_CAPTURE_SPROC]
--SET @SQL = '
--CREATE SYNONYM DYN_PS_CAPTURE_SPROC
--FOR [DynamicsPerf].dbo.[' + @C_TASK_PROCEDURE + ']'

--IF @DEBUG = 'Y' 
--BEGIN
--PRINT '@SQL= ' + @SQL
--END

--EXEC(@SQL) 

IF @DEBUG = 'Y' 
BEGIN
PRINT 'TASK ID = ' + CAST(@C_TASK_ID AS VARCHAR(10))
PRINT 'SERVER NAME = ' + @C_SERVER_NAME 
PRINT 'DATABASE NAME = ' + @C_DATABASE_NAME
PRINT 'TASK PARMS = ' + ISNULL(@C_TASK_PARAMS, '')
PRINT 'TASK DESC = ' + ISNULL(@C_TASK_DESC,'')
PRINT 'LAST RUN = ' + ISNULL(CAST(@C_LAST_RUN AS VARCHAR(30)),'')
PRINT 'RUN NAME = ' + ISNULL(@RUN_NAME,'')
PRINT 'STATS DATE = ' + CAST(@STATS_DATE AS VARCHAR(30))
PRINT 'REMNOTE SERVER FLAG = ' + ISNULL(@REMOTE_SERVER,'')
PRINT 'AZURE DB = ' + CAST(@C_AZURE_DB AS CHAR(1))


END
			
	

BEGIN TRY
PRINT 'STARTING ' + ISNULL(@C_TASK_DESC, '') + CONVERT(VARCHAR, GETDATE(), 109)
PRINT ''


SET @TASK_STARTTIME = GETDATE()
SET @C_TASK_PARAMS = ISNULL(@C_TASK_PARAMS,'')


IF @DEBUG = 'Y'
BEGIN

	PRINT 'SERVER TIME ZONE OFFSET = ' + CAST(@DPA_TZ_OFFSET AS VARCHAR(10))
	PRINT 'AT LAST RUN  = ' + CAST(@C_LAST_RUN AS VARCHAR(30))

END

--REH Adjust the last_run time to UTC Time, the called sproc's will adjust it to local time unless we've never collected
IF @C_LAST_RUN > '1/1/1901'
BEGIN
SET @C_LAST_RUN = DATEADD(MI,@DPA_TZ_OFFSET *-1 ,@C_LAST_RUN)
END



IF @DEBUG = 'Y'
BEGIN
	PRINT 'AT LAST RUN TIME BEING PASSED TO SPROC ' + CAST(@C_LAST_RUN AS VARCHAR(30))
END

SELECT @SQL = 'EXEC ' + @C_TASK_PROCEDURE + '  @TASK_ID=' + CAST(@C_TASK_ID AS NVARCHAR(10)) + 
' ,@SERVER_NAME = ' + '''' +  @C_SERVER_NAME + '''' +
' ,@DATABASE_NAME = ' + '''' +  @C_DATABASE_NAME + '''' +
' ,@TASK_PARAMS = ' +  '''' +  @C_TASK_PARAMS + '''' +
' ,@TASK_DESC = ' + '''' +  @C_TASK_DESC + '''' +
' ,@LAST_RUN = ' + '''' + CONVERT(VARCHAR, @C_LAST_RUN, 109) + '''' +
' ,@RUN_NAME = ' + '''' +  @RUN_NAME + '''' +
' ,@STATS_DATE = ' + '''' + CONVERT(VARCHAR, @STATS_DATE, 109) + '''' +
' ,@REMOTE_SERVER = ' + '''' +  @REMOTE_SERVER + '''' +
' ,@AZURE_DB = ' + CAST(@C_AZURE_DB AS NVARCHAR(10)) + 
' ,@SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET AS NVARCHAR(10)) + 
' ,@DPA_TZ_OFFSET = ' + CAST(@DPA_TZ_OFFSET AS NVARCHAR(10)) + 


' ,@DEBUG = '  + '''' +  @DEBUG + ''''


UPDATE CAPTURE_LOG
SET    TEXT = TEXT  + CHAR(13) + CHAR(10) + '***** ' + @C_TASK_PROCEDURE
			+ CHAR(13) + CHAR(10)
WHERE  STATS_TIME = @STATS_DATE AND TASK_TYPE = @TASK_TYPE



EXECUTE @RC = sp_executesql @SQL

   					  
SET @TASK_ENDTIME = GETDATE()

SET @TASK_TIME = DATEDIFF(ss,@TASK_STARTTIME, @TASK_ENDTIME)



 /*************** RETRY LOGIC ************************/ 
 IF @RC = 1
   AND @TASK_TIME < 10 -- IT FAILED AND WAS LESS THEN 10 SECONDS
  BEGIN
      WAITFOR DELAY '00:00:02' -- REH Wait 2 seconds and try again if sproc trapped the error
      EXECUTE @RC = Sp_executesql
        @SQL

      SET @TASK_ENDTIME = Getdate()
      SET @TASK_TIME = Datediff(ss, @TASK_STARTTIME, @TASK_ENDTIME)
  END 


--REH update last  [DYNPERF_TASK_HISTORY] IF THE TASK WAS SUCCESSFUL


  
 IF @RC = 0
      BEGIN
          PRINT ''
 
          PRINT 'SUCCESSFULLY CAPTURED '
                + ISNULL(@C_TASK_DESC, '') +  ' for SERVER
	'
              + ISNULL(@C_SERVER_NAME, '') + ' on database '
              + ISNULL(@C_DATABASE_NAME, '') + ' in ' + cast(@TASK_TIME AS VARCHAR(20)) + ' SECONDS '
 
  -- REH set last run for daily tasks to previous day so that they will run at midnight from here forward
 SET @STATS_DATE_HOLD = @STATS_DATE
 IF @C_SCHED_UNITS IN ('DD','WK','MM','QQ', 'YY') 

 BEGIN
	--REH Adjust to midnight the previous night if last run was 1/1/1900 so that all daily tasks will then run at midnight

		--REH floor it to today then subtract 2 mins so that its before midnight so that daily tasks will run at 
		-- midnight from now on and not run when we installed DynamicsPerf

	 SET @STATS_DATE_HOLD = DATEADD(MI,-2,dateadd(DAY,datediff(DAY,0,@STATS_DATE),0))


 END



       --REH if a manual capture don't update last run so we don't mess up the scheduling engine
				 IF @MANUAL_CAPTURE = 'N'
				 BEGIN
						  MERGE DynamicsPerf..[DYNPERF_TASK_HISTORY] AS target
						  USING (SELECT @C_SERVER_NAME   AS SERVER_NAME,
										@C_DATABASE_NAME AS DATABASE_NAME,
										@C_TASK_ID       AS TASK_ID,
										@STATS_DATE_HOLD      AS LAST_RUN,
										@TASK_TIME	AS LAST_EXECUTION_TIME_SECS 
												) AS source
						  ON ( source.SERVER_NAME = target.LINKEDSERVER_NAME
							   AND source.DATABASE_NAME = target.DATABASE_NAME
							   AND source.TASK_ID = target.TASK_ID )
						  WHEN MATCHED THEN
							UPDATE SET LAST_RUN = source.LAST_RUN, [LAST_EXECUTION_TIME_SECS] = source.[LAST_EXECUTION_TIME_SECS]
						  WHEN NOT MATCHED THEN
							INSERT ( [LINKEDSERVER_NAME],
									 [DATABASE_NAME],
									 [TASK_ID],
									 [LAST_RUN],
									 [LAST_EXECUTION_TIME_SECS])
							VALUES (source.SERVER_NAME,
									source.DATABASE_NAME,
									source.TASK_ID,
									source.LAST_RUN,
									source.LAST_EXECUTION_TIME_SECS );
				END
      END
 ELSE
	IF @RC = 1  --REH SPROC HANDLED THE ERROR
      BEGIN
          PRINT ''
 
          PRINT 'FAILED !!!!!! ' + ISNULL(@C_TASK_DESC, '')
 
          PRINT ''
      END 
 

 
 

           IF EXISTS (SELECT *
                    FROM   sys.synonyms
                    WHERE  name = 'DYN_PS_QUERY_SYSDATABASES')
           EXEC ('DROP SYNONYM [dbo].DYN_PS_QUERY_SYSDATABASES')

  
END TRY 

BEGIN CATCH


UPDATE CAPTURE_LOG
SET    TEXT = TEXT + ' PROCEDURE FAILED !!! '
              + ISNULL(@C_TASK_DESC, 'TASK') + ' for SERVER
        '
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) + ', '
                          + ' ERROR = ' + CAST(@@ERROR AS VARCHAR(MAX)) 
WHERE  STATS_TIME = @STATS_DATE  AND TASK_TYPE = @TASK_TYPE 


PRINT 'ERROR WHILE COLLECTING ' + ISNULL(@C_TASK_DESC, '') +' !!!!!!!!!!!!!!'


           IF EXISTS (SELECT *
                    FROM   sys.synonyms
                    WHERE  name = 'DYN_PS_QUERY_SYSDATABASES')
           EXEC ('DROP SYNONYM [dbo].DYN_PS_QUERY_SYSDATABASES')


END CATCH



FETCH NEXT FROM TASK_CURSOR INTO @C_TASK_ID, @C_SERVER_NAME, @C_DATABASE_NAME, @C_TASK_PROCEDURE, @C_TASK_PARAMS, @C_TASK_DESC, @C_SERVER_LEVEL_TASK,@C_AZURE_DB, @C_LAST_RUN, @C_SCHED_UNITS


END  /*End of the loop */
CLOSE TASK_CURSOR  /*close the cursor to free memory in SQL*/
DEALLOCATE TASK_CURSOR /*Must deallocate the cursor to destroy it and free SQL resources*/
 
 DELETE FROM COLLECTIONDATABASES WHERE TASK_TYPE = @TASK_TYPE  --REH CLEANUP IN CASE SOMEBODY ELSE RUNS MANUAL CAPTURE
 
			

ENDPROC:
PRINT 'RUN NAME = '+ @RUN_NAME
GO
PRINT N'Altering [dbo].[SP_PROCESS_STATS_LOW_PRIORITY]...';


GO
ALTER PROCEDURE [dbo].[SP_PROCESS_STATS_LOW_PRIORITY]
	@SERVER_NAME	NVARCHAR(128) = NULL,
		@DATABASE_NAME	NVARCHAR(128) = NULL ,
		@DYNAMICS_PRODUCT NVARCHAR(3)  = NULL,
		@TASK_TYPE		VARCHAR(50) = 'PROCESS_LP',
		@AZURE_DB		BIT = 0,
		@TOP_ROWS		INT = 0,
		@TOP_COLUMN		NVARCHAR(128) = 'total_elapsed_time',
		@RUN_NAME		NVARCHAR(128) = NULL,
		@INDEX_PHYSICAL_STATS 	NCHAR(1)= 'N',
		@DEBUG			NVARCHAR(1)= 'N'

AS


SET NOCOUNT ON
SET DATEFORMAT MDY

DECLARE @STATS_DATE		DATETIME,
		@STATS_DATE_HOLD DATETIME,
		@C_SCHED_UNITS CHAR(2), 
		@SQL_VERSION	NVARCHAR(1000), 
		@DYNAMICS_VERSION NVARCHAR(MAX),
		@DATABASE_ID	INT,
		@RETURN_CODE	INT,
		@SQL			NVARCHAR(MAX),
		@RUN_DESCRIPTION NVARCHAR(1000),
		@SQL_TOP_CLAUSE	NVARCHAR(128),
		@SQL_ORDERBY_CLAUSE	NVARCHAR(128),
		@PARM			NVARCHAR(500),
		@SQL_SERVER_STARTTIME DATETIME,
		@RC INT,
		@TASK_PROCEDURE NVARCHAR(128),
		@TASK_PARAMETERS NVARCHAR(1024),
		@TASK_DESCRIPTION NVARCHAR(256),
		@LAST_SERVER_NAME NVARCHAR(128) = 'ZZZ',  --REH This is used to trigger inserting a new STATS_COLLECTION_SUMMARY record
		@LAST_DATABASE_NAME NVARCHAR(128) = 'ZZZ',
		@LAST_STATS_DATE DATETIME,
		@REMOTE_SERVER NVARCHAR(1) = 'N',
		@TASK_STARTTIME DATETIME,
		@TASK_ENDTIME DATETIME,
		@TASK_TIME BIGINT,
		@SQL_STARTTIME DATETIME,
		@SQL_BUILD NVARCHAR(20),
		@SQL2 NVARCHAR(MAX),
		@MANUAL_CAPTURE NVARCHAR(1) = 'N',
		@SQL_TZ_OFFSET INT,
		@DPA_TZ_OFFSET INT 

		
		
DECLARE
	@C_SERVER_NAME NVARCHAR(128),
	@C_DATABASE_NAME NVARCHAR(128),
	@C_TASK_ID INT,
	@C_TASK_PROCEDURE NVARCHAR(128),
	@C_TASK_PARAMS NVARCHAR(1024),
	@C_TASK_DESC NVARCHAR(256),
	@C_SERVER_LEVEL_TASK BIT,
	@C_AZURE_DB  BIT,
	@C_LAST_RUN DATETIME
	
		
--REH Time zone off set for the DynamicsPerf database at time of collection
		SET @DPA_TZ_OFFSET = DATEDIFF(MI,GETUTCDATE(),GETDATE())

	IF @DATABASE_NAME IS NOT NULL SET @MANUAL_CAPTURE = 'Y'

	SET @STATS_DATE = DATEADD(MI, DATEDIFF(MI, 0, getdate()), 0)
--REH  Verify database exists if being manually passed, skip check if Azure DB, no access to sys.databases catalogue

IF ( @AZURE_DB = 0 and ( @SERVER_NAME IS NOT NULL
      OR @DATABASE_NAME IS NOT NULL ))
     BEGIN

	 
	          SET @REMOTE_SERVER = CASE ISNULL(@SERVER_NAME, @@SERVERNAME)
                                WHEN @@SERVERNAME THEN 'N'
                                ELSE 'Y'
                              END


         IF EXISTS (SELECT *
                    FROM   sys.synonyms
                    WHERE  name = 'DYN_PS_LP_QUERY_SYSDATABASES')
           EXEC ('DROP SYNONYM [dbo].DYN_PS_LP_QUERY_SYSDATABASES')

         IF @REMOTE_SERVER = 'Y'
              BEGIN
                  --REH  You CANNOT use synonms for queries that pull XML or use FUNCTIONS
                  SET @SQL = '
				CREATE SYNONYM DYN_PS_LP_QUERY_SYSDATABASES
				FOR [' + @SERVER_NAME
                             + '].master.sys.databases'
              END
         ELSE
           SET @SQL = '
				CREATE SYNONYM DYN_PS_LP_QUERY_SYSDATABASES
				FOR master.sys.databases'

         IF @DEBUG = 'Y'
              BEGIN
                  PRINT '@SQL= ' + @SQL
              END

         EXEC (@SQL) -- SELECT * FROM DYN_PS_LP_QUERY_SYSDATABASES

         IF (SELECT COUNT(*)
             FROM   DynamicsPerf.dbo.DYN_PS_LP_QUERY_SYSDATABASES
             WHERE  name = @DATABASE_NAME) < 1
              BEGIN
                  PRINT 'DATABASE ' + ISNULL(@DATABASE_NAME, 'NULL')
                        + ' does not exist on server '
                        + ISNULL(@SERVER_NAME, 'NULL')

                  RETURN( 0 );
              END

         --REH Make sure there is a record in DATABASES_2_COLLECT or insert if new combination
         IF (SELECT COUNT(*)
             FROM   DATABASES_2_COLLECT
             WHERE  LINKED_SERVER = ISNULL(@SERVER_NAME, @@SERVERNAME)
                    AND DATABASE_NAME = @DATABASE_NAME) < 1
              BEGIN
                  INSERT DATABASES_2_COLLECT
                  VALUES(ISNULL(@SERVER_NAME,@@SERVERNAME),
                         @DATABASE_NAME,
                         ISNULL(@DYNAMICS_PRODUCT, 'ALL'),
                         0,
                         2,
                         24,
						 60,
						 2,
						 90,
						 7,
						 -1,
						 0,
						 100,
						 100,
						 100,
						 100,
						 60)
              END
     END 


	          SET @REMOTE_SERVER = CASE ISNULL(@SERVER_NAME, @@SERVERNAME)
                                WHEN @@SERVERNAME THEN 'N'
                                ELSE 'Y'
                              END



---------------------------------------------------------------------------------------------
--
--  Insert Capture_log entry with paramater values used for the run
--
----------------------------------------------------------------------------------------------

INSERT CAPTURE_LOG  SELECT @TASK_TYPE, @STATS_DATE, 'SP_PROCESS_STATS PARMS PASSED @SERVER_NAME = ' + ISNULL(@SERVER_NAME,'NOT PASSED') + ' @DATABASE_NAME = ' + ISNULL(@DATABASE_NAME,'NOT PASSED') +  ' @DEBUG = ' + @DEBUG + '  ' + CHAR(10) + CHAR(13)



SET @RETURN_CODE = 0

DELETE FROM  COLLECTIONDATABASES WHERE TASK_TYPE = @TASK_TYPE  --REH Default is 'COLLECT' for this sproc.  CAN'T TRUNCATE MULTIPLE SPROCS USING THIS TABLE




IF @DATABASE_NAME IS NULL  --REH AKA, not a manual capture
  BEGIN
      INSERT COLLECTIONDATABASES
      SELECT ISNULL(LINKED_SERVER, @@SERVERNAME),
             [DATABASE_NAME],
             [DYNAMICS_PRODUCT],
             [AZURE_DB],
             [ENABLED],
			 @TASK_TYPE
      FROM   DATABASES_2_COLLECT
      WHERE  ENABLED = 1 -- db must be enabled for autostats collection to work with it
  END
ELSE
  BEGIN   --REH  Insert DBname of the manual capture
      INSERT COLLECTIONDATABASES
      VALUES(ISNULL(@SERVER_NAME, @@SERVERNAME),
             @DATABASE_NAME,
             @DYNAMICS_PRODUCT,
             @AZURE_DB,
             1,
			 @TASK_TYPE)
  END 


--REH Insert any missing task history records in case it's a new database being collected, so we don't fail to capture against the db because of no records
-- yes, this is a cartesian join between these 2 tables

INSERT DYNPERF_TASK_HISTORY
SELECT CD.LINKED_SERVER,
       CD.DATABASE_NAME,
       DTS.TASK_ID,
       NULL,
       NULL,
       NULL,
       '1/1/1900',
       0
FROM   DYNPERF_TASK_SCHEDULER DTS
       CROSS APPLY COLLECTIONDATABASES CD
WHERE  CD.TASK_TYPE = @TASK_TYPE	--REH default is 'PROCESS' in parm definition of this sproc
       AND NOT EXISTS (SELECT 'X'
                       FROM   DYNPERF_TASK_HISTORY DTH
                       WHERE  DTS.TASK_ID = DTH.TASK_ID
                              AND CD.LINKED_SERVER = DTH.LINKEDSERVER_NAME
                              AND CD.DATABASE_NAME = DTH.DATABASE_NAME)
       --REH IF DB is Azure then task must support Azure, otherwise all tasks for Non-Azure dbs
       AND ( ( DTS.AZURE_DB_SUPPORTED = 1
               AND CD.AZURE_DB = 1 )
              OR CD.AZURE_DB = 0 )
       AND DTS.TASK_TYPE = @TASK_TYPE
       AND DTS.SERVER_LEVEL_TASK = 0 --REH Ok, to put 1 record per database in for DB type tasks


	   
--REH Need to insert 1 bogus record for each server level task, or the join on the cursor will fail

INSERT COLLECTIONDATABASES 
 SELECT	DISTINCT [LINKED_SERVER],
             'N/A',
            'ALL',
             [AZURE_DB],
             [ENABLED],
			 [TASK_TYPE]
FROM COLLECTIONDATABASES CD
WHERE DATABASE_NAME <> 'N/A'
AND TASK_TYPE = @TASK_TYPE
AND NOT EXISTS (SELECT 'X' FROM COLLECTIONDATABASES CD2 WHERE CD2.LINKED_SERVER = CD.LINKED_SERVER AND CD2.DATABASE_NAME = 'N/A')



--REH now lets insert server level tasks with a blank DB name so we only do them once per server
INSERT DYNPERF_TASK_HISTORY
SELECT CD.LINKED_SERVER,
       'N/A',
       DTS.TASK_ID,
       NULL,
       NULL,
       NULL,
       '1/1/1900',
       0
FROM   DYNPERF_TASK_SCHEDULER DTS
       CROSS APPLY COLLECTIONDATABASES CD
WHERE  CD.TASK_TYPE = @TASK_TYPE  --REH default is 'COLLECT' in parm definition of this sproc
		AND CD.DATABASE_NAME <> 'N/A'
       AND NOT EXISTS (SELECT 'X'
                   FROM   DYNPERF_TASK_HISTORY DTH
                   WHERE  DTS.TASK_ID = DTH.TASK_ID
                          AND CD.LINKED_SERVER = DTH.LINKEDSERVER_NAME
                          AND DTH.DATABASE_NAME = 'N/A') --REH making the db name = 'N/A' for server level tasks
       --REH IF DB is Azure then task must support Azure, otherwise all tasks for Non-Azure dbs
       AND ( ( DTS.AZURE_DB_SUPPORTED = 1
               AND CD.AZURE_DB = 1 )
              OR CD.AZURE_DB = 0 )
       AND DTS.TASK_TYPE = @TASK_TYPE
       AND DTS.SERVER_LEVEL_TASK = 1 





	IF @DEBUG = 'Y'
	BEGIN
		PRINT 'MANUAL_CAPTURE = ' + @MANUAL_CAPTURE
	END

	--REH Create here and truncate table in each loop
	 --  CREATE TABLE #SQL_INFO
  --   (
  --      SQL_STARTTIME DATETIME,
  --      SQL_BUILD NVARCHAR(20),
		--TZ_OFFSET INT
  --   )
   

/********************************************************************************
Rod Hansen

Added a trigger to DATABASES_2_COLLECT so that we always have a 
DYNPERF_TASK_HISTORY record for this code 

********************************************************************************/

DECLARE TASK_CURSOR CURSOR  LOCAL
FOR
SELECT DISTINCT DTS.TASK_ID,
       CD.LINKED_SERVER,
       CD.DATABASE_NAME,
       DTS.TASK_PROCEDURE,
       DTS.TASK_PARAMETERS,
       DTS.TASK_DESCRIPTION,
       DTS.SERVER_LEVEL_TASK,
       CD.AZURE_DB,
       ISNULL(DTH.LAST_RUN, '1/1/1900'),
	   COALESCE(DTH.SCHEDULE_UNITS, DTS.SCHEDULE_UNITS)  -- Need this to do calculations after task is run

FROM   DynamicsPerf..[DYNPERF_TASK_SCHEDULER] DTS
       LEFT OUTER JOIN DynamicsPerf..[DYNPERF_TASK_HISTORY] DTH
                    ON DTH.TASK_ID = DTS.TASK_ID
       INNER JOIN DynamicsPerf..COLLECTIONDATABASES CD
               ON CD.DATABASE_NAME = DTH.DATABASE_NAME
                  AND CD.LINKED_SERVER = DTH.LINKEDSERVER_NAME
WHERE
  --REH Task is enabled
  DTS.ENABLED = 1
  AND
  --REH It's the correct task type C = COLLECTOR, P = PROCESS, M = MONITOR, ETC
  DTS.TASK_TYPE = @TASK_TYPE
  AND
  --REH database is enabled
  CD.ENABLED = 1
  AND
  --REH Azure_db, if Azure db, then task must support it
  ( CD.AZURE_DB = DTS.AZURE_DB_SUPPORTED
     OR CD.AZURE_DB = 0 )
  --REH Either its an Azure Task, all Azure tasks will run locally, so if task supports AZ and we pass 0, run it anyways
  AND ( DTS.AZURE_DB_SUPPORTED = @AZURE_DB
         OR ( DTS.AZURE_DB_SUPPORTED = 1
              AND @AZURE_DB = 0 ) )
  AND
  --REH it's either All products or matches the Dynamics Product
  ( DTS.DYNAMICS_PRODUCT = 'ALL'
     OR DTS.DYNAMICS_PRODUCT = CD.DYNAMICS_PRODUCT )
  AND
  --REH Scheduling options now
(
  --REH In the case of minutes or hous, we ignore schedule time and just figure out if it's time to run again
  ( @MANUAL_CAPTURE = 'Y'
     OR ( @MANUAL_CAPTURE = 'N'
          AND ( CASE COALESCE(DTH.SCHEDULE_UNITS, DTS.SCHEDULE_UNITS)
                  WHEN 'MI' THEN DATEADD(MINUTE, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                END ) <= GETDATE()
           OR ( ( CASE COALESCE(DTH.SCHEDULE_UNITS, DTS.SCHEDULE_UNITS)
                    WHEN 'HH' THEN DATEADD(HOUR, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                  END ) <= GETDATE()
                --REH and it is on the hour
                AND ( ABS(DATEDIFF(MI, DATEADD(Hour, DATEDIFF(Hour, 0, GETDATE()), 0), GETDATE())) <= 1 ) )
           OR ( ( CASE COALESCE(DTH.SCHEDULE_UNITS, DTS.SCHEDULE_UNITS)
                    WHEN 'DD' THEN DATEADD(DAY, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                    WHEN 'WK' THEN DATEADD(WEEK, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                    WHEN 'MM' THEN DATEADD(WEEK, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                    WHEN 'QQ' THEN DATEADD(WEEK, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                    WHEN 'YY' THEN DATEADD(WEEK, COALESCE(DTH.SCHEDULE_QTY_PER_UNIT, DTS.SCHEDULE_QTY_PER_UNIT), ISNULL(LAST_RUN, '1/1/1900'))
                  END ) <= GETDATE()
                AND ( --REH TIME IS NULL SO IGNORE IT
                    COALESCE(DTH.SCHEDULE_TIME, DTS.SCHEDULE_TIME) IS NULL
                     OR --REH Current time = Scheduled time 
                    ( SUBSTRING((SELECT REPLACE(CONVERT(VARCHAR(10), GETDATE(), 108), ':', '')), 1, 4) = (SELECT REPLICATE('0', 4 - LEN( COALESCE(DTH.SCHEDULE_TIME, DTS.SCHEDULE_TIME)))
                                                                                                                 + CAST( COALESCE(DTH.SCHEDULE_TIME, DTS.SCHEDULE_TIME) AS VARCHAR(4))) ) ) )
         --REH and last_run < current time
         )--AND CONVERT(VARCHAR(10), LAST_RUN, 108) <= CONVERT(VARCHAR(10), Getdate(), 108) ) 
   )
)
ORDER  BY CD.LINKED_SERVER,
          CD.DATABASE_NAME,
          DTS.TASK_ID 



/* Open the cursor */
/*if the cursor isn't open you will get an error when you fetch the record*/
OPEN TASK_CURSOR 

/* Get the first record */
/* you can FETCH NEXT, FIRST, LAST, PREVIOUS */
FETCH NEXT FROM TASK_CURSOR INTO @C_TASK_ID, @C_SERVER_NAME, @C_DATABASE_NAME, @C_TASK_PROCEDURE, @C_TASK_PARAMS, @C_TASK_DESC, @C_SERVER_LEVEL_TASK,@C_AZURE_DB, @C_LAST_RUN, @C_SCHED_UNITS


/* Verify that we got a record*/
/* status 0 means we got a good record*/

WHILE @@fetch_status = 0  /* no errors */
BEGIN /* Top of Loop */

	SET @REMOTE_SERVER = CASE ISNULL(@C_SERVER_NAME, @@SERVERNAME)
                    WHEN @@SERVERNAME THEN 'N'
                    ELSE 'Y'
                    END

--Insert new STATS_COLLECTION_SUMMARY RECORD, we want 1 RUN_NAME per server not per database
IF @C_SERVER_NAME <> @LAST_SERVER_NAME OR @C_DATABASE_NAME <> @LAST_DATABASE_NAME
BEGIN
    SET @RUN_NAME = ISNULL(@C_SERVER_NAME, @@SERVERNAME)+ ' '
                    + CAST(@STATS_DATE AS VARCHAR(30))


TRUNCATE TABLE WRK_LP_SQL_INFO   

 DELETE FROM COLLECTIONDATABASES WHERE LINKED_SERVER = @LAST_SERVER_NAME AND DATABASE_NAME = @LAST_DATABASE_NAME AND TASK_TYPE = @TASK_TYPE  --REH CLEANUP IN CASE SOMEBODY ELSE RUNS MANUAL CAPTURE
 
SELECT @SQL = 'SELECT create_date AS SQL_STARTTIME,
       CAST(Serverproperty(''ProductVersion'') AS NVARCHAR(20))    AS SQL_BUILD,
	   DATEDIFF(MI,GETUTCDATE(),GETDATE()) AS TZ_OFFSET
		FROM sys.databases WHERE name = ''TempDB'''

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END


   SET NOCOUNT ON
 
IF @REMOTE_SERVER = 'N'
BEGIN
		   INSERT WRK_LP_SQL_INFO
		EXEC( @SQL)
END


 IF @REMOTE_SERVER = 'Y'
 BEGIN
			IF @C_AZURE_DB = 0
			BEGIN
				SET @SQL2 = ' 
				SET QUOTED_IDENTIFIER OFF
					SELECT  * FROM OPENQUERY(['+@C_SERVER_NAME+ '],"
				SELECT create_date AS SQL_STARTTIME,
				CAST(Serverproperty(''ProductVersion'') AS NVARCHAR(20))  AS SQL_BUILD,
				DATEDIFF(MI,GETUTCDATE(),GETDATE()) AS TZ_OFFSET
				FROM sys.databases WHERE name = ''TempDB''"	)'
			END
			IF @C_AZURE_DB = 1
			BEGIN
				SET @SQL2 = ' 
				SET QUOTED_IDENTIFIER OFF
					SELECT  * FROM OPENQUERY(['+@C_SERVER_NAME+ '],"
				SELECT DATEADD(ms,�AVG(-wait_time_ms), GETDATE())� AS SQL_STARTTIME,
				CAST(Serverproperty(''ProductVersion'') AS NVARCHAR(20))  AS SQL_BUILD,
				DATEDIFF(MI,GETUTCDATE(),GETDATE()) AS TZ_OFFSET
				FROM�sys.dm_os_wait_stats w� WHERE�wait_type�
IN�(''DIRTY_PAGE_POLL'',''HADR_FILESTREAM_IOMGR_IOCOMPLETION'',''LAZYWRITER_SLEEP'',''LOGMGR_QUEUE'',''REQUEST_FOR_DEADLOCK_SEARCH'',''XE_DISPATCHER_WAIT'',''XE_TIMER_EVENT'') "	)'
			END


				IF @DEBUG = 'Y'
                  BEGIN
                      PRINT '@SQL= ' + @SQL2
                  END 
                
			INSERT WRK_LP_SQL_INFO
				EXEC (@SQL2) 
 
 END
 
 SELECT @SQL_STARTTIME = SQL_STARTTIME, @SQL_BUILD = SQL_BUILD, @SQL_TZ_OFFSET = TZ_OFFSET FROM WRK_LP_SQL_INFO
 TRUNCATE TABLE WRK_LP_SQL_INFO  -- REH cleanout for next pass


  --REH NOT Collecting so don't need this code in this sproc


		--INSERT INTO [DynamicsPerf].[dbo].[STATS_COLLECTION_SUMMARY]
		--			([SERVER_NAME],
		--			 [STATS_TIME],
		--			 [RUN_NAME],
		--			 [DATABASE_NAME],
		--			 [SQL_VERSION],
		--			 [DYNAMICS_VERSION],
		--			 [RUN_DESCRIPTION],
		--			 [SQL_SERVER_STARTTIME],
		--			 [SQL_SERVER_TZ_OFFSET] ,
		--			 [DPA_TZ_OFFSET])
		--VALUES      (@C_SERVER_NAME,
		--			 @STATS_DATE,
		--			 @RUN_NAME,
		--			 @C_DATABASE_NAME,
		--			 @SQL_BUILD,--<SQL_VERSION>
		--			 '',--<DYNAMICS_VERSION>
		--			 '',--<RUN_DESCRIPTION>
		--			 @SQL_STARTTIME, -- <SQL_SERVER_STARTTIME>
		--			 @SQL_TZ_OFFSET,  -- Time Zone offset in minutes of database collected
		--			 @DPA_TZ_OFFSET  -- Time Zone of the DynamicsPerf database
		--			) 
				
END 

SET @LAST_SERVER_NAME = @C_SERVER_NAME
SET @LAST_DATABASE_NAME = @C_DATABASE_NAME


SET @REMOTE_SERVER = CASE @C_SERVER_NAME
                       WHEN @@SERVERNAME THEN 'N'
                       ELSE 'Y'
                     END 



--Create synonyms for the sproc

--IF  EXISTS (SELECT * FROM sys.synonyms WHERE name = 'DYN_PS_LP_CAPTURE_SPROC')
--DROP SYNONYM [dbo].[DYN_PS_LP_CAPTURE_SPROC]
--SET @SQL = '
--CREATE SYNONYM DYN_PS_LP_CAPTURE_SPROC
--FOR [DynamicsPerf].dbo.[' + @C_TASK_PROCEDURE + ']'

--IF @DEBUG = 'Y' 
--BEGIN
--PRINT '@SQL= ' + @SQL
--END

--EXEC(@SQL) 

IF @DEBUG = 'Y' 
BEGIN
PRINT 'TASK ID = ' + CAST(@C_TASK_ID AS VARCHAR(10))
PRINT 'SERVER NAME = ' + @C_SERVER_NAME 
PRINT 'DATABASE NAME = ' + @C_DATABASE_NAME
PRINT 'TASK PARMS = ' + ISNULL(@C_TASK_PARAMS, '')
PRINT 'TASK DESC = ' + ISNULL(@C_TASK_DESC,'')
PRINT 'LAST RUN = ' + ISNULL(CAST(@C_LAST_RUN AS VARCHAR(30)),'')
PRINT 'RUN NAME = ' + ISNULL(@RUN_NAME,'')
PRINT 'STATS DATE = ' + CAST(@STATS_DATE AS VARCHAR(30))
PRINT 'REMNOTE SERVER FLAG = ' + ISNULL(@REMOTE_SERVER,'')
PRINT 'AZURE DB = ' + CAST(@C_AZURE_DB AS CHAR(1))


END
			
	

BEGIN TRY
PRINT 'STARTING ' + ISNULL(@C_TASK_DESC, '') + CONVERT(VARCHAR, GETDATE(), 109)
PRINT ''


SET @TASK_STARTTIME = GETDATE()
SET @C_TASK_PARAMS = ISNULL(@C_TASK_PARAMS,'')


IF @DEBUG = 'Y'
BEGIN

	PRINT 'SERVER TIME ZONE OFFSET = ' + CAST(@DPA_TZ_OFFSET AS VARCHAR(10))
	PRINT 'AT LAST RUN  = ' + CAST(@C_LAST_RUN AS VARCHAR(30))

END

--REH Adjust the last_run time to UTC Time, the called sproc's will adjust it to local time unless we've never collected
IF @C_LAST_RUN > '1/1/1901'
BEGIN
SET @C_LAST_RUN = DATEADD(MI,@DPA_TZ_OFFSET *-1 ,@C_LAST_RUN)
END



IF @DEBUG = 'Y'
BEGIN
	PRINT 'AT LAST RUN TIME BEING PASSED TO SPROC ' + CAST(@C_LAST_RUN AS VARCHAR(30))
END

SELECT @SQL = 'EXEC ' + @C_TASK_PROCEDURE + '  @TASK_ID=' + CAST(@C_TASK_ID AS NVARCHAR(10)) + 
' ,@SERVER_NAME = ' + '''' +  @C_SERVER_NAME + '''' +
' ,@DATABASE_NAME = ' + '''' +  @C_DATABASE_NAME + '''' +
' ,@TASK_PARAMS = ' +  '''' +  @C_TASK_PARAMS + '''' +
' ,@TASK_DESC = ' + '''' +  @C_TASK_DESC + '''' +
' ,@LAST_RUN = ' + '''' + CONVERT(VARCHAR, @C_LAST_RUN, 109) + '''' +
' ,@RUN_NAME = ' + '''' +  @RUN_NAME + '''' +
' ,@STATS_DATE = ' + '''' + CONVERT(VARCHAR, @STATS_DATE, 109) + '''' +
' ,@REMOTE_SERVER = ' + '''' +  @REMOTE_SERVER + '''' +
' ,@AZURE_DB = ' + CAST(@C_AZURE_DB AS NVARCHAR(10)) + 
' ,@SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET AS NVARCHAR(10)) + 
' ,@DPA_TZ_OFFSET = ' + CAST(@DPA_TZ_OFFSET AS NVARCHAR(10)) + 


' ,@DEBUG = '  + '''' +  @DEBUG + ''''


UPDATE CAPTURE_LOG
SET    TEXT = TEXT  + CHAR(13) + CHAR(10) + '***** ' + @C_TASK_PROCEDURE
			+ CHAR(13) + CHAR(10)
WHERE  STATS_TIME = @STATS_DATE AND TASK_TYPE = @TASK_TYPE



EXECUTE @RC = sp_executesql @SQL

   					  
SET @TASK_ENDTIME = GETDATE()

SET @TASK_TIME = DATEDIFF(ss,@TASK_STARTTIME, @TASK_ENDTIME)



 /*************** RETRY LOGIC ************************/ 
 IF @RC = 1
   AND @TASK_TIME < 10 -- IT FAILED AND WAS LESS THEN 10 SECONDS
  BEGIN
      WAITFOR DELAY '00:00:02' -- REH Wait 2 seconds and try again if sproc trapped the error
      EXECUTE @RC = Sp_executesql
        @SQL

      SET @TASK_ENDTIME = Getdate()
      SET @TASK_TIME = Datediff(ss, @TASK_STARTTIME, @TASK_ENDTIME)
  END 


--REH update last  [DYNPERF_TASK_HISTORY] IF THE TASK WAS SUCCESSFUL


  
 IF @RC = 0
      BEGIN
          PRINT ''
 
          PRINT 'SUCCESSFULLY CAPTURED '
                + ISNULL(@C_TASK_DESC, '') +  ' for SERVER
	'
              + ISNULL(@C_SERVER_NAME, '') + ' on database '
              + ISNULL(@C_DATABASE_NAME, '') + ' in ' + cast(@TASK_TIME AS VARCHAR(20)) + ' SECONDS '


  -- REH set last run for daily tasks to previous day so that they will run at midnight from here forward
 SET @STATS_DATE_HOLD = @STATS_DATE
 IF @C_SCHED_UNITS IN ('DD','WK','MM','QQ', 'YY') 

 BEGIN
	--REH Adjust to midnight the previous night if last run was 1/1/1900 so that all daily tasks will then run at midnight

		--REH floor it to today then subtract 2 mins so that its before midnight so that daily tasks will run at 
		-- midnight from now on and not run when we installed DynamicsPerf

	 SET @STATS_DATE_HOLD = DATEADD(MI,-2,dateadd(DAY,datediff(DAY,0,@STATS_DATE),0))


 END


       --REH if a manual capture don't update last run so we don't mess up the scheduling engine
				 IF @MANUAL_CAPTURE = 'N'
				 BEGIN
						  MERGE DynamicsPerf..[DYNPERF_TASK_HISTORY] AS target
						  USING (SELECT @C_SERVER_NAME   AS SERVER_NAME,
										@C_DATABASE_NAME AS DATABASE_NAME,
										@C_TASK_ID       AS TASK_ID,
										@STATS_DATE_HOLD      AS LAST_RUN,
										@TASK_TIME	AS LAST_EXECUTION_TIME_SECS 
												) AS source
						  ON ( source.SERVER_NAME = target.LINKEDSERVER_NAME
							   AND source.DATABASE_NAME = target.DATABASE_NAME
							   AND source.TASK_ID = target.TASK_ID )
						  WHEN MATCHED THEN
							UPDATE SET LAST_RUN = source.LAST_RUN, [LAST_EXECUTION_TIME_SECS] = source.[LAST_EXECUTION_TIME_SECS]
						  WHEN NOT MATCHED THEN
							INSERT ( [LINKEDSERVER_NAME],
									 [DATABASE_NAME],
									 [TASK_ID],
									 [LAST_RUN],
									 [LAST_EXECUTION_TIME_SECS])
							VALUES (source.SERVER_NAME,
									source.DATABASE_NAME,
									source.TASK_ID,
									source.LAST_RUN,
									source.LAST_EXECUTION_TIME_SECS );
				END
      END
 ELSE
	IF @RC = 1  --REH SPROC HANDLED THE ERROR
      BEGIN
          PRINT ''
 
          PRINT 'FAILED !!!!!! ' + ISNULL(@C_TASK_DESC, '')
 
          PRINT ''
      END 
 

 
 

           IF EXISTS (SELECT *
                    FROM   sys.synonyms
                    WHERE  name = 'DYN_PS_LP_QUERY_SYSDATABASES')
           EXEC ('DROP SYNONYM [dbo].DYN_PS_LP_QUERY_SYSDATABASES')

  
END TRY 

BEGIN CATCH


UPDATE CAPTURE_LOG
SET    TEXT = TEXT + ' PROCEDURE FAILED !!! '
              + ISNULL(@C_TASK_DESC, 'TASK') + ' for SERVER
	'
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) + ', '
WHERE  STATS_TIME = @STATS_DATE  AND TASK_TYPE = @TASK_TYPE

PRINT 'ERROR WHILE COLLECTING ' + ISNULL(@C_TASK_DESC, '') +' !!!!!!!!!!!!!!'


           IF EXISTS (SELECT *
                    FROM   sys.synonyms
                    WHERE  name = 'DYN_PS_LP_QUERY_SYSDATABASES')
           EXEC ('DROP SYNONYM [dbo].DYN_PS_LP_QUERY_SYSDATABASES')


END CATCH



FETCH NEXT FROM TASK_CURSOR INTO @C_TASK_ID, @C_SERVER_NAME, @C_DATABASE_NAME, @C_TASK_PROCEDURE, @C_TASK_PARAMS, @C_TASK_DESC, @C_SERVER_LEVEL_TASK,@C_AZURE_DB, @C_LAST_RUN, @C_SCHED_UNITS


END  /*End of the loop */
CLOSE TASK_CURSOR  /*close the cursor to free memory in SQL*/
DEALLOCATE TASK_CURSOR /*Must deallocate the cursor to destroy it and free SQL resources*/
 
 DELETE FROM COLLECTIONDATABASES WHERE TASK_TYPE = @TASK_TYPE  --REH CLEANUP IN CASE SOMEBODY ELSE RUNS MANUAL CAPTURE
 
			

ENDPROC:
PRINT 'RUN NAME = '+ @RUN_NAME
GO
PRINT N'Creating [dbo].[DYNPERF_COLLECT_AX_BATCHJOB]...';

/****** Object:  StoredProcedure [dbo].[DYNPERF_COLLECT_AX_BATCHJOB]    Script Date: 10/4/2018 5:20:16 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DYNPERF_COLLECT_AX_BATCHJOB]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DYNPERF_COLLECT_AX_BATCHJOB]
GO


GO
CREATE PROCEDURE [dbo].[DYNPERF_COLLECT_AX_BATCHJOB] (@TASK_ID       INT,
                                              @SERVER_NAME   NVARCHAR(128),
                                              @DATABASE_NAME NVARCHAR(128),
                                              @TASK_PARAMS   NVARCHAR(1024),
                                              @TASK_DESC     NVARCHAR(256),
                                              @LAST_RUN      DATETIME,
                                              @RUN_NAME      NVARCHAR(255),
                                              @STATS_DATE    DATETIME,
                                              @REMOTE_SERVER NVARCHAR(1),
											  @AZURE_DB		 BIT,
											  @SQL_TZ_OFFSET INT,
											  @DPA_TZ_OFFSET INT,
                                              @DEBUG         NVARCHAR(1))
AS


/************************************************************************************************************
*  SETUP
*		DECLARE VARIABLES, CREATE SYNONYMS, ETC
*
*************************************************************************************************************/

    SET NOCOUNT ON
    SET DATEFORMAT MDY

    DECLARE @SQL NVARCHAR(MAX), @SQL2 NVARCHAR(MAX)
    
/*************************************************

--REH Template for creating a synonym, 
--Will help avoid having to use EXEC (@SQL) code
-- and make the code more dynamic to the inputs


***************************************************/
--REH Moved the synonms to avoid SQL runtime error that columns don't exists.  

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AX_BATCHJOB')
  EXEC ('DROP SYNONYM [dbo].DYN_AX_BATCHJOB')




/********************************************************************************************************************************
*   STARTING TASK
*********************************************************************************************************************************/

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'STARTING to ' + ISNULL(@TASK_DESC, 'TASK')
              + ' for SERVER ' + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' USING PARMS @LAST_RUN ' + CAST(@LAST_RUN AS VARCHAR(30)) 
			  + ' @DPA_TZ_OFFSET = ' + CAST (@DPA_TZ_OFFSET AS VARCHAR(10))
			  + ' @SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET  AS VARCHAR(10))
			  + ' @STATS_DATE = ' + CAST(@STATS_DATE AS VARCHAR(30)) 
			  + ' @AZURE_DB = ' + CAST(@AZURE_DB AS VARCHAR(10))
			  + ' @REMOTE = ' + @REMOTE_SERVER
			  + ' @PARMS = ' + ISNULL(@TASK_PARAMS, '')
			  + ', '
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



--REH  Time Zone code for all procedures

IF @LAST_RUN > '1/1/1901'
  BEGIN
      IF @REMOTE_SERVER = 'N'
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @DPA_TZ_OFFSET, @LAST_RUN) --REH DPA and DB are on same server so use DPA Time Zone Offset
        END
      ELSE
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @SQL_TZ_OFFSET, @LAST_RUN)  --REH DPA and DB are on different servers so use DB Time Zone Offset
        END
  END 


BEGIN TRY
PRINT 'STARTING ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AX_BATCHJOB')
  EXEC ('DROP SYNONYM [dbo].DYN_AX_BATCHJOB')
	



IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AX_BATCHJOB
				FOR [' + @SERVER_NAME + '].[' + @DATABASE_NAME + '].dbo.BATCHJOBHISTORY'
     END
ELSE

         SET @SQL = '
				CREATE SYNONYM DYN_AX_BATCHJOB
				FOR [' + @DATABASE_NAME + '].dbo.BATCHJOBHISTORY'

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL) 

INSERT AX_BATCH_DETAILS
SELECT @SERVER_NAME,
       @STATS_DATE,
       @DATABASE_NAME,
       BATCHJOBID,
       CAPTION,
       COMPANY,
       DATEADD(MI, @SQL_TZ_OFFSET, STARTDATETIME) AS STARTDATETIME,
       DATEADD(MI, @SQL_TZ_OFFSET, ENDDATETIME) AS ENDDATETIME,
       DATEDIFF(SS, STARTDATETIME, ENDDATETIME) AS SECONDS,
       STATUS,
       CREATEDDATETIME
FROM   DYN_AX_BATCHJOB WITH (NOLOCK)
WHERE  DATEADD(MI, @SQL_TZ_OFFSET, ENDDATETIME) >= @LAST_RUN
       AND DATEADD(D, 30, ENDDATETIME) >= GETDATE() 

	

	
IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AX_BATCHJOB')
 EXEC('DROP SYNONYM [dbo].DYN_AX_BATCHJOB')
  
  	
 
UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'SUCCESSFULLY '
              + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' Inserted ' + cast(@@rowcount as varchar(10)) + ' ROWS ' +  CHAR(10) 
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



PRINT ''
PRINT 'SUCCESSFULLY CAPTURED ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


RETURN(0)  --REH RETURN SUCCESS


END TRY 


/********************************************************************************************************************************
*   END OF TASK
*********************************************************************************************************************************/


BEGIN CATCH

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AX_BATCHJOB')
  EXEC ('DROP SYNONYM [dbo].DYN_AX_BATCHJOB')



    UPDATE CAPTURE_LOG
    SET    TEXT = TEXT + 'FAILED !!! to '
	      + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
                  + ISNULL(@SERVER_NAME, '') + ' on database '
                  + ISNULL(@DATABASE_NAME, '') + ' at '
                  + CONVERT(VARCHAR, GETDATE(), 109) 
				  + ', ' 
				  + CHAR(10)
    WHERE  STATS_TIME = @STATS_DATE
	AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)




    PRINT 'ERROR WHILE COLLECTING '
          + ISNULL(@TASK_DESC, '') + ' !!!!!!!!!!!!!!'

    RETURN(1) --REH RETURN ERROR, TRAPPED BY SPROC
END CATCH
GO
PRINT N'Creating [dbo].[DYNPERF_COLLECT_DB_SCOPECONFIG]...';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;

/****** Object:  StoredProcedure [dbo].[DYNPERF_COLLECT_DB_SCOPECONFIG]    Script Date: 10/4/2018 5:21:23 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DYNPERF_COLLECT_DB_SCOPECONFIG]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DYNPERF_COLLECT_DB_SCOPECONFIG]
GO


GO

CREATE PROCEDURE DYNPERF_COLLECT_DB_SCOPECONFIG(@TASK_ID       INT,
                                              @SERVER_NAME   NVARCHAR(128),
                                              @DATABASE_NAME NVARCHAR(128),
                                              @TASK_PARAMS   NVARCHAR(1024),
                                              @TASK_DESC     NVARCHAR(256),
                                              @LAST_RUN      DATETIME,
                                              @RUN_NAME      NVARCHAR(255),
                                              @STATS_DATE    DATETIME,
                                              @REMOTE_SERVER NVARCHAR(1),
											  @AZURE_DB		 BIT,
											  @SQL_TZ_OFFSET INT,
											  @DPA_TZ_OFFSET INT,
                                              @DEBUG         NVARCHAR(1))
AS


/************************************************************************************************************
*  SETUP
*		DECLARE VARIABLES, CREATE SYNONYMS, ETC
*
*************************************************************************************************************/

    SET NOCOUNT ON
    SET DATEFORMAT MDY

    DECLARE @SQL NVARCHAR(MAX), @SQL2 NVARCHAR(MAX), @ROW_COUNT BIGINT=0, @SQLVERSION VARCHAR(30)
	DECLARE @LEGACY_CARDINALITY_ON   sql_variant              
	DECLARE @MAXDOP                  sql_variant              
	DECLARE	@PARAMETER_SNIFFING		 sql_variant				 
	DECLARE	@QUERY_OPTIMIZER_FIXES	 sql_variant	
    
    
/*************************************************

--REH Template for creating a synonym, 
--Will help avoid having to use EXEC (@SQL) code
-- and make the code more dynamic to the inputs


***************************************************/
/********************************************************************************************************************************
*   STARTING TASK
*********************************************************************************************************************************/



UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'STARTING to ' + ISNULL(@TASK_DESC, 'TASK')
              + ' for SERVER ' + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' USING PARMS @LAST_RUN ' + CAST(@LAST_RUN AS VARCHAR(30)) 
			  + ' @DPA_TZ_OFFSET = ' + CAST (@DPA_TZ_OFFSET AS VARCHAR(10))
			  + ' @SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET  AS VARCHAR(10))
			  + ' @STATS_DATE = ' + CAST(@STATS_DATE AS VARCHAR(30)) 
			  + ' @AZURE_DB = ' + CAST(@AZURE_DB AS VARCHAR(10))
			  + ' @REMOTE = ' + @REMOTE_SERVER
			  + ' @PARMS = ' + ISNULL(@TASK_PARAMS, '')
			  + ', '
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)





--REH  Time Zone code for all procedures
IF @LAST_RUN > '1/1/1901'
  BEGIN
      IF @REMOTE_SERVER = 'N'
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @DPA_TZ_OFFSET, @LAST_RUN) --REH DPA and DB are on same server so use DPA Time Zone Offset
        END
      ELSE
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @SQL_TZ_OFFSET, @LAST_RUN)  --REH DPA and DB are on different servers so use DB Time Zone Offset
        END
  END 



  
		IF EXISTS (SELECT *
				   FROM   sys.synonyms
				   WHERE  name = 'DYN_SI_SQLVERSION')
		 EXEC ('DROP SYNONYM [dbo].DYN_SI_SQLVERSION')


		IF @REMOTE_SERVER = 'Y'
			 BEGIN
				 SET @SQL = '
						CREATE SYNONYM DYN_SI_SQLVERSION
						FOR [' + @SERVER_NAME + '].master.sys.xp_msver'
			 END
		ELSE

				 SET @SQL = '
						CREATE SYNONYM DYN_SI_SQLVERSION
						FOR master.sys.xp_msver'

		IF @DEBUG = 'Y' 
		BEGIN
		PRINT '@SQL= ' + @SQL
		END

		EXEC (@SQL) 


		CREATE  table #SQLVERSION(
		[INDEX] INT,
		NAME NVARCHAR(128),
		INTERNAL_VALUE NVARCHAR(128),
		VALUE NVARCHAR(128)
		);

		INSERT #SQLVERSION
		exec DYN_SI_SQLVERSION  --[master].sys.[xp_msver]

		SELECT @SQLVERSION = VALUE FROM #SQLVERSION WHERE NAME = 'ProductVersion'

		IF @SQLVERSION < '13'
		BEGIN

		UPDATE CAPTURE_LOG
			SET    TEXT = TEXT + 'SUCCESSFULLY '
						  + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
						  + ISNULL(@SERVER_NAME, '') + ' on database '
						  + ISNULL(@DATABASE_NAME, '') + ' at '
						  + CONVERT(VARCHAR, GETDATE(), 109) 
						  + ' Inserted ' + cast(@ROW_COUNT as varchar(10)) + ' ROWS ' +  CHAR(10) 
			WHERE  STATS_TIME = @STATS_DATE 
			AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)

	RETURN (0)  --REH OLDER VERSION OF SQL DON'T RUN
		END


BEGIN TRY
PRINT 'STARTING ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_SDB_SYSDATABASESCOPECONFIG')
  EXEC ('DROP SYNONYM [dbo].DYN_SDB_SYSDATABASESCOPECONFIG')


IF @REMOTE_SERVER = 'Y'
     BEGIN

--REH  You CANNOT use synonms for queries that pull XML or use FUNCTIONS

         SET @SQL = '
				CREATE SYNONYM DYN_SDB_SYSDATABASESCOPECONFIG
				FOR [' + @SERVER_NAME + '].' + @DATABASE_NAME + '.sys.database_scoped_configurations'
     END
ELSE
	BEGIN 
         SET @SQL = '
				CREATE SYNONYM DYN_SDB_SYSDATABASESCOPECONFIG
				FOR ' + @DATABASE_NAME + '.sys.database_scoped_configurations'
	END

EXEC (@SQL)

	SELECT  @MAXDOP=value   FROM DYN_SDB_SYSDATABASESCOPECONFIG WHERE name = 'MAXDOP'
	SELECT  @LEGACY_CARDINALITY_ON =value   FROM DYN_SDB_SYSDATABASESCOPECONFIG WHERE name = 'LEGACY_CARDINALITY_ESTIMATION'
	SELECT  @PARAMETER_SNIFFING =value   FROM DYN_SDB_SYSDATABASESCOPECONFIG WHERE name = 'PARAMETER_SNIFFING'
	SELECT  @QUERY_OPTIMIZER_FIXES =value   FROM DYN_SDB_SYSDATABASESCOPECONFIG WHERE name = 'QUERY_OPTIMIZER_HOTFIXES'

    
	INSERT INTO [DynamicsPerf]..SQL_DATABASE_SCOPECONFIG
			SELECT @SERVER_NAME,
			@DATABASE_NAME, 
			@STATS_DATE, 
			@LEGACY_CARDINALITY_ON,
			@MAXDOP,
			@PARAMETER_SNIFFING,
		  @QUERY_OPTIMIZER_FIXES 

	


UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'SUCCESSFULLY '
              + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' Inserted ' + cast(@ROW_COUNT as varchar(10)) + ' ROWS ' +  CHAR(10) 
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)


PRINT ''
PRINT 'SUCCESSFULLY CAPTURED ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


--REH Drop all synonyms

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_SDB_SYSDATABASESCOPECONFIG')
  EXEC ('DROP SYNONYM [dbo].DYN_SDB_SYSDATABASESCOPECONFIG')


RETURN(0)  --REH RETURN SUCCESS


END TRY 


/********************************************************************************************************************************
*   END OF TASK
*********************************************************************************************************************************/




BEGIN CATCH
    UPDATE CAPTURE_LOG
    SET    TEXT = TEXT + 'FAILED !!! to '
	      + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
                  + ISNULL(@SERVER_NAME, '') + ' on database '
                  + ISNULL(@DATABASE_NAME, '') + ' at '
                  + CONVERT(VARCHAR, GETDATE(), 109) 
				  + ' ERROR = ' + CAST(@@ERROR AS VARCHAR(MAX))
				  + ', ' 
				  + CHAR(10)
    WHERE  STATS_TIME = @STATS_DATE
	AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)




    PRINT 'ERROR WHILE COLLECTING '
          + ISNULL(@TASK_DESC, '') + ' !!!!!!!!!!!!!!'

----REH Drop all synonyms

--IF EXISTS (SELECT *
--           FROM   sys.synonyms
--           WHERE  name = 'DYN_SDB_SYSDATABASESCOPECONFIG')
--  EXEC ('DROP SYNONYM [dbo].DYN_SDB_SYSDATABASESCOPECONFIG')


    RETURN(1) --REH RETURN ERROR, TRAPPED BY SPROC
END CATCH
GO



GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;

/****** Object:  StoredProcedure [dbo].[DYNPERF_COLLECT_SQL_ALWAYSON]    Script Date: 10/4/2018 5:21:44 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DYNPERF_COLLECT_SQL_ALWAYSON]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DYNPERF_COLLECT_SQL_ALWAYSON]
GO


GO
PRINT N'Creating [dbo].[DYNPERF_COLLECT_SQL_ALWAYSON]...';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
CREATE PROCEDURE [dbo].[DYNPERF_COLLECT_SQL_ALWAYSON] (@TASK_ID       INT,
                                              @SERVER_NAME   NVARCHAR(128),
                                              @DATABASE_NAME NVARCHAR(128),
                                              @TASK_PARAMS   NVARCHAR(1024),
                                              @TASK_DESC     NVARCHAR(256),
                                              @LAST_RUN      DATETIME,
                                              @RUN_NAME      NVARCHAR(255),
                                              @STATS_DATE    DATETIME,
                                              @REMOTE_SERVER NVARCHAR(1),
											  @AZURE_DB		 BIT,
											  @SQL_TZ_OFFSET INT,
											  @DPA_TZ_OFFSET INT,
                                              @DEBUG         NVARCHAR(1))
AS

/************************************************************************************************************
*  SETUP
*		DECLARE VARIABLES, CREATE SYNONYMS, ETC
*
*************************************************************************************************************/

    SET NOCOUNT ON
    SET DATEFORMAT MDY

    DECLARE @SQL NVARCHAR(MAX), @SQL2 NVARCHAR(MAX)
    
/*************************************************

--REH Template for creating a synonym, 
--Will help avoid having to use EXEC (@SQL) code
-- and make the code more dynamic to the inputs


***************************************************/

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AO_SYS_AVAILABILITY_GROUPS')
  EXEC ('DROP SYNONYM [dbo].DYN_AO_SYS_AVAILABILITY_GROUPS')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AO_SYS_DM_HADR_AVAILABILITY_GROUP_STATES')
  EXEC ('DROP SYNONYM [dbo].DYN_AO_SYS_DM_HADR_AVAILABILITY_GROUP_STATES')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AO_SYS_AVAILABILITY_REPLICAS')
  EXEC ('DROP SYNONYM [dbo].DYN_AO_SYS_AVAILABILITY_REPLICAS')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AO_SYS_DM_HADR_AVAILABILITY_REPLICA_STATES')
  EXEC ('DROP SYNONYM [dbo].DYN_AO_SYS_DM_HADR_AVAILABILITY_REPLICA_STATES')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AO_SYS_DM_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES')
  EXEC ('DROP SYNONYM [dbo].DYN_AO_SYS_DM_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AO_SYS_DM_HADR_DATABASE_REPLICA_STATES')
  EXEC ('DROP SYNONYM [dbo].DYN_AO_SYS_DM_HADR_DATABASE_REPLICA_STATES')

  IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AO_HADR_DB_REPLICA_CLUSTER_STATES')
  EXEC ('DROP SYNONYM [dbo].DYN_AO_HADR_DB_REPLICA_CLUSTER_STATES')

  

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AO_SYS_AVAILABILITY_GROUP_LISTENERS')
  EXEC ('DROP SYNONYM [dbo].DYN_AO_SYS_AVAILABILITY_GROUP_LISTENERS')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AO_SYS_AVAILABILITY_READ_ONLY_ROUTING_LISTS')
  EXEC ('DROP SYNONYM [DBO].DYN_AO_SYS_AVAILABILITY_READ_ONLY_ROUTING_LISTS')




IF @REMOTE_SERVER = 'Y'
     BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AO_SYS_AVAILABILITY_GROUPS
				FOR [' + @SERVER_NAME + '].master.sys.availability_groups'
         SET @SQL = @SQL + CHAR(10) + CHAR(13) + '
				CREATE SYNONYM DYN_AO_SYS_DM_HADR_AVAILABILITY_GROUP_STATES
				FOR [' + @SERVER_NAME + '].master.sys.dm_hadr_availability_group_states'
         SET @SQL = @SQL + CHAR(10) + CHAR(13) + '
				CREATE SYNONYM DYN_AO_SYS_AVAILABILITY_REPLICAS
				FOR [' + @SERVER_NAME + '].master.sys.availability_replicas'
         SET @SQL =@SQL +  CHAR(10) + CHAR(13) + '
				CREATE SYNONYM DYN_AO_SYS_DM_HADR_AVAILABILITY_REPLICA_STATES
				FOR [' + @SERVER_NAME + '].master.sys.dm_hadr_availability_replica_states'
         SET @SQL = @SQL + CHAR(10) + CHAR(13) + '
				CREATE SYNONYM DYN_AO_SYS_DM_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES
				FOR [' + @SERVER_NAME + '].master.sys.dm_hadr_availability_replica_cluster_states'
         SET @SQL =@SQL +  CHAR(10) + CHAR(13) + '
				CREATE SYNONYM DYN_AO_SYS_DM_HADR_DATABASE_REPLICA_STATES
				FOR [' + @SERVER_NAME + '].master.sys.dm_hadr_database_replica_states'
         SET @SQL = @SQL + CHAR(10) + CHAR(13) + '
				CREATE SYNONYM DYN_AO_SYS_AVAILABILITY_GROUP_LISTENERS
				FOR [' + @SERVER_NAME + '].master.sys.availability_group_listeners'
         SET @SQL = @SQL + CHAR(10) + CHAR(13) + '
				CREATE SYNONYM DYN_AO_SYS_AVAILABILITY_READ_ONLY_ROUTING_LISTS
				FOR [' + @SERVER_NAME + '].master.sys.availability_read_only_routing_lists'
         SET @SQL = @SQL + CHAR(10) + CHAR(13) + '
				CREATE SYNONYM DYN_AO_HADR_DB_REPLICA_CLUSTER_STATES
				FOR [' + @SERVER_NAME + '].master.sys.dm_hadr_database_replica_cluster_states'


     END
ELSE
	BEGIN
         SET @SQL = '
				CREATE SYNONYM DYN_AO_SYS_AVAILABILITY_GROUPS
				FOR master.sys.availability_groups'
         SET @SQL = @SQL + CHAR(10) + CHAR(13) + 'GO 
				CREATE SYNONYM DYN_AO_SYS_DM_HADR_AVAILABILITY_GROUP_STATES
				FOR master.sys.dm_hadr_availability_group_states'
         SET @SQL = @SQL + CHAR(10) + CHAR(13) + 'GO 
				CREATE SYNONYM DYN_AO_SYS_AVAILABILITY_REPLICAS
				FOR master.sys.availability_replicas'
         SET @SQL =@SQL +  CHAR(10) + CHAR(13) + 'GO 
				CREATE SYNONYM DYN_AO_SYS_DM_HADR_AVAILABILITY_REPLICA_STATES
				FOR master.sys.dm_hadr_availability_replica_states'
         SET @SQL = @SQL + CHAR(10) + CHAR(13) + 'GO 
				CREATE SYNONYM DYN_AO_SYS_DM_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES
				FOR master.sys.dm_hadr_availability_replica_cluster_states'
         SET @SQL =@SQL +  CHAR(10) + CHAR(13) + 'GO 
				CREATE SYNONYM DYN_AO_SYS_DM_HADR_DATABASE_REPLICA_STATES
				FOR master.sys.dm_hadr_database_replica_states'
         SET @SQL = @SQL + CHAR(10) + CHAR(13) + 'GO 
				CREATE SYNONYM DYN_AO_SYS_AVAILABILITY_GROUP_LISTENERS
				FOR master.sys.availability_group_listeners'
	    SET @SQL = @SQL + CHAR(10) + CHAR(13) + '
			CREATE SYNONYM DYN_AO_SYS_AVAILABILITY_READ_ONLY_ROUTING_LISTS
			FOR master.sys.availability_read_only_routing_lists'
         SET @SQL = @SQL + CHAR(10) + CHAR(13) + '
				CREATE SYNONYM DYN_AO_HADR_DB_REPLICA_CLUSTER_STATES
				FOR [' + @SERVER_NAME + '].master.sys.dm_hadr_database_replica_cluster_states'


	END

IF @DEBUG = 'Y' 
BEGIN
PRINT '@SQL= ' + @SQL
END

EXEC (@SQL) 

/********************************************************************************************************************************
*   STARTING TASK
*********************************************************************************************************************************/

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'STARTING to ' + ISNULL(@TASK_DESC, 'TASK')
              + ' for SERVER ' + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' USING PARMS @LAST_RUN ' + CAST(@LAST_RUN AS VARCHAR(30)) 
			  + ' @DPA_TZ_OFFSET = ' + CAST (@DPA_TZ_OFFSET AS VARCHAR(10))
			  + ' @SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET  AS VARCHAR(10))
			  + ' @STATS_DATE = ' + CAST(@STATS_DATE AS VARCHAR(30)) 
			  + ' @AZURE_DB = ' + CAST(@AZURE_DB AS VARCHAR(10))
			  + ' @REMOTE = ' + @REMOTE_SERVER
			  + ' @PARMS = ' + ISNULL(@TASK_PARAMS, '')
			  + ', '
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



--REH  Time Zone code for all procedures
IF @LAST_RUN > '1/1/1901'
  BEGIN
      IF @REMOTE_SERVER = 'N'
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @DPA_TZ_OFFSET, @LAST_RUN) --REH DPA and DB are on same server so use DPA Time Zone Offset
        END
      ELSE
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @SQL_TZ_OFFSET, @LAST_RUN)  --REH DPA and DB are on different servers so use DB Time Zone Offset
        END
  END 





BEGIN TRY
PRINT 'STARTING ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


INSERT INTO [DynamicsPerf].[dbo].[SQL_AO_AVAILABILITY_GROUP_LISTENERS]
           ([SERVER_NAME],
		    [STATS_TIME],
		   [group_id]
           ,[listener_id]
           ,[dns_name]
           ,[port]
           ,[is_conformant]
           ,[ip_configuration_string_from_cluster])
SELECT @SERVER_NAME, @STATS_DATE
	  ,[group_id]
      ,[listener_id]
      ,[dns_name]
      ,[port]
      ,[is_conformant]
      ,[ip_configuration_string_from_cluster]
  FROM [dbo].[DYN_AO_SYS_AVAILABILITY_GROUP_LISTENERS]

INSERT INTO [DynamicsPerf].[dbo].[SQL_AO_AVAILABILITY_GROUP_STATES]
           ([SERVER_NAME],
		    [STATS_TIME]
			,[group_id]
           ,[primary_replica]
           ,[primary_recovery_health]
           ,[primary_recovery_health_desc]
           ,[secondary_recovery_health]
           ,[secondary_recovery_health_desc]
           ,[synchronization_health]
           ,[synchronization_health_desc])
SELECT @SERVER_NAME, @STATS_DATE
	  ,[group_id]
      ,[primary_replica]
      ,[primary_recovery_health]
      ,[primary_recovery_health_desc]
      ,[secondary_recovery_health]
      ,[secondary_recovery_health_desc]
      ,[synchronization_health]
      ,[synchronization_health_desc]
  FROM [dbo].[DYN_AO_SYS_DM_HADR_AVAILABILITY_GROUP_STATES]


INSERT INTO [DynamicsPerf].[dbo].[SQL_AO_AVAILABILITY_REPLICA_STATES]
           ([SERVER_NAME],
		    [STATS_TIME]
		   ,[replica_id]
           ,[group_id]
           ,[is_local]
           ,[role]
           ,[role_desc]
           ,[operational_state]
           ,[operational_state_desc]
           ,[connected_state]
           ,[connected_state_desc]
           ,[recovery_health]
           ,[recovery_health_desc]
           ,[synchronization_health]
           ,[synchronization_health_desc]
           ,[last_connect_error_number]
           ,[last_connect_error_description]
           ,[last_connect_error_timestamp])
SELECT @SERVER_NAME, @STATS_DATE
	  ,[replica_id]
      ,[group_id]
      ,[is_local]
      ,[role]
      ,[role_desc]
      ,[operational_state]
      ,[operational_state_desc]
      ,[connected_state]
      ,[connected_state_desc]
      ,[recovery_health]
      ,[recovery_health_desc]
      ,[synchronization_health]
      ,[synchronization_health_desc]
      ,[last_connect_error_number]
      ,[last_connect_error_description]
      ,[last_connect_error_timestamp]
  FROM [dbo].[DYN_AO_SYS_DM_HADR_AVAILABILITY_REPLICA_STATES]

INSERT INTO [DynamicsPerf].[dbo].[SQL_AO_AVAILABILITY_REPLICAS]
           ([SERVER_NAME],
		    [STATS_TIME]
		   ,[replica_id]
           ,[group_id]
           ,[replica_metadata_id]
           ,[replica_server_name]
           ,[owner_sid]
           ,[endpoint_url]
           ,[availability_mode]
           ,[availability_mode_desc]
           ,[failover_mode]
           ,[failover_mode_desc]
           ,[session_timeout]
           ,[primary_role_allow_connections]
           ,[primary_role_allow_connections_desc]
           ,[secondary_role_allow_connections]
           ,[secondary_role_allow_connections_desc]
           ,[create_date]
           ,[modify_date]
           ,[backup_priority]
           ,[read_only_routing_url])
SELECT @SERVER_NAME, @STATS_DATE
	  ,[replica_id]
      ,[group_id]
      ,[replica_metadata_id]
      ,[replica_server_name]
      ,[owner_sid]
      ,[endpoint_url]
      ,[availability_mode]
      ,[availability_mode_desc]
      ,[failover_mode]
      ,[failover_mode_desc]
      ,[session_timeout]
      ,[primary_role_allow_connections]
      ,[primary_role_allow_connections_desc]
      ,[secondary_role_allow_connections]
      ,[secondary_role_allow_connections_desc]
      ,[create_date]
      ,[modify_date]
      ,[backup_priority]
      ,[read_only_routing_url]
  FROM [dbo].[DYN_AO_SYS_AVAILABILITY_REPLICAS]   


INSERT INTO [DynamicsPerf].[dbo].[SQL_AO_AVAILABILITYGROUPS]
           ([SERVER_NAME],
		    [STATS_TIME]
		   ,[group_id]
           ,[name]
           ,[resource_id]
           ,[resource_group_id]
           ,[failure_condition_level]
           ,[health_check_timeout]
           ,[automated_backup_preference]
           ,[automated_backup_preference_desc])
SELECT @SERVER_NAME, @STATS_DATE
	  ,[group_id]
      ,[name]
      ,[resource_id]
      ,[resource_group_id]
      ,[failure_condition_level]
      ,[health_check_timeout]
      ,[automated_backup_preference]
      ,[automated_backup_preference_desc]
  FROM [dbo].[DYN_AO_SYS_AVAILABILITY_GROUPS]

INSERT INTO [DynamicsPerf].[dbo].[SQL_AO_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES]
           ([SERVER_NAME],
		    [STATS_TIME]
		   ,[replica_id]
           ,[replica_server_name]
           ,[group_id]
           ,[join_state]
           ,[join_state_desc])
SELECT @SERVER_NAME, @STATS_DATE
	  ,[replica_id]
      ,[replica_server_name]
      ,[group_id]
      ,[join_state]
      ,[join_state_desc]
  FROM [dbo].[DYN_AO_SYS_DM_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES]

INSERT INTO [dbo].[SQL_AO_HADR_DB_REPLICA_CLUSTER_STATES]
           ([SERVER_NAME]
           ,[STATS_TIME]
           ,[replica_id]
           ,[group_database_id]
           ,[database_name]
           ,[is_failover_ready]
           ,[is_pending_secondary_suspend]
           ,[is_database_joined]
           ,[recovery_lsn]
           ,[truncation_lsn])
SELECT  @SERVER_NAME, @STATS_DATE
      ,[replica_id]
      ,[group_database_id]
      ,[database_name]
      ,[is_failover_ready]
      ,[is_pending_secondary_suspend]
      ,[is_database_joined]
      ,[recovery_lsn]
      ,[truncation_lsn]
  FROM [dbo].[DYN_AO_HADR_DB_REPLICA_CLUSTER_STATES]

INSERT INTO [DynamicsPerf].[dbo].[SQL_AO_HADR_DATABASE_REPLICA_STATES]
           ([SERVER_NAME],
		    [STATS_TIME]
		   ,[database_id]
           ,[group_id]
           ,[replica_id]
           ,[group_database_id]
           ,[is_local]
           ,[synchronization_state]
           ,[synchronization_state_desc]
           ,[is_commit_participant]
           ,[synchronization_health]
           ,[synchronization_health_desc]
           ,[database_state]
           ,[database_state_desc]
           ,[is_suspended]
           ,[suspend_reason]
           ,[suspend_reason_desc]
           ,[recovery_lsn]
           ,[truncation_lsn]
           ,[last_sent_lsn]
           ,[last_sent_time]
           ,[last_received_lsn]
           ,[last_received_time]
           ,[last_hardened_lsn]
           ,[last_hardened_time]
           ,[last_redone_lsn]
           ,[last_redone_time]
           ,[log_send_queue_size]
           ,[log_send_rate]
           ,[redo_queue_size]
           ,[redo_rate]
           ,[filestream_send_rate]
           ,[end_of_log_lsn]
           ,[last_commit_lsn]
           ,[last_commit_time]
           ,[low_water_mark_for_ghosts])
SELECT @SERVER_NAME, @STATS_DATE
	  ,[database_id]
      ,[group_id]
      ,[replica_id]
      ,[group_database_id]
      ,[is_local]
      ,[synchronization_state]
      ,[synchronization_state_desc]
      ,[is_commit_participant]
      ,[synchronization_health]
      ,[synchronization_health_desc]
      ,[database_state]
      ,[database_state_desc]
      ,[is_suspended]
      ,[suspend_reason]
      ,[suspend_reason_desc]
      ,[recovery_lsn]
      ,[truncation_lsn]
      ,[last_sent_lsn]
      ,[last_sent_time]
      ,[last_received_lsn]
      ,[last_received_time]
      ,[last_hardened_lsn]
      ,[last_hardened_time]
      ,[last_redone_lsn]
      ,[last_redone_time]
      ,[log_send_queue_size]
      ,[log_send_rate]
      ,[redo_queue_size]
      ,[redo_rate]
      ,[filestream_send_rate]
      ,[end_of_log_lsn]
      ,[last_commit_lsn]
      ,[last_commit_time]
      ,[low_water_mark_for_ghosts]
  FROM [dbo].[DYN_AO_SYS_DM_HADR_DATABASE_REPLICA_STATES]

  INSERT INTO [DynamicsPerf].[dbo].[SQL_AO_ROUTINGLISTS]
           ([SERVER_NAME]
           ,[STATS_TIME]
           ,[replica_id]
           ,[routing_priority]
           ,[read_only_replica_id])
SELECT @SERVER_NAME, @STATS_DATE
      ,[replica_id]
      ,[routing_priority]
      ,[read_only_replica_id]
  FROM DYN_AO_SYS_AVAILABILITY_READ_ONLY_ROUTING_LISTS



IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AO_SYS_AVAILABILITY_GROUPS')
  EXEC ('DROP SYNONYM [dbo].DYN_AO_SYS_AVAILABILITY_GROUPS')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AO_SYS_DM_HADR_AVAILABILITY_GROUP_STATES')
  EXEC ('DROP SYNONYM [dbo].DYN_AO_SYS_DM_HADR_AVAILABILITY_GROUP_STATES')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AO_SYS_AVAILABILITY_REPLICAS')
  EXEC ('DROP SYNONYM [dbo].DYN_AO_SYS_AVAILABILITY_REPLICAS')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AO_SYS_DM_HADR_AVAILABILITY_REPLICA_STATES')
  EXEC ('DROP SYNONYM [dbo].DYN_AO_SYS_DM_HADR_AVAILABILITY_REPLICA_STATES')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AO_SYS_DM_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES')
  EXEC ('DROP SYNONYM [dbo].DYN_AO_SYS_DM_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AO_SYS_DM_HADR_DATABASE_REPLICA_STATES')
  EXEC ('DROP SYNONYM [dbo].DYN_AO_SYS_DM_HADR_DATABASE_REPLICA_STATES')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AO_SYS_AVAILABILITY_GROUP_LISTENERS')
  EXEC ('DROP SYNONYM [dbo].DYN_AO_SYS_AVAILABILITY_GROUP_LISTENERS')

IF EXISTS (SELECT *
           FROM   sys.synonyms
           WHERE  name = 'DYN_AO_SYS_AVAILABILITY_READ_ONLY_ROUTING_LISTS')
  EXEC ('DROP SYNONYM [DBO].DYN_AO_SYS_AVAILABILITY_READ_ONLY_ROUTING_LISTS')




    
UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'SUCCESSFULLY '
              + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
			  + ' Inserted ' + CAST(@@ROWCOUNT AS VARCHAR(10)) + ' ROWS ' +  CHAR(10) 
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



PRINT ''
PRINT 'SUCCESSFULLY CAPTURED ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


RETURN(0)  --REH RETURN SUCCESS


END TRY 


/********************************************************************************************************************************
*   END OF TASK
*********************************************************************************************************************************/



BEGIN CATCH
    UPDATE CAPTURE_LOG
    SET    TEXT = TEXT + 'FAILED !!! to '
	      + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
                  + ISNULL(@SERVER_NAME, '') + ' on database '
                  + ISNULL(@DATABASE_NAME, '') + ' at '
                  + CONVERT(VARCHAR, GETDATE(), 109) 
				  + ' ERROR = ' + CAST(@@ERROR AS VARCHAR(MAX))
				  + ', ' 
				  + CHAR(10)
    WHERE  STATS_TIME = @STATS_DATE
	AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



    PRINT 'ERROR WHILE COLLECTING '
          + ISNULL(@TASK_DESC, '') + ' !!!!!!!!!!!!!!'

    RETURN(1) --REH RETURN ERROR, TRAPPED BY SPROC
END CATCH
GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Creating [dbo].[DYNPERF_UPDATE_AXBATCH_HISTORY]...';

/****** Object:  StoredProcedure [dbo].[DYNPERF_UPDATE_AXBATCH_HISTORY]    Script Date: 10/4/2018 5:22:09 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DYNPERF_UPDATE_AXBATCH_HISTORY]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[DYNPERF_UPDATE_AXBATCH_HISTORY]
GO


GO
CREATE PROCEDURE [dbo].[DYNPERF_UPDATE_AXBATCH_HISTORY]
	(@TASK_ID       INT,
                                              @SERVER_NAME   NVARCHAR(128),
                                              @DATABASE_NAME NVARCHAR(128),
                                              @TASK_PARAMS   NVARCHAR(1024),
                                              @TASK_DESC     NVARCHAR(256),
                                              @LAST_RUN      DATETIME,
                                              @RUN_NAME      NVARCHAR(255),
                                              @STATS_DATE    DATETIME,
                                              @REMOTE_SERVER NVARCHAR(1),
											  @AZURE_DB		 BIT,
											  @SQL_TZ_OFFSET INT,
											  @DPA_TZ_OFFSET INT,
                                              @DEBUG         NVARCHAR(1))
AS

/************************************************************************************************************
*  SETUP
*          DECLARE VARIABLES, CREATE SYNONYMS, ETC
*
*************************************************************************************************************/


    SET NOCOUNT ON
    SET DATEFORMAT MDY

    DECLARE @SQL NVARCHAR(MAX), @SQL2 NVARCHAR(MAX), @ROW_COUNT BIGINT = 0
    



/********************************************************************************************************************************
*   STARTING TASK
*********************************************************************************************************************************/

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'STARTING to ' + ISNULL(@TASK_DESC, 'TASK')
              + ' for SERVER ' + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
                   + ' USING PARMS @LAST_RUN ' + CAST(@LAST_RUN AS VARCHAR(30)) 
                   + ' @DPA_TZ_OFFSET = ' + CAST (@DPA_TZ_OFFSET AS VARCHAR(10))
                   + ' @SQL_TZ_OFFSET = ' + CAST(@SQL_TZ_OFFSET  AS VARCHAR(10))
                   + ' @STATS_DATE = ' + CAST(@STATS_DATE AS VARCHAR(30)) 
                   + ' @AZURE_DB = ' + CAST(@AZURE_DB AS VARCHAR(10))
                   + ' @REMOTE = ' + @REMOTE_SERVER
                   + ' @PARMS = ' + ISNULL(@TASK_PARAMS, '')
                   + ', '
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)




--REH  Time Zone code for all procedures
IF @LAST_RUN > '1/1/1901'
  BEGIN
      IF @REMOTE_SERVER = 'N'
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @DPA_TZ_OFFSET, @LAST_RUN) --REH DPA and DB are on same server so use DPA Time Zone Offset
        END
      ELSE
        BEGIN
            SET @LAST_RUN = DATEADD(MI, @SQL_TZ_OFFSET, @LAST_RUN)  --REH DPA and DB are on different servers so use DB Time Zone Offset
        END
  END 


  --REH need to figure out if it's midnight DB time for DB being rolled up
  -- Take stats_time which is time at DPA server and convert it to local time of the DB

  DECLARE @SERVER_TIME SMALLDATETIME, @SERVER_TIME_MIDNIGHT SMALLDATETIME, @TIME_DIFF INT, @SERVER_TIME_START SMALLDATETIME, @PREV_DAY SMALLDATETIME


   SET @SERVER_TIME = DATEADD(MI,@SQL_TZ_OFFSET,DATEADD(MI,@DPA_TZ_OFFSET*-1,@STATS_DATE))
  SET @SERVER_TIME_MIDNIGHT = (SELECT dateadd(DAY,datediff(DAY,-1,@SERVER_TIME),0))  --REH MIDNIGHT, NEXT DAY, SO HAVE TO BE LESS THAN THIS VALUE FOR TODAY
  SET @SERVER_TIME_START = (SELECT dateadd(DAY,datediff(DAY,0,@SERVER_TIME),0))  --REH MIDNIGHT, NEXT DAY, SO HAVE TO BE LESS THAN THIS VALUE FOR TODAY
  SET @PREV_DAY = DATEADD(DD,-1, @SERVER_TIME_START)
  SET @TIME_DIFF = DATEDIFF(MI, @SERVER_TIME, @SERVER_TIME_MIDNIGHT)


  UPDATE CAPTURE_LOG
SET    TEXT = TEXT + '  CURRENT SERVER TIME ' + CAST( @SERVER_TIME AS VARCHAR(50))
              + '  MIDNIGHT SERVER TIME ' + CAST(@SERVER_TIME_MIDNIGHT AS VARCHAR(50))
              + '  START OF TODAY ' + CAST(@SERVER_TIME_START AS VARCHAR(50))
              +'  FLOORED PREVIOUS DAY ' + CAST(@PREV_DAY AS VARCHAR(50))
                   + ', '
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)




  --REH Giving a 5 minute leaway after midnight to run this code, job will be scheduled to run hourly
-- IF ABS(@TIME_DIFF)> 5  RETURN(0) ;  -- If it's not midnight Server time ont he DB being rolled up, then do nothing

BEGIN TRY
PRINT 'STARTING ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''



/******************************************************************************
NEED TO SUBTRACT OUT PREVIOUS DAYS AMOUNTS IF COMPILE_TIME WAS BEFORE TODAY

SUBTRACT THE LAST QUERY_STATS RECORD FROM PREVIOUS DAY WITH SAME COMPILE_TIME


*******************************************************************************/



           --REH This sums up to the totals of the day
           MERGE AX_BATCH_HISTORY AS target
           USING (SELECT SERVER_NAME,
                              DATABASE_NAME,
                              DDATE                                                                AS [DATE],
                            BATCHJOBID,
                            EXECUTION_COUNT AS EXECUTION_COUNT, 
                            (TOTAL_TIME) AS TOTAL_TIME,
                            ('D')                                                                AS FLAG --REH Mark the record as a DAILY record
                    FROM   (
                            
                              SELECT SERVER_NAME,
                                       DATABASE_NAME,
                                       dateadd(DAY,datediff(DAY,0,ENDDATETIME),0) AS DDATE,
                                       BATCHJOBID,
                                       COUNT(*) AS EXECUTION_COUNT,
                                       SUM(SECONDS) AS TOTAL_TIME

                               FROM   AX_BATCH_DETAILS
                               --REH STATS_TIME IS Dynperf local time, convert it to UTC TIME then convert it to local time for the server
                               WHERE  dateadd(DAY,datediff(DAY,0,ENDDATETIME),0) >= GETDATE()-2 --REH always do last 2 days to catch midnight
                                       AND SERVER_NAME = @SERVER_NAME
                               GROUP  BY SERVER_NAME,
                                            DATABASE_NAME,
                                            dateadd(DAY,datediff(DAY,0,ENDDATETIME),0),
                                            BATCHJOBID
                                            ) AS T1

                                 -----GROUP BY SERVER_NAME, 
                                 --DATABASE_NAME,
                                 --DDATE,
                                 --BATCHJOBID
                            ) AS source
           ON ( source.SERVER_NAME = target.SERVER_NAME
                 AND source.DATABASE_NAME = target.DATABASE_NAME
                 AND source.DATE = target.DATE
                 AND source.BATCHJOBID = target.BATCHJOBID

                 AND source.FLAG = target.FLAG )
           WHEN MATCHED THEN
             UPDATE SET EXECUTION_COUNT = source.EXECUTION_COUNT,
                            TOTAL_TIME = source.TOTAL_TIME
           WHEN NOT MATCHED THEN
             INSERT ( [SERVER_NAME],
                         [DATABASE_NAME],
                         [DATE],
                         [BATCHJOBID],
                         [EXECUTION_COUNT],
                         [TOTAL_TIME],
                         [FLAG] )
             VALUES (source.[SERVER_NAME],
                        source.[DATABASE_NAME],
                        source.[DATE],
                        source.[BATCHJOBID],
                        source.[EXECUTION_COUNT],
                        source.[TOTAL_TIME],
                        source.[FLAG]); 



                        SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT


--REH Rollup the daily total into the Monthly total
           MERGE AX_BATCH_HISTORY AS target
           USING (SELECT SERVER_NAME,
                              DATABASE_NAME,
                              DDATE                                                                AS [DATE],
                            BATCHJOBID,
                            EXECUTION_COUNT  AS EXECUTION_COUNT, 
                            (TOTAL_TIME) AS TOTAL_TIME,
                            ('M')                                                                AS FLAG --REH Mark the record as a DAILY record
                    FROM   (
                            
                              SELECT SERVER_NAME,
                                       DATABASE_NAME,
                                       DATEADD(MONTH,DATEDIFF(MONTH,0,DATE),0) AS DDATE,
                                       BATCHJOBID,
                                       COUNT(*) AS EXECUTION_COUNT,
                                       SUM(TOTAL_TIME) AS TOTAL_TIME

                               FROM   AX_BATCH_HISTORY 
                              WHERE  DATEADD(MONTH,DATEDIFF(MONTH,0,DATE),0) >= DATEADD(MONTH,DATEDIFF(MONTH,0,GETDATE())-1,0) 
                                 AND FLAG = 'D' --reh just adding up the DAY records to compute the MONTH record
                               GROUP  BY SERVER_NAME,
                                            DATABASE_NAME,
                                            DATEADD(MONTH,DATEDIFF(MONTH,0,DATE),0),
                                            BATCHJOBID
                                            ) AS T1

                                 --GROUP BY SERVER_NAME, 
                                 --DATABASE_NAME,
                                 --DDATE,
                                 --BATCHJOBID
                            ) AS source
           ON ( source.SERVER_NAME = target.SERVER_NAME
                 AND source.DATABASE_NAME = target.DATABASE_NAME
                 AND source.DATE = target.DATE
                 AND source.BATCHJOBID = target.BATCHJOBID
                 AND source.FLAG = target.FLAG )
           WHEN MATCHED THEN
             UPDATE SET EXECUTION_COUNT = source.EXECUTION_COUNT,
                            TOTAL_TIME = source.TOTAL_TIME
           WHEN NOT MATCHED THEN
             INSERT ( [SERVER_NAME],
                         [DATABASE_NAME],
                         [DATE],
                         [BATCHJOBID],
                         [EXECUTION_COUNT],
                         [TOTAL_TIME],
                         [FLAG] )
              VALUES (source.[SERVER_NAME],
                        source.[DATABASE_NAME],
                        source.[DATE],
                        source.[BATCHJOBID],
                        source.[EXECUTION_COUNT],
                        source.[TOTAL_TIME],
                        source.[FLAG]); 

        

SET @ROW_COUNT = @ROW_COUNT + @@ROWCOUNT
  

UPDATE CAPTURE_LOG
SET    TEXT = TEXT + 'SUCCESSFULLY '
              + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
              + ISNULL(@SERVER_NAME, '') + ' on database '
              + ISNULL(@DATABASE_NAME, '') + ' at '
              + CONVERT(VARCHAR, GETDATE(), 109) 
                   + ' Inserted ' + CAST(@ROW_COUNT AS VARCHAR(10)) + ' ROWS ' +  CHAR(10) 
WHERE  STATS_TIME = @STATS_DATE 
AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



PRINT ''
PRINT 'SUCCESSFULLY CAPTURED ' + ISNULL(@TASK_DESC, 'TASK')
PRINT ''


RETURN(0)  --REH RETURN SUCCESS


END TRY 


/********************************************************************************************************************************
*   END OF TASK
*********************************************************************************************************************************/


BEGIN CATCH
    UPDATE CAPTURE_LOG
    SET    TEXT = TEXT + 'FAILED !!! to '
            + ISNULL(@TASK_DESC, 'TASK') + ' for SERVER '
                  + ISNULL(@SERVER_NAME, '') + ' on database '
                  + ISNULL(@DATABASE_NAME, '') + ' at '
                  + CONVERT(VARCHAR, GETDATE(), 109) 
                        + ' ERROR = ' + CAST(@@ERROR AS VARCHAR(MAX))
                        + ', ' 
                        + CHAR(10)
    WHERE  STATS_TIME = @STATS_DATE
      AND TASK_TYPE = (SELECT TOP 1 TASK_TYPE FROM DYNPERF_TASK_SCHEDULER WHERE TASK_ID = @TASK_ID)



    PRINT 'ERROR WHILE COLLECTING '
          + ISNULL(@TASK_DESC, '') + ' !!!!!!!!!!!!!!'

    RETURN(1) --REH RETURN ERROR, TRAPPED BY SPROC
END CATCH

GO


PRINT N'Altering [dbo].[SP_LOCKS_MS]...';


GO



ALTER PROCEDURE [dbo].[SP_LOCKS_MS] @delay VARCHAR(10)
 AS
 
SET quoted_identifier OFF
--truncate table DynamicsPerf20..blocks  --delete all previous records
DECLARE  @cmd NVARCHAR(100)



/****** Object:  Table [dbo].[BLOCKS]    Script Date: 04/17/2012 14:10:13 ******/
IF  OBJECT_ID('tempdb..#BLOCKS') IS NOT NULL
          DROP TABLE [dbo].[#BLOCKS]



CREATE TABLE [dbo].[#BLOCKS](
    [SERVER_NAME] [nvarchar] (128) NULL, 
	[BLOCKED_DTTM] [datetime] NOT NULL,
	[BLOCKER_LOGIN] [nvarchar](128) NULL,
	[BLOCKER_PROGRAM] [nvarchar](128) NULL,
	[BLOCKER_HOSTNAME] [nvarchar](128) NULL,
	[BLOCKED_LOGIN] [nvarchar](128) NULL,
	[BLOCKED_PROGRAM] [nvarchar](128) NULL,
	[BLOCKED_HOSTNAME] [nvarchar](128) NULL,
	[BLOCKER_SESSION_ID] [smallint] NULL,
	[BLOCKER_CONTEXT_INFO] [binary](128) NULL,
	[BLOCKER_CONTEXT] [nvarchar](max) NULL,
	[BLOCKER_TRAN_ISOLATION] [varchar](20) NULL,
	[BLOCKER_STATUS] [varchar](18) NULL,
	[BLOCKED_SESSION_ID] [smallint] NULL,
	[BLOCKED_CONTEXT_INFO] [binary](128) NULL,
	[BLOCKED_CONTEXT] [nvarchar](max) NULL,
	[BLOCKED_TRAN_ISOLATION] [varchar](20) NULL,
	[TRANSACTION_ID] [bigint] NULL,
	[WAIT_TIME] [bigint] NULL,
	[LOCK_MODE] [nvarchar](60) NULL,
	[LOCK_SIZE] [nvarchar](6) NULL,
	[DATABASE_NAME] [nvarchar](128) NULL,
	[ALLOW_SNAPSHOT_ISOLATION] [nvarchar](60) NULL,
	[READ_COMMITTED_SNAPSHOT] [nvarchar](3) NULL,
	[OBJECT_NAME] [nvarchar](128) NULL,
	[INDEX_ID] [int] NULL,
	[BLOCKER_SQL] [nvarchar](max) NULL,
	[BLOCKER_PLAN] [xml] NULL,
	[BLOCKED_SQL] [nvarchar](max) NULL,
	[BLOCKED_PLAN] [xml] NULL
) ON [PRIMARY]

TOP_LOOP:
BEGIN TRY

TRUNCATE TABLE #BLOCKS

INSERT #BLOCKS
EXEC [SP_LOGBLOCKS_MS]



 MERGE DynamicsPerf..BLOCKS AS target
    USING (
SELECT 
    SERVER_NAME,
	BLOCKED_DTTM,
	BLOCKER_LOGIN			,
	BLOCKER_PROGRAM		,
	BLOCKER_HOSTNAME		,
	BLOCKED_LOGIN			,
	BLOCKED_PROGRAM		,
	BLOCKED_HOSTNAME		,
	BLOCKER_SESSION_ID		,
	BLOCKER_CONTEXT_INFO	,
	BLOCKER_CONTEXT			,
	BLOCKER_TRAN_ISOLATION	,
	BLOCKER_STATUS			,
	BLOCKED_SESSION_ID		,
	BLOCKED_CONTEXT_INFO	,
	BLOCKED_CONTEXT			,
	BLOCKED_TRAN_ISOLATION	,
	TRANSACTION_ID			,
	WAIT_TIME				,
	LOCK_MODE				,
	LOCK_SIZE				,
	DATABASE_NAME			,
	ALLOW_SNAPSHOT_ISOLATION,
	READ_COMMITTED_SNAPSHOT ,
	OBJECT_NAME				,
	INDEX_ID				,
	BLOCKER_SQL				,
			
	BLOCKER_PLAN = BLOCKER_PLAN	,
	BLOCKED_SQL = 	BLOCKED_SQL ,
	BLOCKED_PLAN =  BLOCKED_PLAN	
				
FROM	#BLOCKS
) as source

ON (source.TRANSACTION_ID = target.TRANSACTION_ID 
AND source.BLOCKED_SESSION_ID = target.BLOCKED_SESSION_ID 
AND source.BLOCKER_SESSION_ID = target.BLOCKER_SESSION_ID)

    WHEN MATCHED THEN 
        UPDATE SET WAIT_TIME = source.WAIT_TIME, BLOCKED_DTTM = source.BLOCKED_DTTM
	WHEN NOT MATCHED THEN	
	    INSERT (
		    [SERVER_NAME]
		   ,[BLOCKED_DTTM]
           ,[BLOCKER_LOGIN]
           ,[BLOCKER_PROGRAM]
           ,[BLOCKER_HOSTNAME]
           ,[BLOCKED_LOGIN]
           ,[BLOCKED_PROGRAM]
           ,[BLOCKED_HOSTNAME]
           ,[BLOCKER_SESSION_ID]
           ,[BLOCKER_CONTEXT_INFO]
           ,[BLOCKER_CONTEXT]
           ,[BLOCKER_TRAN_ISOLATION]
           ,[BLOCKER_STATUS]
           ,[BLOCKED_SESSION_ID]
           ,[BLOCKED_CONTEXT_INFO]
           ,[BLOCKED_CONTEXT]
           ,[BLOCKED_TRAN_ISOLATION]
           ,[TRANSACTION_ID]
           ,[WAIT_TIME]
           ,[LOCK_MODE]
           ,[LOCK_SIZE]
           ,[DATABASE_NAME]
           ,[ALLOW_SNAPSHOT_ISOLATION]
           ,[READ_COMMITTED_SNAPSHOT]
           ,[OBJECT_NAME]
           ,[INDEX_ID]
           ,[BLOCKER_SQL]
           ,[BLOCKER_PLAN]
           ,[BLOCKED_SQL]
           ,[BLOCKED_PLAN])
           
           VALUES (
		    source.[SERVER_NAME]
		   ,source.[BLOCKED_DTTM]
           ,source.[BLOCKER_LOGIN]
           ,source.[BLOCKER_PROGRAM]
           ,source.[BLOCKER_HOSTNAME]
           ,source.[BLOCKED_LOGIN]
           ,source.[BLOCKED_PROGRAM]
           ,source.[BLOCKED_HOSTNAME]
           ,source.[BLOCKER_SESSION_ID]
           ,source.[BLOCKER_CONTEXT_INFO]
           ,source.[BLOCKER_CONTEXT]
           ,source.[BLOCKER_TRAN_ISOLATION]
           ,source.[BLOCKER_STATUS]
           ,source.[BLOCKED_SESSION_ID]
           ,source.[BLOCKED_CONTEXT_INFO]
           ,source.[BLOCKED_CONTEXT]
           ,source.[BLOCKED_TRAN_ISOLATION]
           ,source.[TRANSACTION_ID]
           ,source.[WAIT_TIME]
           ,source.[LOCK_MODE]
           ,source.[LOCK_SIZE]
           ,source.[DATABASE_NAME]
           ,source.[ALLOW_SNAPSHOT_ISOLATION]
           ,source.[READ_COMMITTED_SNAPSHOT]
           ,source.[OBJECT_NAME]
           ,source.[INDEX_ID]
           ,source.[BLOCKER_SQL]
           ,source.[BLOCKER_PLAN]
           ,source.[BLOCKED_SQL]
           ,source.[BLOCKED_PLAN]);
           
   

END TRY
BEGIN CATCH
 --ignore the error
END catch
 
SELECT @cmd = 'waitfor delay ' +Quotename(@delay,'''')
EXEC sp_executesql @cmd

GOTO TOP_LOOP


ABORT:
RETURN(0)
GO
PRINT N'Refreshing [dbo].[DYNPERF_COLLECT_AX_AOTEXPORT_DATA]...';


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[DYNPERF_COLLECT_AX_AOTEXPORT_DATA]';


GO
PRINT N'Refreshing [dbo].[SP_DELETE_AOTEXPORT]...';


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[SP_DELETE_AOTEXPORT]';


GO
PRINT N'Refreshing [dbo].[SP_UPDATE_AOTEXPORT_DATA]...';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER OFF;


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[SP_UPDATE_AOTEXPORT_DATA]';


GO
SET ANSI_NULLS, QUOTED_IDENTIFIER ON;


GO
PRINT N'Refreshing [dbo].[DYNPERF_COLLECT_VIRTIALIO_DISKSTATS]...';


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[DYNPERF_COLLECT_VIRTIALIO_DISKSTATS]';


GO
PRINT N'Refreshing [dbo].[DYNPERF_COLLECT_AX_SYSGLOBALCONFIG]...';


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[DYNPERF_COLLECT_AX_SYSGLOBALCONFIG]';


GO
PRINT N'Refreshing [dbo].[DYNPERF_SERVER_ACTIVITY]...';


GO
EXECUTE sp_refreshsqlmodule N'[dbo].[DYNPERF_SERVER_ACTIVITY]';



------------------------------------------------------------------------------------------


GO
ALTER TABLE QUERY_PLANS SET (LOCK_ESCALATION = DISABLE)

GO

/****************************************************************************************************************************
INSERT PUGETABLE STUFF
*****************************************************************************************************************************/

TRUNCATE TABLE [DYNPERF_PURGETABLES]


INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('AX_BATCHJOB_DETAIL' ,'STATS_TIME', 1, 1,30) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('AX_BATCHSERVERGROUP_CONFIG' ,'STATS_TIME', 1, 1,30) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('AX_INDEX_DETAIL' ,'STATS_TIME', 1, 1,30) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('AX_LICENSEKEY_DETAIL' ,'STATS_TIME', 1, 1,30) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('AX_NUM_SEQUENCES' ,'STATS_TIME', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('AX_SERVER_CONFIG' ,'STATS_TIME', 1, 1,30) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('AX_SQLTRACE' ,'STATS_TIME', 1, 1,7) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('AX_TABLE_DETAIL' ,'STATS_TIME', 1, 1,7) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('AZURE_EVENTS' ,'STATS_TIME', 1, 1,90) 

INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('AX_BATCH_DETAILS' ,'ENDDATETIME', 1, 1,30)

INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('AX_BATCH_HISTORY' ,'DATE', 1, 1,720)  -- REH special handling on this table

-- HANDLED BY SPROC  INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('AX_SYSGLOBALCONFIGURATION' ,'STATS_TIME', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('BLOCKS' ,'BLOCKED_DTTM', 1, 1,7) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('BUFFER_DETAIL' ,'STATS_TIME', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('CAPTURE_LOG' ,'STATS_TIME', 0, 0,7) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('CDC' ,'STATS_TIME', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('CRM_ORGANIZATION' ,'STATS_TIME', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('CRM_PLUGINS' ,'STATS_TIME', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('CRM_POA_TOTALS' ,'STATS_TIME', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('DISKSTATS' ,'STATS_TIME', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('INDEX_DENSITY_VECTOR' ,'', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('INDEX_DETAIL' ,'STATS_TIME', 1, 1,2) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('INDEX_HISTOGRAM' ,'', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('INDEX_HISTORY' ,'DATE', 1, 1,999) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('INDEX_OPERATIONAL_STATS' ,'STATS_TIME', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('INDEX_PHYSICAL_STATS' ,'STATS_TIME', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('INDEX_STAT_HEADER' ,'', 1, 1,14)
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('INDEX_USAGE_STATS' ,'STATS_TIME', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('LOGINFO' ,'STATS_TIME', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('MISSING_INDEXES' ,'DATE_UPDATED', 1, 1,60) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('PERF_COUNTER_DATA' ,'STATS_TIME', 1, 1,7) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('QUERY_ALERTS' ,'STATS_TIME', 1, 1,7) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('QUERY_ALERTS_CONFIG' ,'', 1, 1,7) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('QUERY_HISTORY' ,'DATE', 1, 1,400) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('QUERY_PLANS' ,'DATE_UPDATED', 1, 1,60) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('QUERY_PLANS_PARSED' ,'', 1, 1,400) 

INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('QUERY_STATS' ,'STATS_TIME', 1, 1,2) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('QUERY_TEXT' ,' ', 1, 1,999) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SERVERINFO' ,'STATS_TIME', 1, 0,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SQL_AZURE_EVENTS' ,'END_TIME', 1, 1,14) 


INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SQL_DATABASE_SCOPECONFIG' ,'STATS_TIME', 1, 0,14) 

INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SQL_CONFIGURATION' ,'STATS_TIME', 1, 0,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SQL_AO_AVAILABILITY_GROUP_LISTENERS' ,'STATS_TIME', 1, 0,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SQL_AO_AVAILABILITY_GROUP_STATES' ,'STATS_TIME', 1, 0,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SQL_AO_AVAILABILITY_REPLICA_STATES' ,'STATS_TIME', 1, 0,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('[SQL_AO_AVAILABILITY_REPLICAS]' ,'STATS_TIME', 1, 0,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SQL_AO_AVAILABILITYGROUPS' ,'STATS_TIME', 1, 0,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SQL_AO_HADR_AVAILABILITY_REPLICA_CLUSTER_STATES' ,'STATS_TIME', 1, 0,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SQL_AO_HADR_DATABASE_REPLICA_STATES' ,'STATS_TIME', 1, 0,14) 




INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SQL_DATABASEFILES' ,'STATS_TIME', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SQL_DATABASES' ,'STATS_TIME', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SQL_JOBS' ,'STATS_TIME', 1, 0,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SQL_PLAN_GUIDES' ,'STATS_TIME', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SQL_REPLICATION' ,'STATS_TIME', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SQLERRORLOG' ,'LOGDATE', 1, 0,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SSRS_EXECUTIONLOG' ,'TIMEEND', 1, 0,60) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SSRS_HISTORY' ,'DATE', 1, 0,999)
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('STATS_COLLECTION_SUMMARY' ,'STATS_TIME', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('TRACEFLAGS' ,'STATS_TIME', 1, 1,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('TRIGGER_TABLE' ,'', 1, 1,14) 

INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('WAIT_STATS' ,'STATS_TIME', 1, 0,14) 
INSERT INTO [dbo].[DYNPERF_PURGETABLES]([TABLE_NAME],[TIME_COLUMN],[SERVER_NAME_FLAG],[DATABASE_NAME_FLAG],[RETENTION_DAYS])  VALUES ('SSRS_HISTORY' ,'REPORT_DATE', 1, 0,730)  





go


/****************************************************************************************************************************
INSERT sys.dm_os_performance_counters STUFF
*****************************************************************************************************************************/
TRUNCATE TABLE PERF_COUNTER_2_COLLECT
									--OBJECT NAME        COUNTER_NAME         INSTANCE
INSERT PERF_COUNTER_2_COLLECT VALUES('Buffer Manager', 'Page life expectancy', '')
INSERT PERF_COUNTER_2_COLLECT VALUES('Access Methods', 'Page Splits/sec', '')
INSERT PERF_COUNTER_2_COLLECT VALUES('Access Methods', 'Table Lock Escalations/sec', '')
INSERT PERF_COUNTER_2_COLLECT VALUES('Availability Replica', 'Bytes Sent to Replica/sec', '_Total')
INSERT PERF_COUNTER_2_COLLECT VALUES('Buffer Manager', 'Page reads/sec', '')
INSERT PERF_COUNTER_2_COLLECT VALUES('Buffer Manager', 'Page writes/sec', '')
INSERT PERF_COUNTER_2_COLLECT VALUES('Cursor Manager by Type', 'Active cursors', '_Total')
INSERT PERF_COUNTER_2_COLLECT VALUES('Cursor Manager by Type', 'Cursor memory usage', '_Total')
INSERT PERF_COUNTER_2_COLLECT VALUES('Databases', 'Transactions/sec', '_Total')
INSERT PERF_COUNTER_2_COLLECT VALUES('General Statistics', 'Processes blocked', '')
INSERT PERF_COUNTER_2_COLLECT VALUES('General Statistics', 'User Connections', '')


INSERT PERF_COUNTER_2_COLLECT VALUES('Locks', 'Average Wait Time (ms)', '_Total')
INSERT PERF_COUNTER_2_COLLECT VALUES('Locks', 'Average Wait Time Base', '_Total')

INSERT PERF_COUNTER_2_COLLECT VALUES('Locks', 'Number of Deadlocks/sec', '_Total')
INSERT PERF_COUNTER_2_COLLECT VALUES('Memory Manager', 'Free Memory (KB)', '')
INSERT PERF_COUNTER_2_COLLECT VALUES('Memory Manager', 'Lock Memory (KB)', '')
INSERT PERF_COUNTER_2_COLLECT VALUES('Memory Manager', 'Target Server Memory (KB)', '')
INSERT PERF_COUNTER_2_COLLECT VALUES('Memory Manager', 'Total Server Memory (KB)', '')
INSERT PERF_COUNTER_2_COLLECT VALUES('Plan Cache', 'Cache Pages', '_Total')
INSERT PERF_COUNTER_2_COLLECT VALUES('SQL Statistics', 'Batch Requests/sec', '')
INSERT PERF_COUNTER_2_COLLECT VALUES('SQL Statistics', 'Guided plan executions/sec', '')
INSERT PERF_COUNTER_2_COLLECT VALUES('SQL Statistics', 'SQL Compilations/sec', '')
INSERT PERF_COUNTER_2_COLLECT VALUES('SQL Statistics', 'SQL Re-Compilations/sec', '')
INSERT PERF_COUNTER_2_COLLECT VALUES('Transactions', 'Free Space in tempdb (KB)', '')
INSERT PERF_COUNTER_2_COLLECT VALUES('Transactions', 'Version Store Size (KB)', '')

                                                                                                         



INSERT PERF_COUNTER_2_COLLECT VALUES('Wait Statistics', 'Network IO waits', 'Average wait time (ms)')
INSERT PERF_COUNTER_2_COLLECT VALUES('Wait Statistics', 'Page IO latch waits', 'Average wait time (ms)')
INSERT PERF_COUNTER_2_COLLECT VALUES('Wait Statistics', 'Page latch waits', 'Average wait time (ms)')
INSERT PERF_COUNTER_2_COLLECT VALUES('Wait Statistics', 'Network IO waits', 'Cumulative wait time (ms) per second')
INSERT PERF_COUNTER_2_COLLECT VALUES('Wait Statistics', 'Page IO latch waits', '')
INSERT PERF_COUNTER_2_COLLECT VALUES('Wait Statistics', 'Page latch waits', 'Cumulative wait time (ms) per second')




--INSERT PERF_COUNTER_2_COLLECT VALUES('', '', '')












/***************************************************************************
*
* 3/2/2012  REH   Turn on row compression for all DynamicsPerf indexes
*                   if compression is supported
*
*
****************************************************************************/
IF  (cast(serverproperty('Edition') as varchar(100)) like 'Enterprise%' or cast(serverproperty('Edition') as varchar(100)) like 'Developer%')
BEGIN
		DECLARE @INDEX_NAME SYSNAME
		DECLARE @TABLE_NAME SYSNAME
		DECLARE @SQL VARCHAR(MAX)


		DECLARE INDEXCURSOR CURSOR FOR
			SELECT	
					si.name, 
					so.name
			FROM	DynamicsPerf.sys.indexes si
			JOIN	DynamicsPerf.sys.sysindexes ii on si.object_id = ii.id and si.index_id = ii.indid
			JOIN	DynamicsPerf.sys.objects so on so.object_id = si.object_id
			JOIN	DynamicsPerf.sys.schemas ss on ss.schema_id = so.schema_id
			WHERE	so.type = 'U'
			AND		si.type > 0  --other than heap tables
			
			OPEN INDEXCURSOR

		FETCH INDEXCURSOR INTO 
			@INDEX_NAME		,
			@TABLE_NAME		
			
			
		WHILE @@FETCH_STATUS = 0
			BEGIN
			
			--Need page compression on this table to get maximum space savings
			IF @TABLE_NAME = 'SQLErrorLog'
			BEGIN
			SELECT @SQL = 'ALTER INDEX [' + @INDEX_NAME + '] ON ' + @TABLE_NAME + 
			' REBUILD WITH (DATA_COMPRESSION = PAGE)'
			END
			ELSE
			BEGIN
			SELECT @SQL = 'ALTER INDEX [' + @INDEX_NAME + '] ON ' + @TABLE_NAME + 
			' REBUILD WITH (DATA_COMPRESSION = ROW)'
			END
			
			EXEC (@SQL)
			
			FETCH NEXT FROM INDEXCURSOR INTO @INDEX_NAME,@TABLE_NAME
			END
			
			CLOSE INDEXCURSOR
			DEALLOCATE INDEXCURSOR
			
			
			--REH Compress the QUERY_PLANS table that we removed the clustered index on
			ALTER TABLE dbo.QUERY_PLANS  REBUILD WITH ( DATA_COMPRESSION = ROW )
END


/*************************** START OF SQL JOBS ******************************************/

USE [msdb]
GO
--REH  Delete old jobs that we renamed

/****** Object:  Job [DYNPERF_Log_Blocks_Option1_Tracing]    Script Date: 10/10/2010 14:34:59 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Log_Blocks_Option1_Tracing_Start')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Log_Blocks_Option1_Tracing_Start', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_Log_Blocks_Option1_Tracing_Stop]    Script Date: 10/10/2010 15:24:21 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Log_Blocks_Option1_Tracing_Stop')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Log_Blocks_Option1_Tracing_Stop', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_Log_Blocks_Option1_Load_Blocked_Data]    Script Date: 12/16/2010 11:22:48 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Log_Blocks_Option1_Load_Blocked_Data')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Log_Blocks_Option1_Load_Blocked_Data', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_Log_Blocks_Option2_Polling]    Script Date: 10/10/2010 14:36:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Log_Blocks_Option2_Polling')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Log_Blocks_Option2_Polling', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_Option1_Tracing_Start]    Script Date: 10/19/2011 15:23:06 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Option1_Tracing_Start')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Option1_Tracing_Start', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_Log_Blocks_Option1_Tracing_Stop]    Script Date: 10/10/2010 15:24:21 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Option1_Tracing_Stop')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Option1_Tracing_Stop', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_Log_Blocks_Option1_Load_Blocked_Data]    Script Date: 12/16/2010 11:22:48 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Option1_Load_Blocked_Data')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Option1_Load_Blocked_Data', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_Log_Blocks_Option2_Polling]    Script Date: 10/10/2010 14:36:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Option2_Polling_for_Blocking')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Option2_Polling_for_Blocking', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_Log_Blocks_Option2_Polling]    Script Date: 10/10/2010 14:36:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Option2_Polling_for_Blocking')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Option2_Polling_for_Blocking', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_PerfStats_Hourly]    Script Date: 03/13/2011 13:38:20 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_PerfStats_Hourly')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_PerfStats_Hourly', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_Capture_Stats_Purge]    Script Date: 02/18/2010 11:38:53 ******/
IF EXISTS (SELECT job_id FROM   msdb.dbo.sysjobs_view WHERE  name = N'DYNPERF_Capture_Stats_Purge')
EXEC msdb.dbo.sp_delete_job  @job_name=N'DYNPERF_Capture_Stats_Purge',  @delete_unused_schedule=1 
GO 
IF EXISTS (SELECT job_id FROM   msdb.dbo.sysjobs_view WHERE  name = N'DYNPERF_Compression_Analyzer')
  EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Compression_Analyzer', @delete_unused_schedule=1
GO    

/****** Object:  Job [DYNPERF_Purge_Stats]    Script Date: 10/10/2010 14:36:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Purge_Stats')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Purge_Stats', @delete_unused_schedule=1
GO

/****** Object:  Job [DYNPERF_Default_Trace_Start]    Script Date: 04/26/2012 19:26:53 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Detailed_Trace')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Detailed_Trace', @delete_unused_schedule=1
GO

IF EXISTS (SELECT job_id FROM   msdb.dbo.sysjobs_view  WHERE  name = N'DYNPERF_Purge_Blocks')
  EXEC msdb.dbo.sp_delete_job @job_name = N'DYNPERF_Purge_Blocks', @delete_unused_schedule=1
GO
IF EXISTS (SELECT job_id FROM   msdb.dbo.sysjobs_view WHERE  name = N'DYNPERF_Capture_Stats_Purge')
  EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Capture_Stats_Purge', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_Capture_Stats_Baseline]    Script Date: 03/18/2014 21:27:20 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Capture_Stats_Baseline')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Capture_Stats_Baseline', @delete_unused_schedule=1
GO


--REH deleting lowercased named ones on Case Sensitive systems
/****** Object:  Job [DYNPERF_Capture_Stats]    Script Date: 02/18/2010 11:38:20 ******/ --REH converted to UPPERCASE
IF EXISTS (SELECT job_id FROM   msdb.dbo.sysjobs_view   WHERE  name = N'DYNPERF_Capture_Stats')
EXEC msdb.dbo.sp_delete_job  @job_name=N'DYNPERF_Capture_Stats',  @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_Default_Trace_Start]    Script Date: 10/19/2011 15:23:06 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Default_Trace_Start')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Default_Trace_Start', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_Default_Trace_Stop]    Script Date: 10/10/2010 15:24:21 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Default_Trace_Stop')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Default_Trace_Stop', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_LONG_DURATION_TRACE]    Script Date: 04/26/2012 19:26:53 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Long_Duration_Trace')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Long_Duration_Trace', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_Log_Blocks_Option2_Polling]    Script Date: 10/10/2010 14:36:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Optional_Polling_for_Blocking')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Optional_Polling_for_Blocking', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_Purge_SYSTRACETABLESQL_AX]    Script Date: 10/19/2011 16:21:00 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Purge_SYSTRACETABLESQL_AX')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Purge_SYSTRACETABLESQL_AX', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_Set_AX_User_Trace_on]    Script Date: 04/01/2014 08:20:00 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Set_AX_User_Trace_on')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Set_AX_User_Trace_on', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_Set_AX_User_Trace_off]    Script Date: 04/01/2014 08:21:23 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_Set_AX_User_Trace_off')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_Set_AX_User_Trace_off', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_SET_AX_USER_TRACE_ON]    Script Date: 04/01/2014 08:20:00 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_SET_AX_USER_TRACE_ON')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_SET_AX_USER_TRACE_ON', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_SET_AX_USER_TRACE_OFF]    Script Date: 04/01/2014 08:21:23 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_SET_AX_USER_TRACE_OFF')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_SET_AX_USER_TRACE_OFF', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_PURGE_SYSTRACETABLESQL_AX]    Script Date: 10/19/2011 16:21:00 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_PURGE_SYSTRACETABLESQL_AX')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_PURGE_SYSTRACETABLESQL_AX', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_DEFAULT_TRACE_START]    Script Date: 10/19/2011 15:23:06 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_DEFAULT_TRACE_START')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_DEFAULT_TRACE_START', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_DEFAULT_TRACE_STOP]    Script Date: 10/10/2010 15:24:21 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_DEFAULT_TRACE_STOP')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_DEFAULT_TRACE_STOP', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_LONG_DURATION_TRACE]    Script Date: 04/26/2012 19:26:53 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_LONG_DURATION_TRACE')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_LONG_DURATION_TRACE', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_Log_Blocks_Option2_Polling]    Script Date: 10/10/2010 14:36:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_OPTIONAL_POLLING_FOR_BLOCKING')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_OPTIONAL_POLLING_FOR_BLOCKING', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_COLLECT_AOS_CONFIG]    Script Date: 09/19/2015 07:23:26 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_CAPTURE_SRS')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_CAPTURE_SRS', @delete_unused_schedule=1
GO
/****** Object:  Job [DYNPERF_COLLECT_AOS_CONFIG]    Script Date: 09/19/2015 07:23:26 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_CAPTURE_SSRS')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_CAPTURE_SSRS', @delete_unused_schedule=1
GO



USE [msdb]
GO
/****** Object:  Job [DYNPERF_CAPTURE_STATS]    Script Date: 02/18/2010 11:38:20 ******/
IF EXISTS (SELECT job_id FROM   msdb.dbo.sysjobs_view  WHERE  name = N'DYNPERF_CAPTURE_STATS')
  EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_CAPTURE_STATS',  @delete_unused_schedule=1
 GO 

USE [msdb]
GO

/****** Object:  Job [DYNPERF_CAPTURE_STATS]    Script Date: 09/20/2015 19:31:09 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 09/20/2015 19:31:09 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DYNPERF_CAPTURE_STATS', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Capture DMV Data for performance analysis, daily', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [sp_capturestats]    Script Date: 09/20/2015 19:31:10 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'sp_capturestats', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- THE COMMENTED CODE IS FOR USE 
-- WHEN INSTALLING DYNAMICSPERF INTO AN 
-- ALWAYS ON AVAILABILITY GROUP

--JUST COPY THE JOBS FROM THE SERVER YOU INSTALL INTO 
-- TO THE SECONDARY NODE

/*

IF (SELECT ars.role_desc FROM sys.dm_hadr_availability_replica_states ars
	INNER JOIN sys.availability_groups ag ON ars.group_id = ag.group_id
    WHERE 
	ag.name = ''YOUR_LISTNER_NAME''
	AND ars.is_local=1
    ) = ''PRIMARY''

BEGIN

*/

EXEC  SP_CAPTURESTATS

/*
END
*/', 
		@database_name=N'DynamicsPerf', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'5 MINUTES', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=5, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20101008, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO






USE [msdb]
GO
/****** Object:  Job [DYNPERF_PROCESS_TASKS]    Script Date: 02/18/2010 11:38:20 ******/
IF EXISTS (SELECT job_id
           FROM   msdb.dbo.sysjobs_view
           WHERE  name = N'DYNPERF_PROCESS_TASKS')
  EXEC msdb.dbo.sp_delete_job
    @job_name=N'DYNPERF_PROCESS_TASKS',
    @delete_unused_schedule=1

GO 

USE [msdb]
GO

/****** Object:  Job [DYNPERF_PROCESS_TASKS]    Script Date: 10/10/2010 14:25:48 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 10/10/2010 14:25:48 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DYNPERF_PROCESS_TASKS', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Run Processing tasks in DynamicsPerf Database', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [sp_capturestats]    Script Date: 10/10/2010 14:25:48 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SP_PROCESS_STATS', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- THE COMMENTED CODE IS FOR USE 
-- WHEN INSTALLING DYNAMICSPERF INTO AN 
-- ALWAYS ON AVAILABILITY GROUP

--JUST COPY THE JOBS FROM THE SERVER YOU INSTALL INTO 
-- TO THE SECONDARY NODE

/*

IF (SELECT ars.role_desc FROM sys.dm_hadr_availability_replica_states ars
	INNER JOIN sys.availability_groups ag ON ars.group_id = ag.group_id
    WHERE 
	ag.name = ''YOUR_LISTNER_NAME''
	AND ars.is_local=1
    ) = ''PRIMARY''

BEGIN

*/

EXEC SP_PROCESS_STATS

/*
END
*/	 ', 
		@database_name=N'DynamicsPerf', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'EVERY 5 MINUTES', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=5, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20101008, 
		@active_end_date=99991231, 
		@active_start_time=100, 
		@active_end_time=235959

IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO




USE [msdb]
GO
/****** Object:  Job [DYNPERF_PROCESS_TASKS_LOW_PRIORITY]    Script Date: 02/18/2010 11:38:20 ******/
IF EXISTS (SELECT job_id
           FROM   msdb.dbo.sysjobs_view
           WHERE  name = N'DYNPERF_PROCESS_TASKS_LOW_PRIORITY')
  EXEC msdb.dbo.sp_delete_job
    @job_name=N'DYNPERF_PROCESS_TASKS_LOW_PRIORITY',
    @delete_unused_schedule=1

GO 

USE [msdb]
GO

/****** Object:  Job [DYNPERF_PROCESS_TASKS_LOW_PRIORITY]    Script Date: 10/10/2010 14:25:48 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 10/10/2010 14:25:48 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DYNPERF_PROCESS_TASKS_LOW_PRIORITY', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Run Processing tasks in DynamicsPerf Database', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [sp_capturestats]    Script Date: 10/10/2010 14:25:48 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SP_PROCESS_STATS_LOW_PRIORITY', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- THE COMMENTED CODE IS FOR USE 
-- WHEN INSTALLING DYNAMICSPERF INTO AN 
-- ALWAYS ON AVAILABILITY GROUP

--JUST COPY THE JOBS FROM THE SERVER YOU INSTALL INTO 
-- TO THE SECONDARY NODE

/*

IF (SELECT ars.role_desc FROM sys.dm_hadr_availability_replica_states ars
	INNER JOIN sys.availability_groups ag ON ars.group_id = ag.group_id
    WHERE 
	ag.name = ''YOUR_LISTNER_NAME''
	AND ars.is_local=1
    ) = ''PRIMARY''

BEGIN

*/

EXEC SP_PROCESS_STATS_LOW_PRIORITY	

/*
END
*/ ', 
		@database_name=N'DynamicsPerf', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'EVERY 5 MINUTES', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=5, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20101008, 
		@active_end_date=99991231, 
		@active_start_time=100, 
		@active_end_time=235959

IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO





USE [msdb]
GO

/****** Object:  Job [DYNPERF_COLLECT_AOS_CONFIG]    Script Date: 09/19/2015 07:23:26 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_COLLECT_AOS_CONFIG')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_COLLECT_AOS_CONFIG', @delete_unused_schedule=1
GO

USE [msdb]
GO

IF (SELECT SERVERPROPERTY('PRODUCTVERSION')) < '13.'
BEGIN

/****** Object:  Job [DYNPERF_COLLECT_AOS_CONFIG]    Script Date: 09/19/2015 07:23:26 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 09/19/2015 07:23:26 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DYNPERF_COLLECT_AOS_CONFIG', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [COLLECT AOS CONFIG]    Script Date: 09/19/2015 07:23:26 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'COLLECT AOS CONFIG', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'ActiveScripting', 
	@command=N'strSQLInstance = "PROD_SQL"
strAXDataBase = "PROD_DB"

strSQLInstanceDPA = "DP_SQL"
strDataBaseDPA = "DynamicsPerf"


Const HKLM          = &H80000002
Const adInteger     = 3
Const adVarWChar    = 202
Const adlongVarWChar= 203
Const adParamInput  = &H0001
Const adCmdText     = &H0001
const REG_SZ        = 1
const REG_EXPAND_SZ = 2
const REG_BINARY    = 3
const REG_DWORD     = 4
const REG_MULTI_SZ  = 7

Dim objConnection
Dim objRecordset
Dim objCommandEvt
Dim objCommandReg


Dim objConnectionDPA
Dim objRecordsetDPA
Dim objCommandEvtDPA
Dim objCommandRegDPA



Dim prmEvt1
Dim prmEvt2
Dim prmEvt3
Dim prmEvt4
Dim prmEvt5
Dim prmEvt6

Dim prmReg1
Dim prmReg2
Dim prmReg3
Dim prmReg4
Dim prmReg5
Dim prmReg6
Dim prmReg7
Dim prmReg8


Dim strAOS
Dim strRecordset

strRecordset = "SELECT DISTINCT SUBSTRING(SERVERID,(CHARINDEX(''@'',SERVERID)+1), (LEN(SERVERID)-CHARINDEX(''@'',SERVERID)))FROM SYSSERVERCONFIG"

Set objConnection=CreateObject("ADODB.Connection") 
Set objRecordset=CreateObject("ADODB.Recordset")
set objCommandEvt=CreateObject("ADODB.command")
set objCommandReg=CreateObject("ADODB.command")


Set objConnectionDPA=CreateObject("ADODB.Connection") 
Set objRecordsetDPA=CreateObject("ADODB.Recordset")
set objCommandEvtDPA=CreateObject("ADODB.command")
set objCommandRegDPA=CreateObject("ADODB.command")




objConnection.Provider="SQLOLEDB"
objConnection.Properties("Data Source").Value = strSQLInstance
objConnection.Properties("Initial Catalog").Value = strAXDatabase
objConnection.Properties("Integrated Security").Value = "SSPI"

objConnection.Open


objConnectionDPA.Provider="SQLOLEDB"
objConnectionDPA.Properties("Data Source").Value = strSQLInstanceDPA
objConnectionDPA.Properties("Initial Catalog").Value = strDatabaseDPA
objConnectionDPA.Properties("Integrated Security").Value = "SSPI"

objConnectionDPA.Open



objCommandEvtDPA.ActiveConnection=objConnectionDPA
objCommandEvtDPA.CommandType=adCmdText
objCommandEvtDPA.CommandText="INSERT INTO DynamicsPerf..AOS_EVENTLOG VALUES (?,?,?,?,?,?)"

Set prmEvt1=objCommandEvtDPA.CreateParameter ("", adVarWChar,adParamInput,23)
Set prmEvt2=objCommandEvtDPA.CreateParameter ("", adVarWChar,adParamInput,255)
Set prmEvt3=objCommandEvtDPA.CreateParameter ("", adInteger,adParamInput)
Set prmEvt4=objCommandEvtDPA.CreateParameter ("", adVarWChar,adParamInput,255)
Set prmEvt5=objCommandEvtDPA.CreateParameter ("", adlongVarWChar,adParamInput,32768)
Set prmEvt6=objCommandEvtDPA.CreateParameter ("", adVarWChar,adParamInput,255)

objCommandEvtDPA.Parameters.Append prmEvt1
objCommandEvtDPA.Parameters.Append prmEvt2
objCommandEvtDPA.Parameters.Append prmEvt3
objCommandEvtDPA.Parameters.Append prmEvt4
objCommandEvtDPA.Parameters.Append prmEvt5
objCommandEvtDPA.Parameters.Append prmEvt6

objCommandRegDPA.ActiveConnection=objConnectionDPA
objCommandRegDPA.CommandType=adCmdText
objCommandRegDPA.CommandText="INSERT INTO DynamicsPerf..AOS_REGISTRY VALUES (?,?,?,?,?,?,?,?)"

Set prmReg1=objCommandRegDPA.CreateParameter ("", adVarWChar,adParamInput,255)
Set prmReg2=objCommandRegDPA.CreateParameter ("", adVarWChar,adParamInput,5)
Set prmReg3=objCommandRegDPA.CreateParameter ("", adVarWChar,adParamInput,255)
Set prmReg4=objCommandRegDPA.CreateParameter ("", adVarWChar,adParamInput,25)
Set prmReg5=objCommandRegDPA.CreateParameter ("", adVarWChar,adParamInput,255)
Set prmReg6=objCommandRegDPA.CreateParameter ("", adVarWChar,adParamInput,1)
Set prmReg7=objCommandRegDPA.CreateParameter ("", adVarWChar,adParamInput,255)
Set prmReg8=objCommandRegDPA.CreateParameter ("", adVarWChar,adParamInput,8000)

objCommandRegDPA.Parameters.Append prmReg1
objCommandRegDPA.Parameters.Append prmReg2
objCommandRegDPA.Parameters.Append prmReg3
objCommandRegDPA.Parameters.Append prmReg4
objCommandRegDPA.Parameters.Append prmReg5
objCommandRegDPA.Parameters.Append prmReg6
objCommandRegDPA.Parameters.Append prmReg7
objCommandRegDPA.Parameters.Append prmReg8

objConnectionDPA.Execute "SET DATEFORMAT MDY"
objConnectionDPA.Execute "TRUNCATE TABLE DynamicsPerf..AOS_EVENTLOG"
objConnectionDPA.Execute "TRUNCATE TABLE DynamicsPerf..AOS_REGISTRY"

objRecordset.Open strRecordset, objConnection


Do While Not objRecordset.EOF


				strAOS =  objRecordset.Fields(0) 


				On Error Resume Next

				Set objWMIService = GetObject("winmgmts:{impersonationLevel=impersonate}!\\" & strAOS & "\root\cimv2")
				if Err.Number <> 0 then
							set objWMIService = nothing
							err.clear
				Else
				Set objWMIService = Nothing


				AOSevt(strAOS)
				AOSreg(strAOS)

		end IF
		on error goto 0
		objRecordset.MoveNext 
Loop

Set objConnection=nothing
Set objRecordset=nothing
set objCommandEvt=nothing
set objCommandReg=nothing


Set objConnectionDPA=nothing
Set objRecordsetDPA=nothing
set objCommandEvtDPA=nothing
set objCommandRegDPA=nothing



Sub AOSevt(strAOS)
  
    Const CONVERT_TO_LOCAL_TIME = True
    Set dtmStartDate = CreateObject("WbemScripting.SWbemDateTime")
    DateToCheck = CDate(DATE - 14)
    dtmStartDate.SetVarDate DateToCheck, CONVERT_TO_LOCAL_TIME
    Set objWMIService = GetObject("winmgmts:{impersonationLevel=impersonate}!\\" & strAOS & "\root\cimv2")
    Set colLoggedEvents = objWMIService.ExecQuery _
	    ("Select * from Win32_NTLogEvent Where Logfile = ''Application'' and (eventtype = 1 or eventtype = 2 or (eventtype = 3 and eventcode = 149)) and  TimeWritten >= ''" & dtmStartDate & "''")
    For Each objEvent in colLoggedEvents
        prmEvt1.value=cUTC2Lt(objEvent.TimeWritten)
        prmEvt2.value=objEvent.ComputerName
        prmEvt3.value=objEvent.EventCode
        prmEvt4.value=objEvent.Type
        prmEvt5.value=left(objEvent.Message, 256)
        prmEvt6.value=objEvent.SourceName
        objCommandEvtDPA.Execute
    Next	
End Sub

Sub AOSreg(strAOS)
    Const HKLM = &H80000002
    Set ObjReg=GetObject("winmgmts:{impersonationLevel=impersonate}!\\" & StrAOS & "\root\default:StdRegProv")
    StrKeyPath = "System\CurrentControlSet\Services\Dynamics Server"
    ObjReg.EnumKey HKLM, StrKeyPath, ArrVersions
    For Each StrVersion In ArrVersions
        ObjReg.EnumKey HKLM, StrKeyPath & "\" & StrVersion, ArrInstances
        If IsArray(ArrInstances) Then
            For Each StrInstance In ArrInstances 
                objReg.GetStringValue HKLM, StrKeyPath & "\" & StrVersion & "\" & StrInstance, "InstanceName", strInstanceName 
                objReg.GetStringValue HKLM, StrKeyPath & "\" & StrVersion & "\" & StrInstance, "Current", strCurrentConfig 
                objReg.GetStringValue HKLM, StrKeyPath & "\" & StrVersion & "\" & StrInstance, "ProductVersion", strProductVersion 
                ObjReg.EnumKey HKLM, StrKeyPath & "\" & StrVersion & "\" & StrInstance, ArrConfigs
                    For Each StrConfig In ArrConfigs
                        If StrConfig = StrCurrentConfig Then
                            strActive = "Y"
                        Else
                            strActive = "N"
                        End if
                        ObjReg.EnumValues HKLM, StrKeyPath & "\" & StrVersion & "\" & StrInstance & "\" & StrConfig, ArrValueNames,  ArrValueTypes
                        For I=0 To UBound(arrValueNames) 
                            StrValueName = arrValueNames(I)           
                            Select Case arrValueTypes(I)
                                Case REG_SZ
                                    objReg.GetStringValue HKLM, StrKeyPath & "\" & StrVersion & "\" & StrInstance & "\" & StrConfig, strValueName, strValue
                                Case REG_EXPAND_SZ
                                    objReg.GetExpandedStringValue HKLM, StrKeyPath & "\" & StrVersion & "\" & StrInstance & "\" & StrConfig, strValueName, strValue
                                Case REG_BINARY
                                     objReg.GetBinaryValue  HKLM, StrKeyPath & "\" & StrVersion & "\" & StrInstance & "\" & StrConfig, strValueName, strValue
                                Case REG_DWORD
                                     objReg.GetDWORDValue HKLM, StrKeyPath & "\" & StrVersion & "\" & StrInstance & "\" & StrConfig, strValueName, strValue
                                Case REG_MULTI_SZ
                                     objReg.GetMultiStringValue  HKLM, StrKeyPath & "\" & StrVersion & "\" & StrInstance & "\" & StrConfig, strValueName, strValue
                            End Select        
                            prmReg1.value=StrAOS
                            prmReg2.value=StrVersion
                            prmReg3.value=strInstanceName
                            prmReg4.value=StrProductVersion
                            prmReg5.value=StrConfig
                            prmReg6.value=strActive
                            prmReg7.value=StrValueName
                            prmReg8.value=StrValue
                            objCommandRegDPA.Execute
                        Next
                    Next
            Next
        End If
    Next
End Sub

Function cUTC2Lt(WMITime)
''   Convert UTC Time from Event Log to DateTime format compatible with SQL Server DateTime data type
   	Dim strDate, strTime
   	Dim yyyy : yyyy = left(WMITime,4) ''year
   	Dim mm   : mm = mid(WMITime,5,2)  ''month
   	Dim dd   : dd = mid(WMITime,7,2)  ''day
   	Dim hh   : hh = mid(WMITime,9,2)  ''hour
   	Dim mn   : mn = mid(WMITime,11,2) ''minutes
   	Dim ss   : ss = mid(WMITime,13,2) ''seconds
   	Dim ms   : ms = mid(WMITime,16,6) ''microseconds
 ''  	strDate = mm & "-" & dd & "-" & yyyy
	strDate = yyyy & "-" & mm & "-" & dd
      	strTime = hh & ":" & mn & ":" & ss
      	cUTC2Lt = strDate & " " & strTime
End Function


', 
		@database_name=N'VBScript', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DAILY', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20150919, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=235959

IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:


END

GO


/****** Object:  Job [DYNPERF_COLLECT_AOS_CONFIG]    Script Date: 09/19/2015 07:23:26 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DYNPERF_CAPTURE_SSRS')
EXEC msdb.dbo.sp_delete_job @job_name=N'DYNPERF_CAPTURE_SSRS', @delete_unused_schedule=1
GO

USE [msdb]
GO

/****** Object:  Job [DYNPERF_CAPTURE_SSRS]    Script Date: 06/22/2016 07:07:55 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 06/22/2016 07:07:55 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DYNPERF_CAPTURE_SSRS', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Capture SSRS EXECUTIONLOG2 for performance analysis', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DYNPERF_COLLECT_SSRS_EXECUTIONLOG]    Script Date: 06/22/2016 07:07:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DYNPERF_COLLECT_SSRS_EXECUTIONLOG', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=2, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
		-- THE COMMENTED CODE IS FOR USE 
-- WHEN INSTALLING DYNAMICSPERF INTO AN 
-- ALWAYS ON AVAILABILITY GROUP

--JUST COPY THE JOBS FROM THE SERVER YOU INSTALL INTO 
-- TO THE SECONDARY NODE

/*

IF (SELECT ars.role_desc FROM sys.dm_hadr_availability_replica_states ars
	INNER JOIN sys.availability_groups ag ON ars.group_id = ag.group_id
    WHERE 
	ag.name = ''YOUR_LISTNER_NAME''
	AND ars.is_local=1
    ) = ''PRIMARY''

BEGIN

*/


EXEC  DYNPERF_COLLECT_SSRS_EXECUTIONLOG @DEBUG = ''N''

/*
END
*/

', 
		@database_name=N'DynamicsPerf', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DYNPERF_ROLLUP_SSRS_HISTORY]    Script Date: 06/22/2016 07:07:55 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DYNPERF_ROLLUP_SSRS_HISTORY', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DYNPERF_UPDATE_SSRS_HISTORY @DEBUG = ''N''', 
		@database_name=N'DynamicsPerf', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'5 MINUTES', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=5, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20101008, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959

IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


USE [DynamicsPerf]
GO
GRANT EXECUTE ON SP_DELETE_AOTEXPORT TO PUBLIC
GO
GRANT EXECUTE ON DYNPERF_SERVER_ACTIVITY TO PUBLIC
GO


/********************** END OF SQL JOBS ***********************************/






--Insert  blank record for Dynamics AX cursors, so we only have 1 plan for fetch api_cursor calls  otherwise we'll insert a plan for every fetch api_cursor sitting in procedure cache
--     this record will be deleted after a week by the purge_stats job if it's not needed.
--INSERT INTO [DynamicsPerf]..QUERY_PLANS VALUES(0x0000000000000000,'<ShowPlanXML xmlns="http://schemas.microsoft.com/sqlserver/2004/07/showplan" Version="1.1" Build="10.50.1765.0"><BatchSequence><Batch><Statements><StmtCursor StatementText="FETCH API_CURSOR Look for another QUERY_STATS record with a creation time close to this record" StatementId="1" StatementCompId="9" StatementType="FETCH CURSOR"><CursorPlan CursorName="API_CURSOR00000000000000B3" /></StmtCursor></Statements></Batch></BatchSequence></ShowPlanXML>','',0)



PRINT '-----------------------------------------------------------------------------------------'
PRINT '-- Be sure to complete Steps 2-10 as appropriate in the Simple Installation.txt							'
PRINT '-----------------------------------------------------------------------------------------'
PRINT ''
PRINT '-----------------------------------------------------------------------------------------'
PRINT '-- 												'
PRINT '-- PLEASE VISIT HTTP://BLOGS.MSDN.COM/AXINTHEFIELD  for details on this tool			'
PRINT '-- 												'
PRINT '-----------------------------------------------------------------------------------------'


-- Default back to collecting hourly



USE [DynamicsPerf]
GO


/************************************************************************

CORE_SCHEDULE
AX_SCHEDULE
CRM_SCHEDULE

*************************************************************************/

--REH populate the scheduling tables 
/****************************************

CORE_SCHEDULE

These are the core tasks for all databases
*****************************************/


USE [DynamicsPerf]
GO


/************************************************************************

CORE_SCHEDULE
AX_SCHEDULE
CRM_SCHEDULE

*************************************************************************/

--REH populate the scheduling tables 
/****************************************

CORE_SCHEDULE

These are the core tasks for all databases
*****************************************/




TRUNCATE TABLE DYNPERF_TASK_SCHEDULER
TRUNCATE TABLE DYNPERF_TASK_HISTORY

-- Enabled, Dynamics Product, Sproc Name, Sproc Parms, Task Desc, Sched Units, Sched qty, Sched time, Azure, Linked Server , Server level task, Task group


INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_QUERY_STATS', NULL, 'Collect QUERY_STATS for database','HH',1,NULL,1,1,0,'COLLECT');

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_UPDATE_QUERY_HISTORY', NULL, 'Rollup QUERY data into history tables','HH',1,NULL,1,1,1,'COLLECT');


INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_INDEXSTATS', NULL, 'Collect INDEX STATS for database','HH',1,NULL,1,1,0,'COLLECT');

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_SQL_TEXT', NULL, 'Collect SQL TEXT for database','HH',1,NULL,1,1,0,'COLLECT');

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_QUERY_PLANS', NULL, 'Collect QUERY PLANS for database','HH',1,NULL,1,1,0,'COLLECT');

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_SYSOBJECTS', NULL, 'Collect SYSTEM OBJECT DEFINITIONS for database','DD',1,NULL,1,1,0,'COLLECT');

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_WAITSTATS', NULL, 'Collect SERVER WAIT STATS for server','HH',1,NULL,1,1,1,'COLLECT');


INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_VIRTIALIO_DISKSTATS', NULL, 'Collect VIRTUAL I/O DISK STATS for database','HH',1,NULL,1,1,0,'COLLECT');


INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_CHANGE_DATA_CONTROL', NULL, 'Collect CHANGE DATA CONTROL for database','DD',1,NULL,0,1,0,'COLLECT');


INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_CHANGE_TRACKING', NULL, 'Collect CHANGE TRACKING for database','DD',1,NULL,1,1,0,'COLLECT')


--INSERT DYNPERF_TASK_SCHEDULER
--VALUES (1,'ALL', 'DYNPERF_COLLECT_SSRS_EXECUTIONLOG', NULL, 'Collect SSRS for database','MI',5,NULL,1,1,0,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_SQL_DATA_BUFFER_CACHE', NULL, 'Collect SQL DATA BUFFER CACHE for server','DD',1,NULL,1,1,1,'COLLECT')


INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_SQL_DATABASES', NULL, 'Collect SQL DATABASES INFORMATION for server','DD',1,NULL,0,1,1,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_DATABASE_REPLICATION_INFO', NULL, 'Collect REPLICATION CONFIGURATION for database','DD',1,NULL,0,1,0,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_SQL_CONFIGURATION', NULL, 'Collect SQL CONFIGURATION INFORMATION for server','DD',1,NULL,0,1,1,'COLLECT')


INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_SQL_ALWAYSON', NULL, 'Collect SQL ALWAYSON INFORMATION for server','DD',1,NULL,0,1,1,'COLLECT')


INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_SQL_DATABASE_FILES', NULL, 'Collect SQL DATABASE FILE INFORMATION for server','DD',1,NULL,0,1,1,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_DATABASE_VLFS', NULL, 'Collect SQL TLOG VLFS for server','DD',1,NULL,0,1,1,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_INDEX_USAGE_STATS', NULL, 'Collect INDEX USAGE STATS for database','HH',1,NULL,1,1,0,'COLLECT');

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_INDEX_OPERATIONAL_STATS', NULL, 'Collect INDEX OPERATIONAL STATS for database','HH',1,NULL,1,1,0,'COLLECT');
	

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_SQL_JOBS', NULL, 'Collect SQL JOBS for server','DD',1,NULL,0,1,1,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_SERVERINFO', NULL, 'Collect SQL INSTANCE CONFIGURATION for server','DD',1,NULL,1,1,1,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_SERVER_REGISTRY', NULL, 'Collect SQL STARTUP PARMS IN THE REGISTRY for server','DD',1,NULL,0,1,1,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_SERVER_DISKVOLUMES', NULL, 'Collect DISKVOLUMES USED BY SQL for server','WK',1,NULL,0,1,1,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_SERVER_OS_INFO', NULL, 'Collect WINDOW OS VERSION INFO for server','WK',1,NULL,0,1,1,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_TRIGGER_INFO', NULL, 'Collect DATABASE TRIGGER INFO for database','DD',1,NULL,1,1,0,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_SQL_TRACEFLAGS_RUNNING', NULL, 'Collect RUNNING TRACE FLAGS for server','DD',1,NULL,0,1,1,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_SQL_ERRORLOG', NULL, 'Collect SQL SERVER ERROR LOG for server','MI',5,NULL,1,1,1,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_DATABASE_STATISTICS', NULL, 'Collect DATABASE STATISTICS for database','WK',1,NULL,0,1,0,'PROCESS_LP')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_SQL_PLAN_GUIDES', NULL, 'Collect PLAN GUIDES for database','DD',1,NULL,1,1,0,'COLLECT');

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_PERF_COUNTERS', NULL, 'Collect SQL Performance Counters ','MI',5,NULL,0,1,1,'COLLECT');

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_PERF_COUNTERS_AZURE', NULL, 'Collect SQL Performance Counters for AZURE db ','MI',5,NULL,1,1,0,'COLLECT');

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_AZURE_EVENTLOG', NULL, 'Collect sys.event_log  for AZURE db ','MI',5,NULL,1,1,0,'COLLECT');

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_COLLECT_DB_SCOPECONFIG', NULL, 'Collect Scope level config for database','DD',1,NULL,1,1,0,'COLLECT')





-----------------------------------------Process Tasks -----------------------------------------------------------------------------







INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_UPDATE_INDEX_HISTORY', NULL, 'Rollup INDEX data into history tables','HH',1,NULL,1,1,1,'PROCESS');

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_PROCESS_QUERY_ALERTS', NULL, 'Query Alerts Processing','HH',1,NULL,1,1,0,'PROCESS');

--INSERT DYNPERF_TASK_SCHEDULER
--VALUES (1,'ALL', 'DYNPERF_UPDATE_SSRS_HISTORY', NULL, 'Rollup SSRS EXECUTIONLOG into History table','MI',5,NULL,1,1,1,'PROCESS');

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_PROCESS_MISSING_INDEXES', NULL, 'Parse MISSING INDEXES from Query Plans','HH',1,NULL,1,1,0,'PROCESS');

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_PROCESS_AXSQLTRACE', '7' , 'Update QUERY_HASH in AX_SQLTRACE table','MI',5,NULL,1,1,0,'PROCESS_LP');

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_REFRESH_QUERY_PLANS', NULL, 'Refresh old QUERY PLANS','DD',1,NULL,1,1,0,'PROCESS_LP');

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_REFRESH_QUERY_TEXT', NULL, 'Refresh old QUERY TEXT','DD',1,NULL,1,1,0,'PROCESS_LP');

--reh do this task last so everything else happens in case this task takes a long time
INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_PROCESS_QUERY_PLANS', NULL, 'Parse all XML Query Plans','HH',1,NULL,1,1,0,'PROCESS_LP');


INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'ALL', 'DYNPERF_PURGE_DATA', NULL, 'Purge data from DynamicsPerf','DD',1,NULL,1,1,1,'PROCESS_LP');


/****************************************

AX_SCHEDULE

These are the  tasks for Dynamics AX
*****************************************/

----------------------------------------------AX ---------------------------------------

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'AX', 'DYNPERF_COLLECT_AX_SQLTRACE', NULL, 'Collect SYSTRACETABLESQL for database','MI',5,NULL,0,1,0,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'AX', 'DYNPERF_COLLECT_AX_BATCHJOB', NULL, 'Collect AX_BATCHJOB for database','MI',5,NULL,0,1,0,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'AX', 'DYNPERF_UPDATE_AXBATCH_HISTORY', NULL, 'Process AX_BATCHJOB data into History','MI',5,NULL,0,1,0,'PROCESS')


--REH replaced by AOTEXPORT, better data
--INSERT DYNPERF_TASK_SCHEDULER
--VALUES (1,'AX', 'DYNPERF_COLLECT_AX_BATCHSERVER', NULL, 'Collect AX BATCH TABLES for database','DD',1,NULL,0,1,0,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'AX', 'DYNPERF_COLLECT_AX_SQLSTORAGE', NULL, 'Collect AX SQLSTORAGE TABLE for database','WK',1,NULL,0,1,0,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'AX', 'DYNPERF_COLLECT_AX_USERINFO', NULL, 'Collect AX USERINFO TABLE for database','DD',1,NULL,0,1,0,'COLLECT')


INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'AX', 'DYNPERF_COLLECT_AX_NUMBERSEQUENCE', NULL, 'Collect AX NUMBER SEQUENCES for database','HH',1,NULL,0,1,0,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'AX', 'DYNPERF_COLLECT_AX_SYSGLOBALCONFIG', NULL, 'Collect AX SYSGLOBALCONFIG for database','DD',1,NULL,0,1,0,'COLLECT')

--REH AOTEXPORT class goes direct to DynamicsPerf now
--INSERT DYNPERF_TASK_SCHEDULER
--VALUES (1,'AX', 'DYNPERF_COLLECT_AX_AOTEXPORT_DATA', NULL, 'Collect AX AOTEXPORT DATA for database','DD',1,NULL,0,1,0,'COLLECT')


--REH mark this as server level task because it gets its names from another config table
INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'AX', 'DYNPERF_SET_AX_SQLTRACE', NULL, 'Set AX_SQLTRACE for database','DD',1,NULL,0,1,1,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'AX', 'DYNPERF_COLLECT_AX_USERINFO', NULL, 'Collect USERINFO for database','DD',1,NULL,0,1,0,'COLLECT')





/****************************************

CRM_SCHEDULE

These are the  tasks for Dynamics CRM
*****************************************/

----------------------------------------------CRM ---------------------------------------

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'CRM', 'DYNPERF_COLLECT_CRM_ORGANIZATION', NULL, 'Collect CRM ORGANIZATION INFO for database','DD',1,NULL,0,1,0,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'CRM', 'DYNPERF_COLLECT_CRM_PLUGINS', NULL, 'Collect CRM PLUGINS INFO for database','DD',1,NULL,0,1,0,'COLLECT')

INSERT DYNPERF_TASK_SCHEDULER
VALUES (1,'CRM', 'DYNPERF_COLLECT_CRM_POA_TOTALS', NULL, 'Collect CRM Primary Object Access INFO for database','HH',1,NULL,0,1,0,'COLLECT')








-- Update version stamp and install date

UPDATE [DynamicsPerf]..[DYNAMICSPERF_SETUP] SET VERSION = '2.10 RTM', INSTALLED_DATE = GETDATE()






GO
PRINT N'Update complete.';


GO
